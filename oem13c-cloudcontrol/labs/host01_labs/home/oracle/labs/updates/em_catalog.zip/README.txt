ZIP Archive generated at Fri Jan  8 15:15:04 2016

Generated Date/Time MD5 Digest                       Filename
------------------- -------------------------------- --------------------------
2016-01-08 21:16:52 154b34f305ae7e62f98a3f201e1d0864 aru_products.xml
2016-01-08 21:25:05 6ab5d02e610a70ab5c24677ead3e5cc6 aru_releases.xml
2016-01-08 21:17:22 82c66fc9d01539a6a884a786e991b1d5 aru_platforms.xml
2016-01-08 21:15:31 5f16cd40ba3fb92944ed31854faae5fd aru_languages.xml
2016-01-08 21:17:20 4265059b4c67990514b5468c22af6bcc aru_product_groups.xml
2016-01-08 21:17:03 4d92cc1f4bf6b9335d7fcb6e70ef219c aru_product_releases.xml
2013-04-15 02:30:00 938a324bc01201106c6ce390af7ecaa7 aru_component_releases.xml
2016-01-08 21:15:05 b5c88098499a10d4a2f051b2799b256e aru_targets.xml
2016-01-08 22:40:56 a70ab3aa0ff11831746b8817e8d12003 components.xml
2016-01-08 22:41:11 188fdb4bab1a6aaf5cf45866507e8f7d certifications.xml
2016-01-08 22:50:01 e2884f1c96bf3e24b8a481289335c682 patch_recommendations.xml
