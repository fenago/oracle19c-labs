Rem
Rem $Header: rdbms/admin/e1201000.sql /st_rdbms_12.1.0.2.0dbpsu/2 2015/03/15 08:49:11 surman Exp $
Rem
Rem e1201000.sql
Rem
Rem Copyright (c) 2012, 2015, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      e1201000.sql - downgrade Oracle from 12.1.0.2 patch release
Rem      This scripts is run from catdwgrd.sql to perform any actions
Rem      needed to downgrade from 12g
Rem
Rem    DESCRIPTION
Rem      This scripts is run from catdwgrd.sql to perform any actions
Rem      needed to downgrade from the current 12.1 patch release to
Rem      prior 12.1 patch releases
Rem
Rem
Rem    NOTES
Rem      * This script needs to be run in the current release environment
Rem        (before installing the release to which you want to downgrade).
Rem      * Use SQLPLUS and connect AS SYSDBA to run this script.
Rem      * The database must be open in UPGRADE mode/DOWNGRADE mode.
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      11/07/14 - 19978542: Change bundle_data back to XMLType
Rem    shjoshi     06/12/14 - bug18969815: drop *hist_reports* for dwngrd
Rem    pyam        06/10/14 - 18764101: truncate pdb_inv_type$
Rem    myuin       06/10/14 - handle WRM$_PDB_IN_SNAP and related table/views
Rem    surman      06/05/14 - Backport surman_bug-17277459 from main
Rem    moreddy     06/05/14 - Backport moreddy_lrg-12149882 from main
Rem    lexuxu      06/04/14 - Backport lexuxu_bug-18756350 from main
Rem    cxie        05/30/14 - Backport cxie_bug-18810866 from main
Rem    prthiaga    05/22/14 - Bug 18805145: Drop DBMS_FEATURE_JSON
Rem    dkoppar     05/22/14 - backport of 18219841
Rem    apfwkr      05/26/14 - Backport prthiaga_bug-18805145 from main
Rem    suelee      05/12/14 - Backport jomcdon_bug-18622736 from main
Rem    apfwkr      04/24/14 - Backport akruglik_bug-17446096 from main
Rem    surman      04/17/14 - Backport surman_bug-17665117 and dkoppar_bug-17665104 from main
Rem    apfwkr      04/10/14 - Backport akruglik_bug-18417322 from main
Rem    lexuxu      05/23/14 - bug 18756350
Rem    prthiaga    05/22/14 - Bug 18805145: Drop DBMS_FEATURE_JSON
Rem    cxie        05/15/14 - drop colunm CAUSE on pdb_alert$
Rem    surman      04/21/14 - 17277459: Add bundle columns to SQL registry
Rem    akociube    04/02/14 - drop package DBMS_FEATURE_IMA
Rem    youyang     04/02/14 - Backport youyang_bug-18442084 from main
Rem    abrumm      04/01/14 - rename ORACLE_BIGSQL to ORACLE_BIGDATA
Rem    apfwkr      04/01/14 - Backport tseibold_bug-18459020 from main
Rem    jkaloger    03/30/14 - Add changes for Oracle BigData Agent
Rem    skabraha    03/26/14 - drop JSON views
Rem    spapadom    03/24/14 - XbranchMerge spapadom_imc1 from main
Rem    apfwkr      03/20/14 - Backport praghuna_bug-17638117 from main
Rem    apfwkr      03/16/14 - Backport genli_waitoutlier from main
Rem    akruglik    04/10/14 - Bug 17446096: remove adminauth$ rows in a non-CDB
Rem    akruglik    04/01/14 - Bug 18417322: update CDB_LOCAL_ADMINAUTH$.flags
Rem    youyang     03/26/14 - bug18442084:fix type grant_path
Rem    tseibold    03/25/14 - Bug 18459020: drop Opatch diag views
Rem    jinjche     02/28/14 - Rename a couple of columns
Rem    genli       02/25/14 - drop view and public synonym 
Rem                           for EVENT_HISTOGRAM_MICRO
Rem    risgupta    02/24/14 - Bug 18174384: Drop ora_logon_failures
Rem    jorgrive    02/21/14 - bug 9774957
Rem    hbaer       02/14/14 - remove feature usage tracking DBMS_FEATURE_ZMP
Rem    sslim       02/11/14 - drop cdb_ptc_apply_progress
Rem    jheng       02/10/14 - Bug 18224840
Rem    cdilling    02/06/14 - bug 18165071 - drop DBA_LOCK related objects
Rem    sidatta     02/04/14 - adding views v$cell_db, v$cell_db_history and
Rem                           v$cell_open_alerts
Rem    risgupta    02/03/14 - Bug 18157726: truncate all_unified_audit_actions
Rem                           table
Rem    cgervasi    01/21/14 - 18057967: add WRH$_CELL_DB, WRH$_CELL_OPEN_ALERTS
Rem    p4kumar     01/21/14 - Bug 17537632
Rem    cdilling    01/16/14 - put back drop statements now the downgrade is run
Rem                           on PDBs first
Rem    traney      01/16/14 - 17971391:downgrade size of opbinding$.functionname
Rem    abrumm      12/24/13 - exadoop-downgrade: remove raw attribute from
Rem                           ODCIExtTable[Open,Fetch,Populate,Close]
Rem    achaudhr    12/16/13 - 17793123: Remove oracle_loader deterministic
Rem                           keyword
Rem    jheng       01/09/14 - Bug 18056142: revoke granted SELECT ON privs
Rem    dvoss       12/31/13 - bug 18006033 - dba_rolling_unsupported
Rem    gravipat    12/30/13 - truncate pdb_sync$
Rem    thbaby      12/24/13 - 17987966: drop procedure createX$PermanentTables
Rem    achaudhr    12/16/13 - 17793123: Remove oracle_loader deterministic keyword
Rem    cmlim       12/15/13 - cmlim_bug-17545700: extra: drop cdb and dba
Rem                           objects on top of registry$error
Rem    chinkris    12/12/13 - rename (g)v$imc views as (g)v$im views
Rem    hlakshma    12/10/13 - Drop constraints to ADO tables
Rem    amylavar    12/06/13 - Drop package DBMS_FEATURE_IOT
Rem    yberezin    12/04/13 - bug 17391276: introduce OS time for
Rem                           capture/replay start
REM    tianli      12/04/13 - 17742001: fix process_drop_user_cascade
Rem    thbaby      12/02/13 - drop INT$DBA_COL_COMMENTS, INT$DBA_TAB_COMMENTS
Rem    rmorant     12/02/13 - LRG:9955689 delete duplicae rows in
Rem                           DYN_REMASTER_STATS
Rem    jinjche     11/22/13 - Add big SCN support
Rem    praghuna    11/20/13 - Added pto recovery fields to apply milestone
Rem    ssprasad    11/20/13 - drop views (g)v$asm_disk_sparse(_stat)
Rem                                      (g)v$asm_diskgroup_sparse
Rem    rpang       11/12/13 - 17637420: clear tracking columns in sqltxl tables
Rem                           WRH$_CELL_IOREASON_NAME
Rem    cgervasi    11/06/13 - bug 17852957: add WRH$_CELL_IOREASON, 
Rem                           WRH$_CELL_IOREASON_NAME
Rem    cdilling    11/04/13 - bug 17639057 -add support for cdb downgrade
Rem                         - remove unnecesary drop type statements
Rem    amylavar    11/01/13 - Drop package DBMS_FEATURE_IMC
Rem    yxie        10/28/13 - drop procedure dbms_feature_emx
Rem    yxie        10/25/13 - drop [g]v$emx_usage_stats
Rem    sidatta     10/02/13 - v$cell_ioreason table
Rem    jmuller     08/06/13 - Fix bug 17250794: rework of USE privilege on
Rem                           default edition
Rem    amylavar    23/10/13 - 16859747: Drop DBMS_FEATURE_ADV_TABCMP
Rem    chinkris    10/30/13 - Drop (g)v$im_column_level
Rem    jkati       10/29/13 - bug#17543726 : drop STIG compliant profile
Rem    cchiappa    10/28/13 - Rename V$VECTOR_TRANSLATE to V$KEY_VECTOR
Rem    qinwu       10/21/13 - drop divergence_load_status from wrr$_replays
Rem    romorale    10/21/13 - drop _dba_xstream_unsupported_12_1
Rem    lbarton     10/17/13 - bug 17621089: drop dbms_export_extension_i
Rem    jekamp      10/16/13 - Project 35591: Add v$im_segments and
Rem                           v$im_user_segments
Rem    jinjche     10/16/13 - Rename nab to old_blocks
Rem    sragarwa    10/10/13 - Bug 17303407 : Add delete privileges on aud$
Rem                           and fga_log$ to DELETE_CATALOG_ROLE
Rem    chinkris    10/10/13 - Drop views (g)v$inmemory_area
Rem    sasounda    09/26/13 - proj 47829: del READ priv granted during upgrade
Rem    surman      08/05/13 - 17005047: Add dbms_sqlpatch
Rem    gravipat    10/04/13 - drop INTDBA_PDBS
Rem    tianli      10/03/13 - drop view for apply$_cdr_info
Rem    cxie        10/01/13 - drop index i_pdb_alert2 on pdb_alert$
Rem    huntran     09/30/13 - add lob apply stats
Rem    thbaby      09/30/13 - 17518642: drop view INT$DBA_HIST_CELL_GLOBAL
Rem    chinkris    09/28/13 - Drop views (G)V$IMC_COLUMN_LEVEL
Rem    shiyadav    09/26/13 - bug17348607:downgrade for wrh$_dyn_remaster_stats
Rem    youyang     09/26/13 - bug17496774:delete plsql capture for PA
Rem    vpriyans    09/23/13 - Bug 17299076: drop ORA_CIS_RECOMMENDATIONS
Rem    minx        09/18/13 - Fix Bug 17478619: Add data realm description 
Rem    desingh     08/30/13 - drop columns from AQ SYS.*_PARTITION_MAP tables
Rem    thbaby      09/17/13 - lrg 9710290: reload INT$DBA_CONSTRAINTS
Rem    chinkris    09/11/13 - Drop views (G)V$IMC_AREA
Rem    thbaby      08/29/13 - 14515351: drop INT$ views for object linked views
Rem    jinjche     08/27/13 - Add a column and rename some columns
Rem    sdball      08/26/13 - Bug 17199155: Set db_type to NULL on downgrade
Rem    talliu      08/26/13 - add drop public synonym for CDB views.
Rem    shiyadav    08/22/13 - bug 13375362: changes in baseline for downgrade
Rem    jheng       08/22/13 - Bug 17251375: drop rolename_array
Rem    cgervasi    08/20/13 - add wrh$_cell_global, wrh$_cell_metric_desc
Rem    myuin       08/20/13 - add drop view statements to new CDB_HIST views
Rem    thbaby      08/14/13 - 17313338: drop view int$dba_stored_settings
Rem    praghuna    08/13/13 - bug 17030189
Rem    thbaby      08/13/13 - 16956123: drop view INT$INT$DBA_CONSTRAINTS
Rem    jheng       08/08/13 - Bug 16931220: drop type grant_path
Rem    pradeshm    08/07/13 - Drop new vew USER_XS_PASSWORD_LIMITS created for
Rem                           proj46908
Rem    sidatta     07/30/13 - Adding Cell Metric Description table/views
Rem    shrgauta    07/30/13 - Add V$ and GV$ entries for IMCU and SMU views
Rem    hsivrama    07/22/13 - bug 15854162: drop DBMS_FEATURE_ADAPTIVE_PLANS,
Rem                           DBMS_FEATURE_AUTO_REOPTIMIZATION procedures.
Rem    cgervasi    03/25/13 - add wri$_rept_cell
Rem    dlopezg     07/23/13 - bug 16444144 - new objects were created. Remove
Rem                           them
Rem    hsivrama    07/22/13 - bug 15854162: drop DBMS_FEATURE_ADAPTIVE_PLANS,
Rem                           DBMS_FEATURE_AUTO_REOPTIMIZATION procedures.
Rem    rpang       07/19/13 - 17185425: downgrade SQL ID/hash for SQL
Rem                           translation profiles
Rem    nkgopal     07/16/13 - Bug 14168362: Remove dbid, pdb guid from
Rem                           sys.dam_last_arch_ts$
Rem    mjungerm    07/08/13 - revert addition of CREATE JAVA priv
Rem    pradeshm    07/03/13 - Proj#46908: drop column added in principal table
Rem    svivian     07/01/13 - bug 16848187: clear con_id in logstdby$events
Rem    rpang       06/28/13 - Remove network ACLs from noexp$
Rem    sidatta     06/20/13 - Dropping (g)v$ views and synonyms for
Rem                           cell_global(_history), cell_disk(_history)
Rem    kyagoub     06/07/13 - bug16654392: drop auto_sql_tuning_prog
Rem    gravipat    06/20/13 - drop view DBA_PDB_SAVED_STATES
Rem    mayanagr    06/12/13 - Drop IMC Space (g)v$ views
Rem    kyagoub     06/07/13 - bug16654392: drop auto_sql_tuning_prog
Rem    xha         06/06/13 - Bug 16829223: IMC level flags and map by flags
Rem    sidatta     03/21/13 - Drop Exadata AWR tables
Rem    dgagne      06/04/13 - drop data pump standalone function
Rem    hlakshma    05/21/13 - Changes related to compression advisor
Rem    sdball      05/15/13 - Bug 16816121: Unset data_vers in cloud
Rem    jstraub     05/10/13 - Delete APEX_050000 from sys.default_pwd$
Rem    thbaby      05/08/13 - 13606922: drop view INT$DBA_PLSQL_OBJECT_SETTINGS
Rem    ckearney    05/07/13 - drop vector translate views
Rem    mjungerm    05/06/13 - add create java and related privs
Rem    sdball      05/06/13 - Bug 16770655 - Remove weights from region
Rem    jstraub     05/02/13 - Delete APEX_040200 from sys.default_pwd$
Rem    jinjche     05/02/13 - Change drop column to update per reviewer
Rem                           comments
Rem    jinjche     04/30/13 - Rename and add columns for cross-endian support
Rem    nbenadja    04/22/13 - Remove GDS package types.
Rem    vgokhale    05/15/13 - dbms_scn package downgrade
Rem    jekamp      03/12/13 - Project 35591: drop IMC views
Rem    itaranov    03/28/13 - GDS downgrade (types removal)
Rem    lexuxu      03/27/13 - lrg 8929646
Rem    jerrede     03/26/13 - Move GV$AUTO_BMR_STATISTICS from e1102000.sql to
Rem                           e1201000.sql, it was put in the wrong script
Rem    sdball      03/13/13 - Bug 16789945:remove old_instances
Rem    xbarr       03/07/13 - Downgrading Data Mining feature usage
Rem    youngtak    03/04/13 - BUG-16223559: drop v$fs_observer_histogram
Rem    jovillag    02/27/13 - 14669017: drop _DBA_XSTREAM_OUT_ALL_TABLES
Rem                           and _DBA_XSTREAM_OUT_ADT_PK_TABLES
Rem    esmendoz    02/21/13 - BUG 13868571 - Downgrading Gateway Feature usage
Rem    mwjohnso    02/14/13 - drop LOADER_DB_OPEN_READ_WRITE
Rem    amunnoli    02/08/13 - Bug 16066652: Drop column job_flags from
Rem                           dam_cleanup_jobs$
Rem    elu         02/06/13 - drop get_oldversion_hashcode2
Rem    sdball      01/23/13 - Bugs 16269799,16269848:
Rem                           Add GDS downgrade to 12.1.0.1
Rem    praghuna    13/01/11 - update logstdby$apply_milestone.lwm_upd_time  
Rem    vpriyans    01/27/13 - Bug 15996683: drop table
Rem                           UNIFIED_MISC_AUDITED_ACTIONS
Rem    praghuna    13/01/11 - update logstdby$apply_milestone.lwm_upd_time  
Rem    cdilling    10/19/12 - patch downgrade from 12.1.0.2 to 12.1.0.1
Rem    cdilling    10/19/12 - Created
Rem

Rem *************************************************************************
Rem BEGIN e1201000.sql
Rem *************************************************************************

@@?/rdbms/admin/sqlsessstart.sql

Rem ====================================================================
Rem BEGIN Security changes
Rem ===================================================================
/* [17250794] The USE privilege for PUBLIC on the default edition is implicit
 * with this fix.  Make it explicit on downgrade to a version that doesn't
 * contain the fix.
 */
DECLARE
  edn obj$.name%TYPE;
BEGIN
  SELECT property_value INTO edn FROM database_properties 
  WHERE property_name = 'DEFAULT_EDITION';
  EXECUTE IMMEDIATE 'grant use on edition ' ||
                    dbms_assert.enquote_name(edn,FALSE) ||
                    ' to public';
END;
/

DROP VIEW usable_editions;
/

DROP PUBLIC SYNONYM usable_editions;
/

Rem ====================================================================
Rem END Security changes
Rem ===================================================================

Rem ==========================================================================
Rem GRANT DELETE on AUD$ and FGA_LOG$ to DELETE_CATALOG_ROLE (Bug 17303407)
Rem ==========================================================================

GRANT DELETE ON AUD$ TO DELETE_CATALOG_ROLE;

GRANT DELETE ON FGA_LOG$ TO DELETE_CATALOG_ROLE;

Rem ====================================================================
Rem End (Bug 17303407)
Rem ===================================================================

Rem ====================================================================
Rem BEGIN GDS changes since 12.1.0.1
Rem ===================================================================

ALTER SESSION SET CURRENT_SCHEMA = gsmadmin_internal
/

ALTER TABLE service_preferred_available DROP COLUMN dbparams
/

ALTER TABLE service_preferred_available DROP COLUMN instances
/

ALTER TABLE gsm_requests DROP COLUMN old_instances
/

DROP TYPE instance_list FORCE
/

DROP TYPE instance_t FORCE
/

DROP TYPE dbparams_list FORCE
/

DROP TYPE dbparams_t FORCE
/

DROP TYPE database_dsc_t FORCE
/

DROP TYPE service_dsc_list_t FORCE
/

DROP TYPE service_dsc_t FORCE
/

DROP TYPE warning_list_t FORCE
/

DROP TYPE warning_t FORCE
/

DROP TYPE tvers_lookup_t FORCE
/

DROP TYPE vers_lookup_t FORCE
/

DROP TYPE tvers_rec FORCE
/

DROP TYPE vers_lookup_rec FORCE
/

DROP TYPE vers_list FORCE
/

DROP TYPE gsm_session FORCE
/

DROP TRIGGER cat_rollback_trigger
/

DROP TRIGGER request_delete_trigger
/

DROP TRIGGER done_trigger
/

DROP TRIGGER GSMlogoff
/

DROP PACKAGE dbms_gsm_alerts 
/


-- Per dowgrade guidelines, just set new columns back to default values

UPDATE service_preferred_available SET change_state = NULL
/

UPDATE region SET change_state = NULL
/

UPDATE region SET weights = NULL
/

UPDATE service SET change_state = NULL
/

UPDATE database SET encrypted_gsm_password = NULL
/

UPDATE cloud SET private_key = NULL
/

UPDATE cloud SET public_key  = NULL
/

UPDATE cloud SET prvk_enc_str = NULL
/

UPDATE cloud SET data_vers = NULL
/

UPDATE database  SET srlat_thresh=20
/

UPDATE database  SET cpu_thresh=75
/

UPDATE database  SET version=NULL
/

UPDATE database  SET db_type=NULL
/

UPDATE cloud SET data_vers = NULL
/

UPDATE gsm SET version = NULL
/

UPDATE gsm SET change_state = NULL
/

COMMIT
/

ALTER SESSION SET CURRENT_SCHEMA = SYS
/
show errors

Rem ====================================================================
Rem END GDS changes since 12.1.0.1
Rem ===================================================================

Rem =======================================================================
Rem  Begin Changes for Gateway feature usage
Rem =======================================================================

drop procedure  DBMS_FEATURE_GATEWAYS;

Rem =======================================================================
Rem  End Changes for Gateway feature usage
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for Data Mining feature usage
Rem =======================================================================

drop procedure DBMS_FEATURE_DATABASE_ODM;

Rem =======================================================================
Rem  End Changes for Data Mining feature usage
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for Unified Auditing
Rem =======================================================================

Rem Bug 16066652
alter table sys.dam_cleanup_jobs$ drop column job_flags;

Rem Bug 15996683
drop table UNIFIED_MISC_AUDITED_ACTIONS;

Rem *************************************************************************
Rem Begin Bug 14168362: Support cleanup of old dbid and guid based audit data
Rem *************************************************************************

drop index sys.i_dam_last_arch_ts$;
declare
  prev_version  varchar2(30);
begin
  select prv_version into prev_version from registry$
  where cid = 'CATPROC';
  if prev_version = '12.1.0.1' then 
    execute immediate 'create unique index sys.i_dam_last_arch_ts$ ' ||
                      'on sys.dam_last_arch_ts$ ' ||
                      '(audit_trail_type#, rac_instance#)';
  elsif prev_version < '12.1.0.1' then 
    execute immediate 'alter table sys.dam_last_arch_ts$ add constraint ' ||
                      'DAM_LAST_ARCH_TS_UK1 unique ' ||
                      '(audit_trail_type#, rac_instance#)';
  end if;
end;
/
alter table sys.dam_last_arch_ts$ drop column database_id;
alter table sys.dam_last_arch_ts$ drop column container_guid;

Rem *************************************************************************
Rem End Bug 14168362: Support cleanup of old dbid and guid based audit data
Rem *************************************************************************

Rem *************************************************************************
Rem Begin Bug 17299076 drop  ORA_CIS_RECOMMENDATIONS audit policy
Rem       Bug 18174384 drop  ORA_LOGON_FAILURES
Rem *************************************************************************
begin
  for item in (select policy_name, user_name, enabled_opt 
               from audit_unified_enabled_policies
               where policy_name='ORA_CIS_RECOMMENDATIONS')
  loop
    if item.user_name='ALL USERS' or item.enabled_opt='EXCEPT' then
      execute immediate 'noaudit policy '|| item.policy_name;
    else
      execute immediate 'noaudit policy '|| item.policy_name ||
                                    ' by '|| item.user_name;
    end if;
  end loop;
end;
/
drop audit policy ORA_CIS_RECOMMENDATIONS
/
begin
  for item in (select policy_name, user_name, enabled_opt 
               from audit_unified_enabled_policies
               where policy_name='ORA_LOGON_FAILURES')
  loop
    if item.user_name='ALL USERS' or item.enabled_opt='EXCEPT' then
      execute immediate 'noaudit policy '|| item.policy_name;
    else
      execute immediate 'noaudit policy '|| item.policy_name ||
                                    ' by '|| item.user_name;
    end if;
  end loop;
end;
/
drop audit policy ORA_LOGON_FAILURES 
/
Rem ***********************************************************************
Rem End Bug 17299076 drop  ORA_CIS_RECOMMENDATIONS audit policy
Rem ***********************************************************************

Rem Bug 15996683
truncate table ALL_UNIFIED_AUDIT_ACTIONS
/
 
Rem =======================================================================
Rem  End Changes for Unified Auditing
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for RAS
Rem =======================================================================

-- drop user_xs_users view
drop public synonym USER_XS_USERS;
drop view SYS.USER_XS_USERS;

-- drop USER_XS_PASSWORD_LIMITS view
drop public synonym USER_XS_PASSWORD_LIMITS;
drop view SYS.USER_XS_PASSWORD_LIMITS;

-- drop new culumns added as part of project#46908
update sys.xs$prin set profile# = 0;
update sys.xs$prin set astatus = 0;

-- add column profile dropped as part of project#46908
alter table sys.xs$prin add profile varchar2(128);

-- drop column description
alter table sys.xs$instset_rule drop column description;

-- drop type XS$REALM_CONSTRAINT_TYPE
drop type XS$REALM_CONSTRAINT_TYPE force;


Rem =======================================================================
Rem  End Changes for RAS
Rem =======================================================================

Rem =======================================================================
Rem Begin Changes for Logminer
Rem =======================================================================

-- These types are local to prvtlmcb.sql and are not used outside them. 
-- These types are used for returning rows from logminer table functions
-- and wont be persisted. 
-- In earlier releases we didnt drop the types before creating them in 
-- prvtlmcb.sql.Hence dropping them here so that running prvtlmcb.sql in
-- the downgraded db wont error.

drop TYPE SYSTEM.LOGMNR$TAB_GG_RECS ;
drop TYPE SYSTEM.LOGMNR$COL_GG_RECS ;
drop TYPE SYSTEM.LOGMNR$SEQ_GG_RECS ;
drop TYPE SYSTEM.LOGMNR$KEY_GG_RECS ;

drop TYPE SYSTEM.LOGMNR$TAB_GG_REC ;
drop TYPE SYSTEM.LOGMNR$COL_GG_REC ;
drop TYPE SYSTEM.LOGMNR$SEQ_GG_REC ;
drop TYPE SYSTEM.LOGMNR$KEY_GG_REC ;

Rem =======================================================================
Rem  End Changes for Logminer
Rem =======================================================================

Rem =======================================================================
Rem Begin Changes for Logical Standby
Rem =======================================================================

update system.logstdby$apply_milestone 
set lwm_upd_time = null, spare4 = null, spare5 = null, spare6 = null, 
    spare7 = null, pto_recovery_scn = null, pto_recovery_incarnation = null;
commit;

update system.logstdby$events set con_id = null;
commit;

drop view cdb_rolling_unsupported;
drop public synonym cdb_rolling_unsupported;

drop view dba_rolling_unsupported;
drop public synonym dba_rolling_unsupported;

drop view logstdby_ru_unsupport_tab_12_1;

drop view cdb_ptc_apply_progress;
drop view ptc_apply_progress;

Rem =======================================================================
Rem End Changes for Logical Standby
Rem =======================================================================

Rem =======================================================================
Rem Begin Changes for Data Pump 
Rem =======================================================================
drop function sys.kupc$_tab_mt_cols;

drop public synonym LOADER_DB_OPEN_READ_WRITE
drop view SYS.LOADER_DB_OPEN_READ_WRITE

Rem =======================================================================
Rem End Changes for Data Pump
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$FS_OBSERVER_HISTOGRAM
Rem =======================================================================

drop public synonym v$fs_observer_histogram;
drop view v_$fs_observer_histogram;
drop public synonym gv$fs_observer_histogram;
drop view gv_$fs_observer_histogram;

Rem =======================================================================
Rem END Changes for [G]V$FS_OBSERVER_HISTOGRAM
Rem =======================================================================

drop public synonym get_oldversion_hashcode2
/

drop function get_oldversion_hashcode2
/

Rem =======================================================================
Rem Begin Changes for Streams/XStream 
Rem =======================================================================
      
drop view "_DBA_XSTREAM_OUT_ALL_TABLES";
drop view "_DBA_XSTREAM_OUT_ADT_PK_TABLES";
TRUNCATE TABLE apply$_cdr_info;
drop view "_DBA_APPLY_CDR_INFO";
drop view "_DBA_XSTREAM_UNSUPPORTED_12_1";

update sys.apply$_table_stats set lob_operations = 0;
commit;

Rem support drop_user_cascade if downgrade
DELETE FROM sys.duc$ WHERE owner='SYS' AND pack='DBMS_STREAMS_ADM_UTL' 
  AND proc='PROCESS_DROP_USER_CASCADE' AND operation#=1;

INSERT INTO sys.duc$ (owner, pack, proc, operation#, seq, com)
  VALUES ('SYS', 'DBMS_STREAMS_ADM_UTL', 'PROCESS_DROP_USER_CASCADE', 1, 1,
          'Drop any capture or apply processes for this user');
commit;

drop package SYS.dbms_offline_snapshot_internal;
drop package SYS.dbms_defer_sys_definer;
drop package SYS.dbms_rectifier_diff_internal;
drop package SYS.dbms_defer_query_definer;
drop package SYS.dbms_defer_definer;
drop package SYS.dbms_offline_rgt_internal;
drop package SYS.dbms_repcat_definer;
drop package SYS.dbms_repcat_sna_internal;
drop package SYS.dbms_offline_og_internal;

update sys.streams$_apply_milestone 
set pto_recovery_scn = null, pto_recovery_incarnation = null;
commit;

Rem =======================================================================
Rem End Changes for Streams/XStream
Rem =======================================================================
   
Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_SEGMENTS_DETAIL
Rem =======================================================================

drop public synonym gv$im_segments_detail;
drop view gv_$im_segments_detail;
drop public synonym v$im_segments_detail;
drop view v_$im_segments_detail;

Rem =======================================================================
Rem END Changes for [G]V$IM_SEGMENTS_DETAIL
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM[_USER]_SEGMENTS
Rem =======================================================================

drop public synonym gv$im_segments;
drop view gv_$im_segments;
drop public synonym v$im_segments;
drop view v_$im_segments;

drop public synonym gv$im_user_segments;
drop view gv_$im_user_segments;
drop public synonym v$im_user_segments;
drop view v_$im_user_segments;

Rem =======================================================================
Rem END Changes for [G]V$IM[_USER]_SEGMENTS
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$INMEMORY_AREA
Rem =======================================================================

drop public synonym gv$inmemory_area;
drop view gv_$inmemory_area;
drop public synonym v$inmemory_area;
drop view v_$inmemory_area;

Rem =======================================================================
Rem END Changes for [G]V$INMEMORY_AREA
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_COLUMN_LEVEL
Rem =======================================================================

drop public synonym gv$im_column_level;
drop view gv_$im_column_level;
drop public synonym v$im_column_level;
drop view v_$im_column_level;

Rem =======================================================================
Rem END Changes for [G]V$IM_COLUMN_LEVEL
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_TBS_EXT_MAP
Rem =======================================================================

drop public synonym gv$im_tbs_ext_map;
drop view gv_$im_tbs_ext_map;
drop public synonym v$im_tbs_ext_map;
drop view v_$im_tbs_ext_map;

Rem =======================================================================
Rem END Changes for [G]V$IM_TBS_EXT_MAP
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_SEG_EXT_MAP
Rem =======================================================================

drop public synonym gv$im_seg_ext_map;
drop view gv_$im_seg_ext_map;
drop public synonym v$im_seg_ext_map;
drop view v_$im_seg_ext_map;

Rem =======================================================================
Rem END Changes for [G]V$IM_SEG_EXT_MAP
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_HEADER
Rem =======================================================================

drop public synonym gv$im_header;
drop view gv_$im_header;
drop public synonym v$im_header;
drop view v_$im_header;

Rem =======================================================================
Rem END Changes for [G]V$IM_HEADER
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_COL_CU
Rem =======================================================================

drop public synonym gv$im_col_cu;
drop view gv_$im_col_cu;
drop public synonym v$im_col_cu;
drop view v_$im_col_cu;

Rem =======================================================================
Rem END Changes for [G]V$IM_COL_CU
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_SMU_HEAD 
Rem =======================================================================

drop public synonym gv$im_smu_head;
drop view gv_$im_smu_head;
drop public synonym v$im_smu_head;
drop view v_$im_smu_head;

Rem =======================================================================
Rem END Changes for [G]V$IM_SMU_HEAD 
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$IM_SMU_CHUNK
Rem =======================================================================

drop public synonym gv$im_smu_chunk;
drop view gv_$im_smu_chunk;
drop public synonym v$im_smu_chunk;
drop view v_$im_smu_chunk;

Rem =======================================================================
Rem END Changes for [G]V$IM_SMU_CHUNK
Rem =======================================================================

Rem =======================================================================
Rem BEGIN IMC flag changes
Rem =======================================================================

Rem ts$ and seg$ flags were extended to ub8 for IMC
update ts$ set flags = bitand(flags, 4294967295) where flags > 4294967295;
update seg$ set spare1 = bitand(spare1, 4294967295) where spare1 > 4294967295;
update partobj$ set spare2 = bitand(spare2, 1099511627775) where
 spare2 > 1099511627775;

Rem File dcore.bsq - delete imc flag from deferred_stg$
update deferred_stg$ set imcflag_stg = NULL;

Rem =======================================================================
Rem END IMC flag changes
Rem =======================================================================

Rem =======================================================================
Rem Begin Changes for GV$AUTO_BMR_STATISTICS 
Rem =======================================================================

drop public synonym gv$auto_bmr_statistics;
drop view gv_$auto_bmr_statistics;

Rem =======================================================================
Rem End Changes for GV$AUTO_BMR_STATISTICS 
Rem =======================================================================

-- Remove entries from SYS.DEFAULT_PWD$
delete from SYS.DEFAULT_PWD$ where user_name='APEX_040200' and
 pwd_verifier='NOLOGIN000000000';
delete from SYS.DEFAULT_PWD$ where user_name='APEX_050000' and
 pwd_verifier='NOLOGIN000000000';

Rem =======================================================================
Rem  Begin 12.2 Changes for Physical Standby
Rem =======================================================================

alter table system.redo_db  rename column endian to spare2;
alter table system.redo_db  rename column enqidx to spare3;
alter table system.redo_db  rename column resetlogs_scn to scn1_bas;
alter table system.redo_db  rename column presetlogs_scn to scn1_wrp;
alter table system.redo_db  rename column gap_ret2 to scn1_time;
alter table system.redo_db  rename column gap_next_scn to curscn_bas;
alter table system.redo_db  rename column gap_next_time to curscn_wrp;
update system.redo_db set spare8 = 0;
update system.redo_db set spare9 = 0;
update system.redo_db set spare10 = 0;
update system.redo_db set spare11 = 0;
update system.redo_db set spare12 = 0;
update system.redo_db set resetlogs_scn_bas=0, resetlogs_scn_wrp=1, resetlogs_time=1, presetlogs_scn_bas=1, presetlogs_scn_wrp=1 where dbid=0 and thread#=0;

alter table system.redo_log  rename column endian to spare1;
alter table system.redo_log  rename column first_scn to current_scn_bas;
alter table system.redo_log  rename column next_scn to current_scn_wrp;
alter table system.redo_log  rename column resetlogs_scn to current_time;
alter table system.redo_log  rename column presetlogs_scn to current_blkno;
alter table system.redo_log  rename column old_blocks to nab;
update system.redo_log set spare8  = 0;
update system.redo_log set spare9  = 0;
update system.redo_log set spare10 = 0;
update system.redo_log set old_status1 = 0;
update system.redo_log set old_status2 = 0;
update system.redo_log set old_filename = '';

alter table system.redo_rta  rename column rls to rlsb;
alter table system.redo_rta  rename column spare9 to rlsw;
alter table system.redo_rta  rename column pscn to pscnb;
alter table system.redo_rta  rename column spare10 to pscnw;
alter table system.redo_rta  rename column rscn to rscnb;
alter table system.redo_rta  rename column spare11 to rscnw;
update system.redo_rta set spare7  = 0;
update system.redo_rta set spare8  = 0;

Rem =======================================================================
Rem  End 12.2 Changes for Physical Standby
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for CDB Common Data Views
Rem =======================================================================

drop view INT$DBA_COL_COMMENTS;
drop view INT$DBA_TAB_COMMENTS;
drop view INT$DBA_PLSQL_OBJECT_SETTINGS;
drop view INT$INT$DBA_CONSTRAINTS;

-- lrg 9710290: 12.1.0.2->12.1.0.1 downgrade drops INT$INT$DBA_CONSTRAINTS, 
-- which causes INT$DBA_CONSTRAINTS to be marked invalid. This, in turn, 
-- causes USER_CONSTRAINTS to be marked invalid. 12.1.0.1->11.2 downgrade 
-- accesses USER_CONSTRAINTS and cannot validate it. Reload the 12.1.0.1 
-- definition of INT$DBA_CONSTRAINTS right after INT$INT$DBA_CONSTRAINTS 
-- is dropped. 
create or replace view INT$DBA_CONSTRAINTS COMMON_DATA 
    (OWNER, CONSTRAINT_NAME, CONSTRAINT_TYPE,
     TABLE_NAME, OBJECT_TYPE#, SEARCH_CONDITION, SEARCH_CONDITION_VC, 
     R_OWNER, R_CONSTRAINT_NAME, DELETE_RULE, STATUS,
     DEFERRABLE, DEFERRED, VALIDATED, GENERATED,
     BAD, RELY, LAST_CHANGE, INDEX_OWNER, INDEX_NAME,
     INVALID, VIEW_RELATED, SHARING, ORIGIN_CON_ID)
as
select ou.name, oc.name,
       decode(c.type#, 1, 'C', 2, 'P', 3, 'U',
              4, 'R', 5, 'V', 6, 'O', 7,'C', 8, 'H', 9, 'F',
              10, 'F', 11, 'F', 13, 'F', '?'),
       o.name, o.type#, c.condition, 
       getlong(2, c.rowid), 
       ru.name, rc.name,
       decode(c.type#, 4,
              decode(c.refact, 1, 'CASCADE', 2, 'SET NULL', 'NO ACTION'),
              NULL),
       decode(c.type#, 5, 'ENABLED',
              decode(c.enabled, NULL, 'DISABLED', 'ENABLED')),
       decode(bitand(c.defer, 1), 1, 'DEFERRABLE', 'NOT DEFERRABLE'),
       decode(bitand(c.defer, 2), 2, 'DEFERRED', 'IMMEDIATE'),
       decode(bitand(c.defer, 4), 4, 'VALIDATED', 'NOT VALIDATED'),
       decode(bitand(c.defer, 8), 8, 'GENERATED NAME', 'USER NAME'),
       decode(bitand(c.defer,16),16, 'BAD', null),
       decode(bitand(c.defer,32),32, 'RELY', null),
       c.mtime,
       decode(c.type#, 2, ui.name, 3, ui.name, null),
       decode(c.type#, 2, oi.name, 3, oi.name, null),
       decode(bitand(c.defer, 256), 256,
              decode(c.type#, 4,
                     case when (bitand(c.defer, 128) = 128
                                or o.status in (3, 5)
                                or ro.status in (3, 5)) then 'INVALID'
                          else null end,
                     case when (bitand(c.defer, 128) = 128
                                or o.status in (3, 5)) then 'INVALID'
                          else null end
                    ),
              null),
       decode(bitand(c.defer, 256), 256, 'DEPEND ON VIEW', null), 
       decode(bitand(o.flags, 196608), 65536, 1, 131072, 1, 0), 
       to_number(sys_context('USERENV', 'CON_ID'))
from sys.con$ oc, sys.con$ rc, sys."_BASE_USER" ou, sys."_BASE_USER" ru,
     sys."_CURRENT_EDITION_OBJ" ro, sys."_CURRENT_EDITION_OBJ" o, sys.cdef$ c,
     sys.obj$ oi, sys.user$ ui
where oc.owner# = ou.user#
  and oc.con# = c.con#
  and c.obj# = o.obj#
  and c.type# != 8        /* don't include hash expressions */
  and (c.type# < 14 or c.type# > 17)    /* don't include supplog cons   */
  and (c.type# != 12)                   /* don't include log group cons */
  and c.rcon# = rc.con#(+)
  and c.enabled = oi.obj#(+)
  and oi.owner# = ui.user#(+)
  and rc.owner# = ru.user#(+)
  and c.robj# = ro.obj#(+)
/
drop view INT$DBA_STORED_SETTINGS;

Rem =======================================================================
Rem  End Changes for CDB Common Data Views
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for CDB Object Linked Views
Rem =======================================================================

DROP VIEW INT$DBA_ALERT_HISTORY; 
DROP VIEW INT$DBA_ALERT_HISTORY_DETAIL; 
DROP VIEW INT$DBA_CPOOL_INFO; 
DROP VIEW INT$DBA_HIST_ACT_SESS_HISTORY; 
DROP VIEW INT$DBA_HIST_APPLY_SUMMARY; 
DROP VIEW INT$DBA_HIST_ASH_SNAPSHOT; 
DROP VIEW INT$DBA_HIST_ASM_BAD_DISK; 
DROP VIEW INT$DBA_HIST_ASM_DG_STAT; 
DROP VIEW INT$DBA_HIST_ASM_DISKGROUP; 
DROP VIEW INT$DBA_HIST_BASELINE; 
DROP VIEW INT$DBA_HIST_BASELINE_DETAILS; 
DROP VIEW INT$DBA_HIST_BASELINE_METADATA;
DROP VIEW INT$DBA_HIST_BASELINE_TEMPLATE; 
DROP VIEW INT$DBA_HIST_BG_EVENT_SUMMARY; 
DROP VIEW INT$DBA_HIST_BUFFERED_QUEUES; 
DROP VIEW INT$DBA_HIST_BUFFER_POOL_STAT; 
DROP VIEW INT$DBA_HIST_BUF_SUBSCRIBERS; 
DROP VIEW INT$DBA_HIST_CAPTURE; 
DROP VIEW INT$DBA_HIST_CELL_CFG_DETAIL; 
DROP VIEW INT$DBA_HIST_CELL_CONFIG; 
DROP VIEW INT$DBA_HIST_CELL_DISKTYPE; 
DROP VIEW INT$DBA_HIST_CELL_DISK_NAME; 
DROP VIEW INT$DBA_HIST_CELL_DISK_SUMMARY; 
DROP VIEW INT$DBA_HIST_CELL_GLBL_SUMMARY; 
DROP VIEW INT$DBA_HIST_CELL_NAME; 
DROP VIEW INT$DBA_HIST_CLUSTER_INTERCON; 
DROP VIEW INT$DBA_HIST_COLORED_SQL; 
DROP VIEW INT$DBA_HIST_COMP_IOSTAT; 
DROP VIEW INT$DBA_HIST_CR_BLOCK_SERVER; 
DROP VIEW INT$DBA_HIST_CURR_BLK_SERVER; 
DROP VIEW INT$DBA_HIST_DATABASE_INSTANCE; 
DROP VIEW INT$DBA_HIST_DATAFILE; 
DROP VIEW INT$DBA_HIST_DB_CACHE_ADVICE; 
DROP VIEW INT$DBA_HIST_DISPATCHER; 
DROP VIEW INT$DBA_HIST_DLM_MISC; 
DROP VIEW INT$DBA_HIST_DYN_RE_STATS; 
DROP VIEW INT$DBA_HIST_ENQUEUE_STAT; 
DROP VIEW INT$DBA_HIST_EVENT_HISTOGRAM; 
DROP VIEW INT$DBA_HIST_EVENT_NAME; 
DROP VIEW INT$DBA_HIST_FILESTATXS; 
DROP VIEW INT$DBA_HIST_FM_HISTORY; 
DROP VIEW INT$DBA_HIST_IC_CLIENT_STATS; 
DROP VIEW INT$DBA_HIST_IC_DEVICE_STATS; 
DROP VIEW INT$DBA_HIST_IC_PINGS; 
DROP VIEW INT$DBA_HIST_IC_TRANSFER; 
DROP VIEW INT$DBA_HIST_INSTANCE_RECOVERY; 
DROP VIEW INT$DBA_HIST_IOSTAT_DETAIL; 
DROP VIEW INT$DBA_HIST_IOSTAT_FILETYPE; 
DROP VIEW INT$DBA_HIST_IOSTAT_FN_NAME; 
DROP VIEW INT$DBA_HIST_IOSTAT_FT_NAME; 
DROP VIEW INT$DBA_HIST_IOSTAT_FUNCTION; 
DROP VIEW INT$DBA_HIST_JAVA_POOL_ADVICE; 
DROP VIEW INT$DBA_HIST_LATCH; 
DROP VIEW INT$DBA_HIST_LATCH_CHILDREN; 
DROP VIEW INT$DBA_HIST_LATCH_NAME; 
DROP VIEW INT$DBA_HIST_LATCH_PARENT; 
DROP VIEW INT$DBA_HIST_LAT_M_SUMMARY; 
DROP VIEW INT$DBA_HIST_LIBRARYCACHE; 
DROP VIEW INT$DBA_HIST_LOG; 
DROP VIEW INT$DBA_HIST_MEMORY_RESIZE_OPS; 
DROP VIEW INT$DBA_HIST_MEM_DYNAMIC_COMP; 
DROP VIEW INT$DBA_HIST_MEM_TGT_ADVICE; 
DROP VIEW INT$DBA_HIST_METRIC_NAME; 
DROP VIEW INT$DBA_HIST_MTTR_TGT_ADVICE; 
DROP VIEW INT$DBA_HIST_MUTEX_SLEEP; 
DROP VIEW INT$DBA_HIST_MVPARAMETER; 
DROP VIEW INT$DBA_HIST_OPTIMIZER_ENV; 
DROP VIEW INT$DBA_HIST_OSSTAT; 
DROP VIEW INT$DBA_HIST_OSSTAT_NAME; 
DROP VIEW INT$DBA_HIST_PARAMETER; 
DROP VIEW INT$DBA_HIST_PARAMETER_NAME; 
DROP VIEW INT$DBA_HIST_PDB_INSTANCE; 
DROP VIEW INT$DBA_HIST_PERSISTENT_QUEUES; 
DROP VIEW INT$DBA_HIST_PERSISTENT_SUBS; 
DROP VIEW INT$DBA_HIST_PERS_QMN_CACHE; 
DROP VIEW INT$DBA_HIST_PGASTAT; 
DROP VIEW INT$DBA_HIST_PGA_TARGET_ADVICE; 
DROP VIEW INT$DBA_HIST_PLAN_OPTION_NAME; 
DROP VIEW INT$DBA_HIST_PLAN_OP_NAME; 
DROP VIEW INT$DBA_HIST_PMEM_SUMMARY; 
DROP VIEW INT$DBA_HIST_REP_TBL_STATS; 
DROP VIEW INT$DBA_HIST_REP_TXN_STATS; 
DROP VIEW INT$DBA_HIST_RESOURCE_LIMIT; 
DROP VIEW INT$DBA_HIST_ROWCACHE_SUMMARY; 
DROP VIEW INT$DBA_HIST_RSRC_CON_GROUP; 
DROP VIEW INT$DBA_HIST_RSRC_PLAN; 
DROP VIEW INT$DBA_HIST_RULE_SET; 
DROP VIEW INT$DBA_HIST_SEG_STAT; 
DROP VIEW INT$DBA_HIST_SEG_STAT_OBJ; 
DROP VIEW INT$DBA_HIST_SERVICE_NAME; 
DROP VIEW INT$DBA_HIST_SERVICE_STAT; 
DROP VIEW INT$DBA_HIST_SESS_SGA_STATS; 
DROP VIEW INT$DBA_HIST_SESS_TIME_STATS; 
DROP VIEW INT$DBA_HIST_SGA; 
DROP VIEW INT$DBA_HIST_SGASTAT; 
DROP VIEW INT$DBA_HIST_SGA_TARGET_ADVICE; 
DROP VIEW INT$DBA_HIST_SHRD_SVR_SUMMARY; 
DROP VIEW INT$DBA_HIST_SM_HISTORY; 
DROP VIEW INT$DBA_HIST_SNAPSHOT; 
DROP VIEW INT$DBA_HIST_SNAP_ERROR; 
DROP VIEW INT$DBA_HIST_SPOOL_ADVICE; 
DROP VIEW INT$DBA_HIST_SQLCOMMAND_NAME; 
DROP VIEW INT$DBA_HIST_SQLSTAT; 
DROP VIEW INT$DBA_HIST_SQLTEXT; 
DROP VIEW INT$DBA_HIST_SQL_BIND_METADATA; 
DROP VIEW INT$DBA_HIST_SQL_PLAN; 
DROP VIEW INT$DBA_HIST_SQL_SUMMARY; 
DROP VIEW INT$DBA_HIST_SQL_WA_HSTGRM; 
DROP VIEW INT$DBA_HIST_STAT_NAME; 
DROP VIEW INT$DBA_HIST_STREAMS_APPLY_SUM; 
DROP VIEW INT$DBA_HIST_STREAMS_CAPTURE; 
DROP VIEW INT$DBA_HIST_STRPOOL_ADVICE; 
DROP VIEW INT$DBA_HIST_SVC_WAIT_CLASS; 
DROP VIEW INT$DBA_HIST_SYSMETRIC_HISTORY; 
DROP VIEW INT$DBA_HIST_SYSMETRIC_SUMMARY; 
DROP VIEW INT$DBA_HIST_SYSSTAT; 
DROP VIEW INT$DBA_HIST_SYSTEM_EVENT; 
DROP VIEW INT$DBA_HIST_SYS_TIME_MODEL; 
DROP VIEW INT$DBA_HIST_TABLESPACE; 
DROP VIEW INT$DBA_HIST_TABLESPACE_STAT; 
DROP VIEW INT$DBA_HIST_TBSPC_SPACE_USAGE; 
DROP VIEW INT$DBA_HIST_TEMPFILE; 
DROP VIEW INT$DBA_HIST_TEMPSTATXS; 
DROP VIEW INT$DBA_HIST_THREAD; 
DROP VIEW INT$DBA_HIST_TOPLEVELCALL_NAME; 
DROP VIEW INT$DBA_HIST_UNDOSTAT; 
DROP VIEW INT$DBA_HIST_WAITSTAT; 
DROP VIEW INT$DBA_HIST_WCM_HISTORY; 
DROP VIEW INT$DBA_HIST_WR_CONTROL; 
DROP VIEW INT$DBA_HIST_CELL_GLOBAL;
DROP VIEW INT$DBA_HIST_CELL_METRIC_DESC;
DROP VIEW INT$DBA_HIST_CELL_IOREASON_NM;
DROP VIEW INT$DBA_HIST_CELL_IOREASON;
DROP VIEW INT$DBA_HIST_CELL_DB;
DROP VIEW INT$DBA_HIST_CELL_OPEN_ALERTS;
DROP VIEW INT$DBA_HIST_IM_SEG_STAT;
DROP VIEW INT$DBA_HIST_IM_SEG_STAT_OBJ;
DROP VIEW INT$DBA_HIST_PDB_IN_SNAP;
DROP VIEW INT$DBA_HIST_REPORTS_DETAILS;
DROP VIEW INT$DBA_OUTSTANDING_ALERTS; 
DROP VIEW INT$DBA_PDB_SAVED_STATES; 
DROP VIEW INT$DBA_PDBS;
DROP VIEW INT$DBA_HIST_REPORTS;
DROP VIEW INT$DBA_HIST_REPORTS_TIMEBANDS;

DROP VIEW CDB_HIST_REPORTS;
DROP PUBLIC SYNONYM CDB_HIST_REPORTS;

DROP VIEW CDB_HIST_REPORTS_DETAILS;
DROP PUBLIC SYNONYM CDB_HIST_REPORTS_DETAILS;

DROP VIEW CDB_HIST_REPORTS_TIMEBANDS;
DROP PUBLIC SYNONYM CDB_HIST_REPORTS_TIMEBANDS;

DROP VIEW CDB_HIST_REPORTS_CONTROL;
DROP PUBLIC SYNONYM CDB_HIST_REPORTS_CONTROL;

Rem =======================================================================
Rem  End Changes for CDB Object Linked Views
Rem =======================================================================

Rem =======================================================================
Rem  Begin Changes for CDB X$ Tables
Rem =======================================================================

drop procedure createX$PermanentTables;
drop procedure dropX$PermanentTables;

Rem =======================================================================
Rem  End Changes for CDB X$ Tables
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$KEY_VECTOR
Rem =======================================================================

drop public synonym gv$key_vector;
drop public synonym v$key_vector;
drop view gv_$key_vector;
drop view v_$key_vector;

Rem =======================================================================
Rem END Changes for [G]V$KEY_VECTOR
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for In-Memory Aggregation
Rem =======================================================================

Rem Used by feature tracking
drop procedure DBMS_FEATURE_IMA;

Rem =======================================================================
Rem END Changes for In-Memory Aggregation
Rem =======================================================================

Rem =======================================================================
Rem Begin Changes for DBMS_SCN
Rem =======================================================================

drop public synonym dbms_scn;
drop package body sys.dbms_scn;
drop package sys.dbms_scn;
drop library dbms_scn_lib;

Rem =======================================================================
Rem End Changes for DBMS_SCN
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for In-Memory Column Store
Rem =======================================================================

Rem Used by feature tracking
drop procedure DBMS_FEATURE_IMC;

Rem =======================================================================
Rem END Changes for In-Memory Column Store
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes Zone map tracking
Rem =======================================================================

Rem Used by feature tracking
drop procedure DBMS_FEATURE_ZMAP;

Rem =======================================================================
Rem END Changes for In-Memory Column Store
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for Index Organized Tables
Rem =======================================================================

Rem Used by feature tracking
drop procedure DBMS_FEATURE_IOT;

Rem =======================================================================
Rem END Changes for Index Organized Tables
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for ADVANCED Table Compression
Rem =======================================================================

Rem Used by dbms_compression
drop package prvt_compress;

Rem Used by feature tracking
drop procedure DBMS_FEATURE_ADV_TABCMP;

Rem =======================================================================
Rem END Changes for ADVANCED Table Compression
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for JSON
Rem =======================================================================

Rem Used by feature tracking
drop procedure DBMS_FEATURE_JSON;

Rem =======================================================================
Rem END Changes for JSON
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for [G]V$CELL_CONFIG_INFO
Rem =======================================================================

drop public synonym gv$cell_config_info;
drop public synonym v$cell_config_info;
drop view gv_$cell_config_info;
drop view v_$cell_config_info;

Rem =======================================================================
Rem END Changes for [G]V$CELL_CONFIG_INFO
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for Cell Metrics Fixed Tables
Rem =======================================================================

drop public synonym gv$cell_metric_desc;
drop public synonym v$cell_metric_desc;
drop view gv_$cell_metric_desc;
drop view v_$cell_metric_desc;

drop public synonym gv$cell_global;
drop public synonym v$cell_global;
drop view gv_$cell_global;
drop view v_$cell_global;

drop public synonym gv$cell_global_history;
drop public synonym v$cell_global_history;
drop view gv_$cell_global_history;
drop view v_$cell_global_history;

drop public synonym gv$cell_disk;
drop public synonym v$cell_disk;
drop view gv_$cell_disk;
drop view v_$cell_disk;

drop public synonym gv$cell_disk_history;
drop public synonym v$cell_disk_history;
drop view gv_$cell_disk_history;
drop view v_$cell_disk_history;

drop public synonym gv$cell_ioreason;
drop public synonym v$cell_ioreason;
drop view gv_$cell_ioreason;
drop view v_$cell_ioreason;

drop public synonym gv$cell_ioreason_name;
drop public synonym v$cell_ioreason_name;
drop view gv_$cell_ioreason_name;
drop view v_$cell_ioreason_name;

drop public synonym gv$cell_db;
drop public synonym v$cell_db;
drop view gv_$cell_db;
drop view v_$cell_db;

drop public synonym gv$cell_db_history;
drop public synonym v$cell_db_history;
drop view gv_$cell_db_history;
drop view v_$cell_db_history;

drop public synonym gv$cell_open_alerts;
drop public synonym v$cell_open_alerts;
drop view gv_$cell_open_alerts;
drop view v_$cell_open_alerts;

Rem =======================================================================
Rem END Changes for Cell Metrics Fixed Tables
Rem =======================================================================

Rem===================
Rem AWR Changes Begin
Rem===================

update wrm$_baseline set baseline_name = substr(baseline_name, 1, 64);
update wrm$_baseline set template_name = substr(template_name, 1, 64);

update wrm$_baseline_template set template_name = 
substr(template_name, 1, 30);

update wrm$_baseline_template set baseline_name_prefix = 
substr(baseline_name_prefix, 1, 30);

alter table wrh$_dyn_remaster_stats drop constraint wrh$_dyn_remaster_stats_pk;

alter table wrh$_dyn_remaster_stats drop column remaster_type;

delete from wrh$_dyn_remaster_stats a where a.rowid > any (select b.rowid from
wrh$_dyn_remaster_stats b where b.dbid = a.dbid and b.snap_id = a.snap_id and
b.instance_number = a.instance_number and b.con_dbid = a.con_dbid);

alter table wrh$_dyn_remaster_stats add constraint wrh$_dyn_remaster_stats_pk 
        primary key (dbid, snap_id, instance_number, con_dbid);

commit;

-- AWR PDB table changes
truncate table WRM$_PDB_IN_SNAP;
truncate table WRM$_PDB_IN_SNAP_BL;
drop view DBA_HIST_PDB_IN_SNAP;
drop public synonym DBA_HIST_PDB_IN_SNAP;
drop view CDB_HIST_PDB_IN_SNAP;
drop public synonym CDB_HIST_PDB_IN_SNAP;


Rem =======================================================================
Rem Begin Changes for AWR Exadata
Rem =======================================================================

-- AWR IM Segments changes
truncate table WRH$_IM_SEG_STAT;
truncate table WRH$_IM_SEG_STAT_BL;
drop view DBA_HIST_IM_SEG_STAT;
drop public synonym DBA_HIST_IM_SEG_STAT; 
drop view CDB_HIST_IM_SEG_STAT;
drop public synonym CDB_HIST_IM_SEG_STAT;

truncate table WRH$_IM_SEG_STAT_OBJ;
drop view DBA_HIST_IM_SEG_STAT_OBJ;
drop public synonym DBA_HIST_IM_SEG_STAT_OBJ; 
drop view CDB_HIST_IM_SEG_STAT_OBJ;
drop public synonym CDB_HIST_IM_SEG_STAT_OBJ;

-- Drop Exadata AWR views
truncate table WRH$_CELL_CONFIG;
drop view DBA_HIST_CELL_CONFIG;
drop public synonym DBA_HIST_CELL_CONFIG;
drop view CDB_HIST_CELL_CONFIG;
drop public synonym CDB_HIST_CELL_CONFIG;

truncate table WRH$_CELL_CONFIG_DETAIL;
drop view DBA_HIST_CELL_CONFIG_DETAIL;
drop public synonym DBA_HIST_CELL_CONFIG_DETAIL;
drop view CDB_HIST_CELL_CONFIG_DETAIL;
drop public synonym CDB_HIST_CELL_CONFIG_DETAIL;

drop view DBA_HIST_CELL_NAME;
drop public synonym DBA_HIST_CELL_NAME;
drop view CDB_HIST_CELL_NAME;
drop public synonym CDB_HIST_CELL_NAME;

drop view DBA_HIST_CELL_DISKTYPE;
drop public synonym DBA_HIST_CELL_DISKTYPE;
drop view CDB_HIST_CELL_DISKTYPE;
drop public synonym CDB_HIST_CELL_DISKTYPE;

drop view DBA_HIST_CELL_DISK_NAME;
drop public synonym DBA_HIST_CELL_DISK_NAME;
drop view CDB_HIST_CELL_DISK_NAME;
drop public synonym CDB_HIST_CELL_DISK_NAME;

truncate table WRH$_ASM_DISKGROUP;
drop view DBA_HIST_ASM_DISKGROUP;
drop public synonym DBA_HIST_ASM_DISKGROUP;
drop view CDB_HIST_ASM_DISKGROUP;
drop public synonym CDB_HIST_ASM_DISKGROUP;

truncate table WRH$_ASM_DISKGROUP_STAT;
drop view DBA_HIST_ASM_DISKGROUP_STAT;
drop public synonym DBA_HIST_ASM_DISKGROUP_STAT;
drop view CDB_HIST_ASM_DISKGROUP_STAT;
drop public synonym CDB_HIST_ASM_DISKGROUP_STAT;

truncate table WRH$_ASM_BAD_DISK;
drop view DBA_HIST_ASM_BAD_DISK;
drop public synonym DBA_HIST_ASM_BAD_DISK;
drop view CDB_HIST_ASM_BAD_DISK;
drop public synonym CDB_HIST_ASM_BAD_DISK;

truncate table WRH$_CELL_GLOBAL_SUMMARY;
truncate table WRH$_CELL_GLOBAL_SUMMARY_BL;
drop view DBA_HIST_CELL_GLOBAL_SUMMARY;
drop public synonym DBA_HIST_CELL_GLOBAL_SUMMARY;
drop view CDB_HIST_CELL_GLOBAL_SUMMARY;
drop public synonym CDB_HIST_CELL_GLOBAL_SUMMARY;

truncate table WRH$_CELL_DISK_SUMMARY;
truncate table WRH$_CELL_DISK_SUMMARY_BL;
drop view DBA_HIST_CELL_DISK_SUMMARY;
drop public synonym DBA_HIST_CELL_DISK_SUMMARY;
drop view CDB_HIST_CELL_DISK_SUMMARY;
drop public synonym CDB_HIST_CELL_DISK_SUMMARY;

truncate table WRH$_CELL_METRIC_DESC;
drop view DBA_HIST_CELL_METRIC_DESC;
drop public synonym DBA_HIST_CELL_METRIC_DESC;
drop view CDB_HIST_CELL_METRIC_DESC;
drop public synonym CDB_HIST_CELL_METRIC_DESC;

truncate table WRH$_CELL_GLOBAL;
truncate table WRH$_CELL_GLOBAL_BL;
drop view DBA_HIST_CELL_GLOBAL;
drop public synonym DBA_HIST_CELL_GLOBAL;
drop view CDB_HIST_CELL_GLOBAL;
drop public synonym CDB_HIST_CELL_GLOBAL;

truncate table WRH$_CELL_IOREASON_NAME;
drop view DBA_HIST_CELL_IOREASON_NAME;
drop public synonym DBA_HIST_CELL_IOREASON_NAME;
drop view CDB_HIST_CELL_IOREASON_NAME;
drop public synonym CDB_HIST_CELL_IOREASON_NAME;

truncate table WRH$_CELL_IOREASON;
truncate table WRH$_CELL_IOREASON_BL;
drop view DBA_HIST_CELL_IOREASON;
drop public synonym DBA_HIST_CELL_IOREASON;
drop view CDB_HIST_CELL_IOREASON;
drop public synonym CDB_HIST_CELL_IOREASON;

truncate table WRH$_CELL_DB;
truncate table WRH$_CELL_DB_BL;
drop view DBA_HIST_CELL_DB;
drop public synonym DBA_HIST_CELL_DB;
drop view CDB_HIST_CELL_DB;
drop public synonym CDB_HIST_CELL_DB;

truncate table WRH$_CELL_OPEN_ALERTS;
truncate table WRH$_CELL_OPEN_ALERTS_BL;
drop view DBA_HIST_CELL_OPEN_ALERTS;
drop public synonym DBA_HIST_CELL_OPEN_ALERTS;
drop view CDB_HIST_CELL_OPEN_ALERTS;
drop public synonym CDB_HIST_CELL_OPEN_ALERTS;


Rem =======================================================================
Rem End Changes for AWR Exadata
Rem =======================================================================

Rem =======================================================================
Rem Begin Changes for ASM DISK(/GROUP) Sparse views
Rem =======================================================================

drop public synonym v$asm_diskgroup_sparse;
drop view v_$asm_diskgroup_sparse;
drop public synonym gv$asm_diskgroup_sparse;
drop view gv_$asm_diskgroup_sparse;

drop public synonym v$asm_disk_sparse;
drop view v_$asm_disk_sparse;
drop public synonym gv$asm_disk_sparse;
drop view gv_$asm_disk_sparse;

drop public synonym v$asm_disk_sparse_stat;
drop view v_$asm_disk_sparse_stat;
drop public synonym gv$asm_disk_sparse_stat;
drop view gv_$asm_disk_sparse_stat;

drop public synonym v$asm_disk_iostat_sparse;
drop view v_$asm_disk_iostat_sparse;
drop public synonym gv$asm_disk_iostat_sparse;
drop view gv_$asm_disk_iostat_sparse;

Rem =======================================================================
Rem End Changes for ASM DISK(/GROUP) Sparse views
Rem =======================================================================

Rem =======================================================
Rem ==  Update the SWRF_VERSION to the current version.  ==
Rem ==          (12.1.0.0.0 - 10)                        ==
Rem ==  This step must be the last step for the AWR      ==
Rem ==  downgrade changes.  Place all other AWR          ==
Rem ==  downgrade changes above this.                    ==
Rem =======================================================

BEGIN
  UPDATE wrm$_wr_control SET swrf_version = 10;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    IF (SQLCODE = -942) THEN
      NULL;
    ELSE
      RAISE;
    END IF;
END;
/

Rem=================
Rem AWR Changes End
Rem=================

Rem =======================================================================
Rem Consolidated Database changes - BEGIN
Rem =======================================================================

drop public synonym DBA_PDB_SAVED_STATES;
drop view SYS.DBA_PDB_SAVED_STATES;
drop view SYS.CDB_PDB_SAVED_STATES;
drop public synonym CDB_PDB_SAVED_STATES;

Rem =======================================================================
Rem Consolidated Database changes - END
Rem =======================================================================


Rem ====================================================================
Rem Begin Changes for SQL Tuning Advisor 
Rem ====================================================================
Rem 
Rem bug#16654392: drop the auto-sqltune program if already exists. 
Rem 
begin 
  -- drop program  
  dbms_scheduler.drop_program('AUTO_SQL_TUNING_PROG');

exception
  when others then
    if (sqlcode = -27476)     -- program does not exist
    then
      null;                   -- ignore it
    else
      raise;                  -- non expected errors
    end if;
end; 
/

Rem ====================================================================
Rem End Changes for SQL Tuning Advisor 
Rem ====================================================================

Rem ====================================================================
Rem Begin changes for Bug 16444144: Added optimized objects
Rem ====================================================================

DROP SYNONYM  SYS.HS$_DDTF_OPTTables;                            
DROP TYPE     SYS.HS$_DDTF_OPTColumns_O;      
DROP TYPE     SYS.HS$_DDTF_OPTColumns_T;      
DROP FUNCTION SYS.HS$_DDTF_OPTColumns;    
DROP SYNONYM  SYS.HS$_DDTF_OPTPrimaryKeys; 
DROP TYPE     SYS.HS$_DDTF_OPTForeignKeys_O;  
DROP TYPE     SYS.HS$_DDTF_OPTForeignKeys_T;  
DROP FUNCTION SYS.HS$_DDTF_OPTForeignKeys;
DROP TYPE     SYS.HS$_DDTF_OPTProcedures_O;   
DROP TYPE     SYS.HS$_DDTF_OPTProcedures_T;   
DROP FUNCTION SYS.HS$_DDTF_OPTProcedures; 
DROP TYPE     SYS.HS$_DDTF_OPTStatistics_O;   
DROP TYPE     SYS.HS$_DDTF_OPTStatistics_T;   
DROP FUNCTION SYS.HS$_DDTF_OPTStatistics; 
DROP FUNCTION SYS.HS$_DDTF_OPTTabPriKeys; 
DROP FUNCTION SYS.HS$_DDTF_OPTTabForKeys; 
DROP FUNCTION SYS.HS$_DDTF_OPTTabStats;   

Rem ====================================================================
Rem End changes for Bug 16444144: Added optimized objects
Rem ====================================================================


Rem*********************************************************************
Rem bug 15854162: Drop dbms_feature_adaptive_plans and 
Rem               dbms_feature_auto_reopt - BEGIN
Rem*********************************************************************

drop procedure dbms_feature_adaptive_plans;
drop procedure dbms_feature_auto_reopt;

Rem*********************************************************************
Rem bug 15854162: Drop dbms_feature_adaptive_plans and 
Rem               dbms_feature_auto_reop  - END
Rem*********************************************************************

Rem =========================================================================
Rem BEGIN SQL Translation Framework Changes
Rem =========================================================================

Rem Downgrade SQL ID and SQL hash to 12.1.0.1
declare

  md5      raw(16);
  sql_id   sqltxl_sql$.sqlid%type;
  sql_hash sqltxl_sql$.sqlhash%type;

  cursor c is select u.name owner, o.name profile_name,
                     o.defining_edition edition, s.sqltext sqltext
                from sqltxl_sql$ s, "_ACTUAL_EDITION_OBJ" o, user$ u
               where s.obj# = o.obj#
                 and o.owner# = u.user#
                 for update of s.sqlid, s.sqlhash;

  -- Cast a 4-byte raw to unsigned integer in machine endianness
  function unsigned_integer(r in raw) return number as
    n number;
  begin
    n := utl_raw.cast_to_binary_integer(r, utl_raw.machine_endian);
    if (n < 0) then
      n := n + 4294967296;
    end if;
    return n;
  end;

  -- MD5 hash to SQL ID
  function sqlt_sqlid(md5 in raw) return varchar2 as
    type map_type is varray(32) of varchar2(1);
    map  map_type := map_type('0', '1', '2', '3', '4', '5', '6', '7',
                              '8', '9', 'a', 'b', 'c', 'd', 'f', 'g',
                              'h', 'j', 'k', 'm', 'n', 'p', 'q', 'r',
                              's', 't', 'u', 'v', 'w', 'x', 'y', 'z');
    hash  number;
    sqlid varchar2(13);
  begin
    hash := unsigned_integer(utl_raw.substr(md5, 9, 4)) * 4294967296 +
            unsigned_integer(utl_raw.substr(md5, 13, 4));
    for i in 1..13 loop
      sqlid := map(mod(hash,32)+1) || sqlid;
      hash  := trunc(hash/32);
    end loop;
    return sqlid;
  end;

  -- MD5 hash to SQL hash
  function sqlt_sqlhash(md5 in raw) return number as
  begin
    return unsigned_integer(utl_raw.substr(md5, 13, 4));
  end;

begin

  for r in c loop
    -- In 12.1.0.1, SQL ID and SQL hash of SQL translations in profile include
    -- profile name and edition name
    md5 := dbms_crypto.hash(r.sqltext||chr(0)||
                            '"'||r.owner||'"."'||r.profile_name||'"'||r.edition,
                            dbms_crypto.hash_md5);
    sql_id   := sqlt_sqlid(md5);
    sql_hash := sqlt_sqlhash(md5);

    update sqltxl_sql$
       set sqlid = sql_id, sqlhash = sql_hash
     where current of c;
  end loop;

end;
/
commit;

Rem =========================================================================
Rem END SQL Translation Framework Changes
Rem =========================================================================

Rem =======================================================================
Rem Begin Changes for rept framework
Rem =======================================================================
-- drop new packages generating new reports
drop package prvtemx_cell;

-- drop your report subtype synonyms here
drop public synonym wri$_rept_cell;

BEGIN
  -- delete cell object before drop the subtype
  execute immediate 'delete from sys.wri$_rept_components
             where treat(object as wri$_rept_cell) is not null';
EXCEPTION
  WHEN OTHERS THEN
    -- ignore 942 which may be caused during downgrade
    IF (SQLCODE = -942) THEN
      NULL;
    ELSE
      RAISE;
    END IF;
END;
/
 
-- drop your report subtypes here	
drop type wri$_rept_cell validate;

Rem =======================================================================
Rem End Changes for rept framework
Rem =======================================================================

Rem =========================================================================
Rem BEGIN Privilege Analysis Changes
Rem =========================================================================
alter table sys.priv_used_path$ drop column path;
alter table sys.priv_unused_path$ drop column path;

drop type sys.grant_path;
create or replace type sys.grant_path AS TABLE OF VARCHAR2(128);
/
create or replace PUBLIC synonym grant_path for sys.grant_path;
/
grant execute on grant_path to PUBLIC;

ALTER TABLE sys.priv_used_path$ add path sys.grant_path nested table path store as priv_used_path_nt return as value;

ALTER TABLE sys.priv_unused_path$ add path sys.grant_path  nested table path store as priv_unused_path_nt return as value;

--Bug 18056142
revoke select on sys.priv_capture$ from capture_admin;
revoke select on sys.capture_run_log$ from capture_admin;

--Bug 18224840
drop function sys.grantpath_to_string;
drop function sys.string_to_grantpath;
Rem =========================================================================
Rem END Privilege Analysis Changes
Rem =========================================================================


Rem *************************************************************************
Rem Network ACL changes for 12.1.0.2
Rem *************************************************************************

Rem Delete network ACLs from Datapump noexp$
delete from noexp$ ne
 where ne.obj_type = 110
   and exists (select * from dba_xs_acls xa
                where xa.security_class_owner = 'SYS'
                  and xa.security_class       = 'NETWORK_SC'
                  and xa.owner                = ne.owner
                  and xa.name                 = ne.name);
commit;

Rem *************************************************************************
Rem END Network ACL changes
Rem *************************************************************************

Rem ====================================================================
Rem BEGIN changes for Privilege Analysis
Rem ====================================================================
drop public synonym rolename_array;
drop type sys.rolename_array FORCE;

-- bug 17496774
delete from sys.priv_capture$ where id# = 0;

Rem ====================================================================
Rem End changes for Privilege Analysis
Rem ====================================================================

Rem *************************************************************************
Rem BEGIN bug#17543726 : drop STIG compliant profile
Rem *************************************************************************

drop profile ora_stig_profile cascade;
drop function ora12c_strong_verify_function;
drop function ora_complexity_check;
drop function ora_string_distance;

Rem *************************************************************************
Rem END bug#17543726 : drop STIG compliant profile
Rem *************************************************************************

Rem ====================================================================
Rem BEGIN changes for PDB_ALERT$
Rem ====================================================================
drop index i_pdb_alert2;
alter table pdb_alert$ drop column cause;
delete from pdb_alert$ where cause#>57;

Rem ====================================================================
Rem End changes for PDB_ALERT$
Rem ===================================================================

Rem =======================================================================
Rem  Begin changes for AQ SYS.*_PARTITION_MAP tables & *_pmap_* types.
Rem =======================================================================

alter table sys.aq$_queue_partition_map drop column unbound_idx;
alter table sys.aq$_dequeue_log_partition_map drop column subshard;
alter table sys.aq$_dequeue_log_partition_map drop column unbound_idx;

DROP TYPE sys.sh$qtab_pmap_list;
DROP TYPE BODY sys.sh$qtab_pmap;

create or replace type sys.sh$qtab_pmap as object(
 queue number,
 shard number,
 priority number,
 subshard number,
 partition# number,
 partname  varchar2(30),
 map_time   TIMESTAMP(6) WITH TIME ZONE,
 instance number

 );
/

CREATE OR REPLACE TYPE sys.sh$qtab_pmap_list AS VARRAY(1000000) OF sys.sh$qtab_pmap;
/

DROP TYPE sys.sh$deq_pmap_list;
DROP TYPE BODY sh$deq_pmap;

create or replace type sys.sh$deq_pmap as object(
 queue number,
 queue_part# number,
 subscriber_id number,
 instance number,
 partition# number,
 partname varchar2(30),
 flag number

 );
/

CREATE OR REPLACE TYPE sys.sh$deq_pmap_list AS VARRAY(1000000) OF sys.sh$deq_pmap;
/

Rem =======================================================================
Rem  End changes for AQ *_PARTITION_MAP tables & *_pmap_* types.
Rem =======================================================================

Rem ====================================================================
Rem Begin changes for Bug 17621089: drop dbms_export_extension_i
Rem ====================================================================

DROP PACKAGE sys.dbms_export_extension_i;

Rem ====================================================================
Rem End changes for Bug 17621089: drop dbms_export_extension_i
Rem ====================================================================

Rem =======================================================================
Rem  Begin Changes for Database Workload Capture and Replay
Rem =======================================================================
Rem
Rem Null out the new columns
UPDATE wrr$_captures SET internal_start_time    = NULL;
UPDATE wrr$_replays  SET divergence_load_status = NULL,
                         internal_start_time    = NULL;

Rem Drop as_replay package
DROP package as_replay;

Rem =======================================================================
Rem  End Changes for Database Workload Capture and Replay
Rem =======================================================================

Rem =========================================================================
Rem BEGIN proj 47829 - delete READ obj priv and READ ANY TABLE sys priv
Rem =========================================================================

-- update/delete READ object privilege from objauth$
declare
  cursor c1 is
    select oa1.obj#, oa1.grantor#, oa1.grantee#, oa1.col#
    from sys.objauth$ oa1, sys.objauth$ oa2
    where oa1.obj# = oa2.obj#
    and oa1.grantor# = oa2.grantor#
    and oa1.grantee# = oa2.grantee#
    and (oa1.col# = oa2.col# or (oa1.col# is null and oa2.col# is null))
    and oa1.privilege# != oa2.privilege#
    and oa1.privilege# = 17
    and oa2.privilege# = 9;
  priv_record c1%rowtype;
begin
  open c1;
  loop
    fetch c1 into priv_record;
    exit when c1%NOTFOUND;
    delete from sys.objauth$ oa
      where oa.obj# = priv_record.obj#
      and oa.obj# not in (select obj# from sys.obj$ where type# = 23)
      and oa.grantor# = priv_record.grantor#
      and oa.grantee# = priv_record.grantee#
      and (oa.col# = priv_record.col# or oa.col# is null)
      and oa.privilege# = 17;
    commit;
  end loop;
  close c1;
  update sys.objauth$ oa set oa.privilege# = 9 where oa.privilege# = 17
    and oa.obj# not in (select obj# from sys.obj$ where type# = 23);
  commit;
end;
/

-- update/delete READ ANY TABLE privilege from sysauth$
update sys.sysauth$ set privilege# = -47 where privilege# = -397
  and grantee# not in (select sa1.grantee# from sys.sysauth$ sa1 where sa1.privilege# = -47);
delete from sys.sysauth$ where privilege# = -397;
commit;

-- delete READ ANY TABLE option from audit$
delete from sys.audit$ where option# = 397;
commit;

-- delete READ ANY TABLE privilege from stmt_audit_option_map
delete from sys.stmt_audit_option_map where option# = 397;
commit;

-- delete READ ANY TABLE privilege from system_priv_map
delete from sys.system_privilege_map where privilege = -397;
commit;

-- delete from aud_policy$
delete from aud_policy$ where syspriv = 'READ ANY TABLE';
commit;

-- delete from objpriv$
delete from objpriv$ where privilege# = 17;
commit;

-- delete from adminauth$
delete from adminauth$ where syspriv = 397;
commit;

Rem =========================================================================
Rem END proj 47829 changes
Rem =========================================================================

Rem =========================================================================
Rem Begin ADO changes
Rem =========================================================================

alter table sys.ilm_executiondetails$ drop constraint fk_execdet;

alter table sys.ilm_results$ drop constraint fk_res;

alter table sys.ilm_result_stat$ drop constraint fk_resst;
 
alter table sys.ilm_dependant_obj$ drop constraint fk_depobj;

alter table sys.ilm_dependant_obj$ drop constraint fk_depobjjobn;

alter table sys.ilm_dep_executiondetails$ drop constraint fk_depdet;

alter table sys.ilm_dep_executiondetails$ drop constraint fk_depdetjobn;

alter table sys.ilm_results$ drop constraint pk_res;

alter table sys.ilm_execution$ drop constraint pk_taskid;

Rem Index on execution_id column of ilm_execution$. This index is replaced by
Rem the primark key constraint pk_taskid in later versions.

create index i_ilmexec_execid on ilm_execution$(execution_id)
tablespace SYSAUX
/

Rem Index on ilm_results$. This index is replaced by pk_res in later versions.
create index i_ilm_results$ on ilm_results$(jobname)
tablespace SYSAUX
/

Rem =========================================================================
Rem End ADO changes
Rem =========================================================================

Rem *************************************************************************
Rem Begin Bug 17637420: Clear tracking columns in SQL and error translation
Rem                     tables
Rem *************************************************************************

update sqltxl_sql$ set rtime = null, cinfo = null, module = null, action = null,
  puser# = null, pschema# = null, comment$ = null;


update sqltxl_err$ set rtime = null, comment$ = null;

commit;


Rem *************************************************************************
Rem End Bug 17637420
Rem *************************************************************************

Rem =======================================================================
Rem Bug 18165071 - Drop DBA_LOCK associated objects (catblock.sql) 
Rem =======================================================================
drop view DBA_LOCK;
drop public synonym DBA_LOCK;
drop public synonym DBA_LOCKS;
drop view DBA_LOCK_INTERNAL;
drop public synonym DBA_LOCK_INTERNAL;
drop view DBA_WAITERS;
drop public synonym DBA_WAITERS;
drop view DBA_BLOCKERS;
drop public synonym DBA_BLOCKERS;

Rem =======================================================================
Rem BEGIN changes for EM Express
Rem =======================================================================

drop procedure dbms_feature_emx;

drop public synonym v$emx_usage_stats;
drop view v_$emx_usage_stats;

drop public synonym gv$emx_usage_stats;
drop view gv_$emx_usage_stats;

Rem =======================================================================
Rem END changes for EM Express
Rem =======================================================================

Rem =======================================================================
Rem DBMS_QOPATCH bug 18219841
Rem =======================================================================
DROP PACKAGE BODY dbms_qopatch;
DROP PACKAGE dbms_qopatch;

Rem =======================================================================
Rem END changes for DBMS_QOPATCH
Rem =======================================================================

Rem BEGIN changes for REGISTRY objects
Rem =======================================================================

drop view dba_registry_error;
drop public synonym dba_registry_error;

drop view cdb_registry_error;
drop public synonym cdb_registry_error;

Rem =======================================================================
Rem END changes for REGISTRY objects
Rem =======================================================================

Rem *************************************************************************
Rem Begin Bug 17526652 17526621 revoke select_catalog_role
Rem *************************************************************************

begin
  execute immediate 'grant select on cdb_keepsizes to select_catalog_role';
  execute immediate 'grant select on cdb_analyze_objects to select_catalog_role';
exception when others then
  if sqlcode in (-1927, -942) then null;
  else raise;
  end if;
end;
/

Rem *************************************************************************
Rem End Bug 17526652 17526621
Rem *************************************************************************

Rem ********************************************************************
Rem Begin sys.ORACLE_LOADER: Make methods deterministic for Result Cache
Rem                        : Remove xtArgs argument from Open,Fetch,
Rem                          Populate,Close methods.
Rem ********************************************************************

-- Remove DETERMINISTIC from all the methods of ORACLE_LOADER type
-- by dropping and then recreating each of them without the DETERMINISTIC
-- annotation. (This approach is required for "upgrade" to 
-- work correctly.)
-- Also, remove the xtArgs attribute from each method by dropping and
-- and recreating each method WITHOUT the attibute.

ALTER TYPE sys.oracle_loader DROP 
  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT NOCOPY SYS.ODCIObjectList)
         RETURN NUMBER DETERMINISTIC;
ALTER TYPE sys.oracle_loader ADD 
  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT NOCOPY SYS.ODCIObjectList)
         RETURN NUMBER;

ALTER TYPE sys.oracle_loader DROP
  STATIC FUNCTION ODCIExtTableOpen(lctx   IN OUT NOCOPY oracle_loader,
                                   xti    IN            SYS.ODCIExtTableInfo,
                                   xri       OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl       OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag   IN OUT        number,
                                   strv   IN OUT        number,
                                   env    IN            SYS.ODCIEnv,
                                   xtArgs IN OUT        raw)
         RETURN number DETERMINISTIC;
ALTER TYPE sys.oracle_loader ADD
  STATIC FUNCTION ODCIExtTableOpen(lctx  IN OUT NOCOPY oracle_loader,
                                   xti   IN            SYS.ODCIExtTableInfo,
                                   xri      OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl      OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag  IN OUT        number,
                                   strv  IN OUT        number,
                                   env   IN            SYS.ODCIEnv)
         RETURN number;

ALTER TYPE sys.oracle_loader DROP
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv,
                                    xtArgs IN OUT raw)
         RETURN number DETERMINISTIC;
ALTER TYPE sys.oracle_loader ADD
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv)
         RETURN number;

ALTER TYPE sys.oracle_loader DROP
  MEMBER FUNCTION ODCIExtTablePopulate(flag   IN OUT number,
                                       env    IN     SYS.ODCIEnv,
                                       xtArgs IN OUT raw)
         RETURN number DETERMINISTIC;
ALTER TYPE sys.oracle_loader ADD
  MEMBER FUNCTION ODCIExtTablePopulate(flag IN OUT number,
                                       env  IN     SYS.ODCIEnv)
         RETURN number;

ALTER TYPE sys.oracle_loader DROP
  MEMBER FUNCTION ODCIExtTableClose(flag  IN OUT number,
                                    env   IN     SYS.ODCIEnv,
                                   xtArgs IN OUT raw)
         RETURN number DETERMINISTIC;
ALTER TYPE sys.oracle_loader ADD
  MEMBER FUNCTION ODCIExtTableClose(flag IN OUT number,
                                    env  IN     SYS.ODCIEnv)
         RETURN number;

Rem ********************************************************************
Rem End   sys.ORACLE_LOADER: Make methods deterministic for Result Cache
Rem ********************************************************************

Rem ********************************************************************
Rem Begin sys.ORACLE_DATAPUMP: Remove xtArgs argument from Open,Fetch,
Rem                            Populate,Close methods.
Rem ********************************************************************

-- Remove the xtArgs attribute from each method by dropping and
-- and recreating each method WITHOUT the attibute.

ALTER TYPE sys.oracle_datapump DROP
  STATIC FUNCTION ODCIExtTableOpen(lctx   IN OUT NOCOPY oracle_datapump,
                                   xti    IN            SYS.ODCIExtTableInfo,
                                   xri       OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl       OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag   IN OUT        number,
                                   strv   IN OUT        number,
                                   env    IN            SYS.ODCIEnv,
                                   xtArgs IN OUT        raw)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  STATIC FUNCTION ODCIExtTableOpen(lctx  IN OUT NOCOPY oracle_datapump,
                                   xti   IN            SYS.ODCIExtTableInfo,
                                   xri      OUT NOCOPY SYS.ODCIExtTableQCInfo,
                                   pcl      OUT NOCOPY SYS.ODCIColInfoList2,
                                   flag  IN OUT        number,
                                   strv  IN OUT        number,
                                   env   IN            SYS.ODCIEnv)
         RETURN number;

ALTER TYPE sys.oracle_datapump DROP
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv,
                                    xtArgs IN OUT raw)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  MEMBER FUNCTION ODCIExtTableFetch(gnum   IN     number,
                                    cnverr IN OUT number,
                                    flag   IN OUT number,
                                    env    IN     SYS.ODCIEnv)
         RETURN number;

ALTER TYPE sys.oracle_datapump DROP
  MEMBER FUNCTION ODCIExtTablePopulate(flag   IN OUT number,
                                       env    IN     SYS.ODCIEnv,
                                       xtArgs IN OUT raw)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  MEMBER FUNCTION ODCIExtTablePopulate(flag IN OUT number,
                                       env  IN     SYS.ODCIEnv)
         RETURN number;

ALTER TYPE sys.oracle_datapump DROP
  MEMBER FUNCTION ODCIExtTableClose(flag  IN OUT number,
                                    env   IN     SYS.ODCIEnv,
                                   xtArgs IN OUT raw)
         RETURN number;
ALTER TYPE sys.oracle_datapump ADD
  MEMBER FUNCTION ODCIExtTableClose(flag IN OUT number,
                                    env  IN     SYS.ODCIEnv)
         RETURN number;

Rem ********************************************************************
Rem End   sys.ORACLE_DATAPUMP: Remove xtArgs argument from Open,Fetch,
Rem                            Populate,Close methods.
Rem ********************************************************************

Rem ********************************************************************
Rem Begin sys.ORACLE_[BIGSQL,HDFS,HIVE]
Rem   Drop these new external table types which did not exist
Rem   prior to 12.1.0.1
Rem ********************************************************************

drop type sys.oracle_hive force;
drop type sys.oracle_hdfs force;
drop type sys.oracle_bigdata force;

Rem ********************************************************************
Rem End sys.ORACLE_[BIGSQL,HDFS,HIVE]
Rem ********************************************************************

Rem =======================================================================
Rem BEGIN Changes for pdb_sync$
Rem =======================================================================
truncate table pdb_sync$;

Rem =======================================================================
Rem  END Changes for pdb_sync$
Rem =======================================================================

Rem =======================================================================
Rem BEGIN Changes for pdb_inv_type$
Rem =======================================================================
truncate table pdb_inv_type$;
Rem =======================================================================
Rem  END Changes for pdb_inv_type$
Rem =======================================================================

Rem *************************************************************************
Rem 17971391: downgrade size of opbinding$.functionname
Rem *************************************************************************

alter table sys.opbinding$ modify functionname varchar2(92);

Rem *************************************************************************
Rem End 17971391
Rem *************************************************************************

Rem *************************************************************************
Rem 17537632: VALUE column for System table RECO_SCRIPT_PARAMS$ need to change
Rem           from CLOB datatype to varchar2(4000).
Rem           And for this during down-grade process, any existing records in
Rem           VALUE column will be copied to new column of varchar2(4000) type
Rem      NOTE:Data truncation possible as CLOB could be holding data which is
Rem           greater than 4K in size.
Rem *************************************************************************
ALTER TABLE reco_script_params$ ADD (TEMP varchar2(4000));
UPDATE reco_script_params$ SET TEMP = substr(VALUE, 1, 4000);
ALTER TABLE reco_script_params$ DROP COLUMN VALUE;
ALTER TABLE reco_script_params$ RENAME COLUMN TEMP to VALUE;

Rem *************************************************************************
Rem End 17537632
Rem *************************************************************************

Rem =======================================================================
Rem BEGIN Changes for [G]V$EVENT_HISTOGRAM_MICRO
Rem =======================================================================

drop public synonym gv$event_histogram_micro;
drop view gv_$event_histogram_micro;
drop public synonym v$event_histogram_micro;
drop view v_$event_histogram_micro;

Rem =======================================================================
Rem END Changes for [G]V$EVENT_HISTOGRAM_MICRO
Rem =======================================================================  


Rem *************************************************************************
Rem BEGIN 18774852, 17665117 & 17277459:
Rem Recreate the constraint on registry$sqlpatch to reflect original 12.1.0.1
Rem columns and drop the package and view.  The package and/or view will be
Rem recreated when catrelod is run in the downgraded database, and will not be
Rem invalid before we get there (because it does not exist).
Rem This allows the PDB plug in checks in the downgraded database to
Rem work properly.
Rem *************************************************************************
ALTER TABLE registry$sqlpatch DROP CONSTRAINT registry$sqlpatch_pk;
ALTER TABLE registry$sqlpatch ADD
  (CONSTRAINT registry$sqlpatch_pk
     PRIMARY KEY (patch_id, action, action_time));

Rem 19978542: Change bundle_data back to XMLType
BEGIN
  EXECUTE IMMEDIATE 'alter table registry$sqlpatch add (temp XMLType)';
  EXECUTE IMMEDIATE 
    'update registry$sqlpatch set temp = XMLType(bundle_data)';
  BEGIN
    EXECUTE IMMEDIATE 'alter table registry$sqlpatch drop column bundle_data';
  EXCEPTION
    WHEN OTHERS THEN
      IF sqlcode = -904 THEN
        null;
      ELSE
        raise;
      END IF;
  END;
  EXECUTE IMMEDIATE
   'alter table registry$sqlpatch rename column temp to bundle_data';
END;
/

DROP PACKAGE dbms_sqlpatch;	
DROP PUBLIC SYNONYM dbms_sqlpatch;

DROP VIEW dba_registry_sqlpatch;
DROP PUBLIC SYNONYM dba_registry_sqlpatch;

DROP VIEW cdb_registry_sqlpatch;
DROP PUBLIC SYNONYM CDB_registry_sqlpatch;

Rem *************************************************************************
Rem END 18774852, 17665117 & 17277459
Rem *************************************************************************

Rem =======================================================================
Rem Begin Changes for Oracle BigData Agent
Rem =======================================================================

drop package body sys.kubsagt;
drop package sys.kubsagt;
drop library kubsagt_lib;

Rem =======================================================================
Rem End Changes for Oracle BigData Agent
Rem =======================================================================

Rem =======================================================================
Rem BEGIN JSON views
Rem =======================================================================
drop view ALL_JSON_COLUMNS;
drop view USER_JSON_COLUMNS;
drop view CDB_JSON_COLUMNS;
drop view DBA_JSON_COLUMNS;
drop view INT$DBA_JSON_COLUMNS;
drop public synonym ALL_JSON_COLUMNS;
drop public synonym USER_JSON_COLUMNS;
drop public synonym CDB_JSON_COLUMNS;
drop public synonym DBA_JSON_COLUMNS;
Rem =======================================================================
Rem  END JSON views
Rem =======================================================================

Rem *************************************************************************
Rem Begin Bug 18459020 
Rem *************************************************************************
drop public synonym v$DIAG_DFW_PATCH_CAPTURE;
drop view v_$DIAG_DFW_PATCH_CAPTURE;
drop public synonym v$DIAG_DFW_PATCH_ITEM;
drop view v_$DIAG_DFW_PATCH_ITEM;
Rem *************************************************************************
Rem end of 18459020
Rem *************************************************************************

Rem =======================================================================
Rem BEGIN bug 18417322: set CDB_LOCAL_ADMINAUTH$.flags to 0
Rem =======================================================================

update cdb_local_adminauth$ set flags = 0
/

commit
/
  
Rem =======================================================================
Rem  END bug 18417322
Rem =======================================================================

Rem *************************************************************************
Rem bug 17446096: delete rows from adminauth$ in a non-CDB.
Rem *************************************************************************
delete from adminauth$ where sys_context('userenv', 'con_id') = 0
/

commit
/

Rem ********************************************************************
Rem End  17446096
Rem ********************************************************************

Rem *************************************************************************
Rem Begin Bug 17665104 add patch UID into opatch_inst_patch
Rem *************************************************************************

alter table opatch_inst_patch drop column patchUId;
Rem *************************************************************************
Rem end of 17665104
Rem *************************************************************************

Rem *************************************************************************
Rem bug 18756350: delete dbms_feature_ba_owner procedure.
Rem *************************************************************************
drop procedure dbms_feature_ba_owner;

Rem ********************************************************************
Rem End  18756350
Rem ********************************************************************

  
Rem *************************************************************************
Rem Resource Manager related changes - BEGIN
Rem *************************************************************************

-- Unfortunately, 12.1.0.1 code uses an insert without parameters. This
-- means that the old code cannot tolerate extra columns. So, these
-- columns need to be dropped rather than simply cleared for the
-- downgrade to work correctly. The server code has been modified so
-- that it tolerates the lack of columns, so it is safe to drop them.

alter table cdb_resource_plan_directive$ drop column memory_min;
alter table cdb_resource_plan_directive$ drop column memory_limit;
alter table cdb_resource_plan_directive$ drop column directive_type;

Rem *************************************************************************
Rem Resource Manager related changes - END
Rem *************************************************************************


@?/rdbms/admin/sqlsessend.sql

Rem *************************************************************************
Rem END   e1201000.sql
Rem *************************************************************************
