SET SERVEROUTPUT ON

REM Apply script for patch 21359755/19194568
DEFINE description = &1
DEFINE logfiledir = &2
DEFINE flags = &3
DEFINE bundle_series = &4

COLUMN sqlpatch_logfile NEW_VALUE full_logfile
SELECT '&logfiledir' || '21359755_apply_' ||
       CASE WHEN (sys_context('userenv', 'cdb_name') IS NULL) 
            THEN name
            ELSE name || '_' || replace(sys_context('userenv', 'con_name'), '$')
             END || TO_CHAR(systimestamp, '_YYYYMonDD_HH24_MI_SS') ||
                    '.log' AS sqlpatch_logfile
  FROM v$database;

SPOOL &full_logfile

SET PAGESIZE 0
SELECT 'Starting apply for patch 21359755/19194568 on ' ||
       SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

BEGIN
    dbms_sqlpatch.patch_initialize(p_patch_id      => 21359755,
                                   p_patch_uid     => 19194568,
                                   p_flags         => '&flags',
                                   p_description   => '&description',
                                   p_action        => 'APPLY',
                                   p_logfile       => '&full_logfile',
                                   p_bundle_series => '&bundle_series');
END;
/

COLUMN install_file NEW_VALUE sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/bug20876308_apply.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/bug20876308_apply.sql') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling olap/admin/xoqclnup.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: ORA-01432 ORA-00942 ORA-02289

SELECT dbms_sqlpatch.install_file('olap/admin/xoqclnup.sql') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/prvtpckl.plb on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/prvtpckl.plb') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/bug19532017_upgrade.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: ORA-00955

SELECT dbms_sqlpatch.install_file('rdbms/admin/bug19532017_upgrade.sql') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/prvtlmd.plb on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/prvtlmd.plb') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/prvtpexei.plb on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/prvtpexei.plb') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/prvtilm.plb on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/prvtilm.plb') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/utluppkg.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/utluppkg.sql') AS install_file
  FROM dual;
@@&sql_script



ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling olap/admin/bug20558005.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: ORA-04043

SELECT dbms_sqlpatch.install_file('olap/admin/bug20558005.sql') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/bug19587324.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/bug19587324.sql') AS install_file
  FROM dual;
@@&sql_script


ALTER SESSION SET CURRENT_SCHEMA = SYS;

SET PAGESIZE 0
SELECT 'Calling rdbms/admin/bug18909599.sql on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

PROMPT IGNORABLE ERRORS: NONE

SELECT dbms_sqlpatch.install_file('rdbms/admin/bug18909599.sql') AS install_file
  FROM dual;
@@&sql_script


BEGIN dbms_sqlpatch.patch_finalize; END;
/

SET PAGESIZE 0
SELECT 'Finished apply for patch 21359755/19194568 on' ||
       SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

SPOOL off

