# $Header: rdbms/admin/catctl.pl /st_rdbms_12.1.0.2.0dbpsu/3 2014/10/20 04:17:05 apfwkr Exp $
#
# $Header: rdbms/admin/catctl.pl /st_rdbms_12.1.0.2.0dbpsu/3 2014/10/20 04:17:05 apfwkr Exp $
#
# catctl.pl
# 
# Copyright (c) 2005, 2014, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      catctl.pl - Catalog Control Perl program
#
#    DESCRIPTION
#      This perl program processes sqlplus files and organizes
#      them for parallel processing based on annotations within
#      the files.
#
#      Below is the Basic Flow of upgrade.
#
#      Traditional Database
#
#         Run Database upgrade in parallel (-n option) passing in catupgrd.sql.
#             Minimum SQL process count is 1.
#             Maximum SQL process count is 8.
#             Default SQL process count is 4.
#         Run Post Upgrade Procedure.
#             If there are any errors in the upgrade the post
#             upgrade procedure will not run.
#             If the -x option is specified the post upgrade procedure
#             will not run.
#
#         1)  The database must be first started in upgrade mode
#             by the database adminstrator.
#         2)  After the upgrade completes the database is shutdown.
#         3)  The database is then restarted in restricted normal mode.
#         4)  Run the post upgrade procedure (catuppst.sql).
#         5)  Shutdown the database.
#
#      Multitenant Database (CDB)
#
#         Run Database upgrade in parallel (-n option) passing in catupgrd.sql.
#             Minimum SQL process count is 1.
#             Maximum SQL process count is 64.
#             Default SQL process count is 0.
#                 This is calculated by Number of Cpu's on your system.
#         Run Upgrade on CDB$ROOT.
#             The Maximum SQL process count is 8.
#             If there are any errors in the CDB$ROOT upgrade the
#             entire upgrade process is stopped.
#         Run Upgrades in all the PDB's.
#             The number of PDB's that run together is calculated by
#             dividing the SQL process count by 2.
#             Each individual PDB will use 2 for its SQL process count.
#             For example:
#             If the value of -n is set to 32.  32/2 yields 16
#             PDB's upgrading at the same time.
#             Each of those 16 PDB's use 2 for thier SQL
#             process count for a total of 32 SQL sessions that
#             running concurrently.
#             If the value of -N is set then the PDB's will use
#             this value for thier SQL process count instead of
#             the default 2.
#
#         If the -x option is specified the post upgrade procedure
#         will not run for all the CDB containers.  This option will
#         be ignored for the PDB$SEED only.  In this case we will force
#         the running of the post upgrade procedures (catuppst.sql and
#         utlprp.sql).  The number of threads that will run in utlprp.sql
#         is set equal to the SQL process count for the PDB's.
#
#         If there are any errors in the upgrade the post
#         upgrade procedure will not run for that specific container.
#
#         The below steps occur when updating and entire CDB.
# 
#         1)  The database and its PDB's must be first started in upgrade mode
#             by the database adminstrator.
#         2)  After the upgrade of CDB$ROOT completes the database is shutdown.
#         3)  The database is then restarted with CDB$ROOT opened in normal
#             mode.
#         4)  Post upgrade procedure (catuppst.sql) is run in CDB$ROOT.
#         5)  PDB's are re-opened in upgrade mode.
#         6)  Upgrade is performed on the PDB.
#         7)  PDB is then re-opened in normal restricted mode.
#         8)  Post upgrade procedure (catuppst.sql) is run in PDB.
#         9)  Shutdown the PDB.
#         10) After the entire upgrade completes only the CDB$ROOT
#             will remain open in case database administrators
#             wish to bring up an upgraded PDB to run utlrp.
#
#         Support for upgrading specific PDB's.
#
#         Options 'c' and 'C' are used for this purpose.
#
#         -c = Inclusion list
# 
#         This specifies which PDB's you wish to upgrade.
#         For example:
#
#         -c 'PDB1 PDB2'
#
#         This example will upgrade PDB1 and PDB2 only.
#
#         -C = Exclusion list
#
#         This specifies which PDB's you wish to exclude from the upgrade.
#         For Example:
#
#         -C = 'CDB$ROOT PDB$SEED'
#
#         This example will upgrade all the PDB's except CDB$ROOT and
#         PDB$SEED.
#
#         The flow of this processing is the same as above depending
#         on what the list contains in it. Examples are as follows.
#
#         CDB$ROOT steps 1-4 are performed.
#         PDB$SEED steps 5-10 are performed.
#         CDB$ROOT and PDB$SEED steps 1-10 are performed.
#         CDB$ROOT and PDB$SEED and PDB steps 1-10 are performed.
#         CDB$ROOT and PDB steps 1-10 are performed.
#         PDB$SEED and PDB steps 5-10 are performed.
#         PDB steps 5-10 are performed.
#
#      Annotations are the following within a .sql file(s):
#
#      --CATCTL -S
#         Run Sql in Serial Mode one Process
#      --CATCTL -M
#         Run Sql in Multiple Processes
#      --CATFILE -X
#         Sql contains multiprocessing
#      --CATCTL -R
#         Bounce the Sql Process
#      --CATCTL -CS
#         Turns Compile Off (Defaults to on)
#      --CATCTL -CE
#         Turns Compile On
#      --CATCTL -SES
#         Session files for phases
#      --CATCTL -SE
#        Run Sql in Serial Mode only executed in catctl.pl
#      --CATCTL -ME
#        Run Sql in Parallel Mode only executed in catctl.pl
#
#      In order to keep Sql dependencies in check catctl.pl enforces phases.
#      A phase is bunch of Sql files that are loaded into the database in
#      parallel (using multiple Sql Processes) or serial (utilizing just one
#      Sql Process).  Each phase must complete before proceeding
#      to the next phase.
#      
#
#    NOTES
#      Connects to database specified by ORACLE_SID environment variable
#
#    MODIFIED   (MM/DD/YY)
#    apfwkr      10/09/14 - Backport apfwkr_blr_backport_19050649_12.1.0.2.0
#                           from st_rdbms_12.1
#    apfwkr      08/26/14 - Backport surman_bug-19409212 from main
#    surman      07/29/14 - Backport surman_bug-19189317 from main
#    surman      07/21/14 - Backport surman_bug-19178851 from main
#    jerrede     09/05/14 - Remove shutting down PDB's before upgrading root.
#                           Failes if all PDB's are closed.  When
#                           I used force it worked but failed if I ctrl c out
#                           and restarted because pdb$seed was then put
#                           in mounted state.
#    apfwkr      09/04/14 - Backport jerrede_psu1 from main
#    jerrede     06/19/14 - Backport jerrede_bug-18969473 from main
#    surman      08/20/14 - 19409212: Quote root
#    surman      08/08/14 - 19390567: Fix sqlpatch command
#    surman      07/12/14 - 19178851: More library path variables
#    surman      07/10/14 - 19189317: Properly quote -pdbs
#    jerrede     08/19/14 - Bug 19050649 Psu Fixes
#                           Enable strict warnings, Create stack trace on
#                           a crash and ensure that stderr is written to
#                           the log files, Display Start/End Times, Shutdown
#                           Pdb's when upgrading root, Ignore down pdb's
#                           correctly, Fix Inclusion and Exclusion list
#                           displays.
#    surman      06/17/14 - 18986292: Set LD_LIBRARY_PATH
#    jerrede     06/06/14 - Backport jerrede_bug-18790704 from main
#    surman      06/05/14 - Backport surman_bug-17277459 from main
#    apfwkr      06/05/14 - Backport jerrede_bug_18721318 from main
#    apfwkr      06/02/14 - Backport jerrede_bug_18756451 from main
#    apfwkr      06/02/14 - Backprot jerrede_bug_18756451 from main
#    apfwkr      05/15/14 - Backport jerrede_bug-18687127 from main
#    apfwkr      05/12/14 - Backport jerrede_bug-18686614 from main
#    apfwkr      04/24/14 - Backport jerrede_bug-18617421 from main
#    apfwkr      04/16/14 - Backport jerrede_utlrpinseed from main
#    apfwkr      04/04/14 - Backport ewittenb_bug-18363959 from main
#    apfwkr      03/21/14 - Backport jerrede_ctldbg from main
#    apfwkr      03/14/14 - Backport sankejai_bug-18348157 from main
#    sankejai    03/11/14 - Bug 18348157: ignore ORA-24344 when opening PDB
#    apfwkr      03/11/14 - Backport jerrede_gtotal from main
#    surman      05/13/14 - 17277459: Call datapatch
#    jerrede     05/05/14 - Bug 18687127 Make sure root has been upgraded
#    jerrede     04/29/14 - When Parsing CDB lists ignore pdbs not in upgrade
#                           mode.  Also added additional checking for removing
#                           upgrade summary report.
#    jerrede     04/24/14 - Fix leaving PDB open when (-o) open mode specified 
#    jerrede     04/18/14 - Bug 18617421 Kick out Upgrade if CDB$ROOT not upgrade
#    jerrede     04/02/14 - Bug 18500239 Run utlprp in PDB$SEED
#    ewittenb    03/12/14 - fix bug 18363959
#    jerrede     03/11/14 - Bug 18369331 Open seed in read write restricted
#                           mode. Bug 18369292 Reorganize Total time display.
#    jerrede     03/05/14 - Add catctl.pl tracing.
#    jerrede     02/27/14 - Bug 18321633 After upgrade bring up the seed in
#                           read only mode.
#    jerrede     02/26/14 - Bug 18309547 Add Grand total to the end of report
#    jerrede     02/12/14 - Bug 18247889 Add option to upgrade entire
#                           Multitenant database in upgrade mode.  Allow
#                           no user access until all the containers have
#                           been upgraded.
#    jerrede     01/30/14 - Bug 18160117 Incorrectly Parsing Exclusion lists
#    jerrede     01/27/14 - Upgrade seed and pdb's together
#    jerrede     01/22/14 - Bug 17898118: Set PDB$SEED read/write for
#                           post upgrade.
#    jerrede     01/21/14 - Fix Boolean Expression
#    jerrede     01/17/14 - Fix Bug 18071399 Add Post Upgrade Report Time
#    jerrede     01/10/14 - Fix lrg 11214367 Open Database even if we are not
#                           doing post upgrade for CDB
#    jerrede     01/08/14 - Fix bug 18044666 Summary Report not displayed
#    talliu      01/15/13 - 14223369: catconInit interface change
#    jerrede     10/16/13 - Instances of catctl.pl
#    jerrede     10/15/13 - Bug 17550069: Pass Gui Flag to catcon
#    jerrede     10/02/13 - Performance Improvements bug 17551016.
#    jerrede     08/19/13 - Fix Bug 17209379 Row Lock Issue when updating table
#                           using -t qualifier and lrg 9527629.
#    jerrede     07/17/13 - Lrg 9410354 Remove Execute Immediate alter session
#                           for setting cdb root
#    jerrede     06/24/13 - Root First Upgrade
#    jerrede     06/21/13 - Add Display Args
#    jerrede     04/23/13 - Rewritten to use common catcon routines.
#    jerrede     01/14/13 - XbranchMerge jerrede_bug-16097914 from
#                           st_rdbms_12.1.0.1	
#    jerrede     01/10/13 - Ignore sqlsessstart and sqlsessend in driver files
#    jerrede     12/11/12 - xbranchmerge of jerrede_lrg-7343558	
#    jerrede     11/30/12 - Add Clearer Error Messages	
#    jerrede     11/06/12 - Add Display option for patch group	
#    bmccarth    10/30/12 - call utlucdir	
#    jerrede     10/16/12 - Fix lrg 7284666	
#    jerrede     10/11/12 - Fix Security bug 14750812	
#    jerrede     10/03/12 - Fix lrg 7291461	
#    jerrede     08/28/12 - Mandatory Post upgrade.	
#    jerrede     07/19/12 - Remove Passing Password at Command Line	
#                           Use /n\/n as the SQL Terminator for all	
#                           Sql Statements	
#    jerrede     05/24/12 - Add Display of SQL File Executing	
#    jerrede     10/18/11 - Parallel Upgrade ntt Changes	
#    jerrede     09/12/11 - Fix Bug 12959399	
#    jerrede     09/01/11 - Parallel Upgrade Project no 23496	
#    rburns      10/23/07 - remove multiple processes; fix password mgmt
#    rburns      10/20/06 - add session script	
#    rburns      12/16/05 - perl script for parallel sqlplus processing 
#    rburns      12/16/05 - Creation
# 
#
# TO DO:
#    ADD DEBUGGING INFO
#
######################################################################
# Include Package definitions 
######################################################################

use strict;
use warnings;
use English;
use Getopt::Std;             # To parse command line options
use threads;                 # Threads
use Cwd;                     # Get Current working directory
use File::Basename;          # Get Base File Name
use lib dirname (__FILE__);  # Add Dir Name of catctl.pl onto lib path
                             # So we can find catcon.pm in the event
                             # we are not running out of the same directory
use File::Spec;
use Fcntl qw(:flock);        # File Lock
use Carp qw(confess);        # For Stack trace

use catcon qw( catconInit
               catconExec
               catconWrapUp
               catconBounceProcesses
               catconRunSqlInEveryProcess
               catconShutdown
               catconIsCDB
               catconGetConNames
               catconQuery
               catconUpgEndSessions
               catconUpgStartSessions
               catconUserPass
               catconGetUsrPasswdEnvTag
               catconForce); #Common routines for cdb and upgrade

######################################################################
# Save Args before we process them
######################################################################
my @gArgs;
my $gArgsNo = 0;
foreach $gArgsNo (0 .. $#ARGV)
{
  push (@gArgs, $ARGV[$gArgsNo]);
}


######################################################################
# Check Arg's
######################################################################
if (@ARGV < 1) {
    printUsage();
}

######################################################################
# 
# printUsage 
#
# Description: prints the command line syntax and exits.
#
# Parameters:
#   - None
######################################################################
sub printUsage {
  print STDERR <<USAGE;

  Usage: catctl [-u username] [-n processes] [-d directory] 
                [-t table] [-l directory] [-s script] [-N PDB processes] 
                [-e] [-p startPhase] [-P endPhase] [-i identifier]
                [-c quotedSpaceSeparatedInclusionListOfPDBs] 
                [-C quotedSpaceSeparatedExclusionListOfPDBs] [-x] [-M] filename

  Supported Options:

     -u  username (prompts for password)
     -n  the number of processes to use for parallel operations
     -N  the number of processes to use for PDB parallel operations
     -d  directory containing the files to be run 
     -t  table name for phase logging
     -l  directory to use for spool log files
     -s  SQL script to initialize sessions
     -S  Serial Upgrade
     -M  CDB\$ROOT is set to upgrade mode while upgrading all containers
         If -M is unspecified then CDB\$ROOT defaults to normal mode
         while upgrading all containers
     -e  sets echo off while running the scripts
     -p  Start phase (skip successful phases on a rerun)
     -P  Stop phase (phase you want to stop on)
     -i  identifier to use when creating spool log files
     -c  Inclusion list of containers.  Run filename in the quoted,
         space separated argument list of containers only, omitting
         all other containers of the CDB. For example,
         Unix:
           -c 'PDB1 PDB2'
         Windows:
           -c "PDB1 PDB2"
         This switch is mutually exclusive with -C

     -C  Exclusion list of containers.  Run filename in all containers
         in the CDB, EXCEPT those explicitly listed in the quoted, space
         separated argument.  For example, 
         Unix:
           -C 'CDB\$ROOT PDB3'
         Windows:
           -C "CDB\$ROOT PDB3"
         This switch is mutually exclusive with -c

     -x  Postpone running the post upgrade procedure
     -y  display phases only
     -z  turns on production catcon.pm debugging info while running this script
     -Z  turns on catctl debug tracing while running this script. Set to number
         1 for debugging -Z 1
        
     filename top-level sqlplus script to run

USAGE
    exit 1;  # Error Get Out
}


######################################################################
# Global Variables and Constants
######################################################################

#
# Intialize Args
#
our $opt_u  = 0;
our $opt_n  = 0;
our $opt_N  = 0;
our $opt_d  = 0;
our $opt_t  = 0;
our $opt_l  = 0;
our $opt_s  = 0;
our $opt_S  = 0;
our $opt_M  = 0;
our $opt_f  = 0;
our $opt_p  = 0;
our $opt_P  = 0;
our $opt_e  = 1;  # Turn Echo on By Default
our $opt_a  = 0;
our $opt_x  = 0;
our $opt_r  = 0;
our $opt_o  = 0;
our $opt_i  = 0;
our $opt_I  = 0;
our $opt_y  = 0;
our $opt_z  = 0;
our $opt_Z  = 0;
our $opt_c  = 0;
our $opt_C  = 0;

#
# Constants
#
my $CATCTLVERSION = "12.1.0.2.0";
my $SINGLE      = 1;
my $MULTI       = 2;
my $TRUE        = 1;
my $FALSE       = 0;
my $NEXTPHASE   = $TRUE;      # Next Phase
my $NOCDBCONID  = 0;          # No CDB Con Id
my $READPFILE   = 1;
my $READERRORS  = 2;
my $PSTUPGNORUN    = 0;       # Don't Run Post Upgrade (-x option, No Pfile)
my $PSTUPGNOERR    = 1;       # Run Post Upgrade No Errors Occurred
my $PSTUPGWITHERR  = 2;       # Run Post Upgrade Check for Errors
my $MAXPROC_NO_CDB = 8;       # Max SQL Processes for Non-CDB
my $DEFPROC_NO_CDB = 4;       # Default SQL Processes for Non-CDB
my $DEFPROC_PDB    = 2;       # Default SQL Processes for PDB's
my $MAXPROC_PDB    = $MAXPROC_NO_CDB; # Max SQL Processes for PDB
my $MAXPROC_CDB    = 64;      # Max SQL Processes for CDB
my $MAXROOT_CDB = $MAXPROC_NO_CDB; # Max SQL Processes for Root and seed.
my $MINPROC        = 0;       # No SQL Processes specified (Use Def. values)
my $MINPDBINSTANCES  = 2;     # Min # of concurrent PDB upgrades
my $RUNROOTONLY      = 1;     # Run in Root Only
my $RUNEVERYWHERE    = 0;     # Run Everywhere
my $DBOPENNORMAL     = 1;     # Open Database In Normal Mode or Restricted Mode
my $DBOPENUPGPDB     = 2;     # Open Database Pdb's in upgrade mode
my $DBOPENROSEED     = 3;     # Reopen Seed Read only
my $DBOPENUPGSEED    = 4;     # Open Seed in upgrade mode
my $RESTART     = "ora_restart.sql";
my $LOADCOMPILEOFF = "ora_load_without_comp.sql";
my $LOADCOMPILEON  = "ora_load_with_comp.sql";
my $TWOSPACE    = "  ";
my $SPACE       = " ";
my $NOSPACE     = "";
my $SQLTERM     = "\n/\n";
my $NONE        = "NONE";
my $UNIXSLASH   = "/";
my $WINDOWSLASH = "\\";
my $SLASH       = $UNIXSLASH;
my $PWDSLASH    = $UNIXSLASH;
my $SINGLEQUOTE = "'";
my $DOUBLEQUOTE = "\"";
my $CONTAINERQUOTE  = $SINGLEQUOTE;
my $LOADWITHOUTCOMP = qq/ALTER SESSION SET "_LOAD_WITHOUT_COMPILE" = plsql;\n/;
my $LOADWITHCOMP    = qq/ALTER SESSION SET "_LOAD_WITHOUT_COMPILE" = none;\n/;
my $ORCLSCIPTFALSE  = qq/ALTER SESSION SET "_ORACLE_SCRIPT" = FALSE;\n/;
my $ORCLSCIPTTRUE   = qq/ALTER SESSION SET "_ORACLE_SCRIPT" = TRUE;\n/;
my $REGISTRYTBL       = "sys.registry\$";
my $REGISTRYTBLTAG    = $REGISTRYTBL;
my $INSTANCETBL       = "sys.v\$instance";
my $INSTANCETBLTAG    = $INSTANCETBL;
my $ERRORTABLE        = "sys.registry\$error";
my $ERRORTABLETAG     = $ERRORTABLE;
my $SUMMARYTBL        = "sys.registry\$upg_summary";
my $SUMMARYTBLTAG     = $SUMMARYTBL;
my $CDBROOT           = "CDB\$ROOT";
my $CDBROOTTAG        = $CDBROOT;
my $PDBSEED           = "PDB\$SEED";
my $PDBSEEDTAG        = $PDBSEED;
my $CDBSETROOT        = qq/ALTER SESSION SET CONTAINER = "$CDBROOT";\n/;
my $TIMEENDCPU        = qq/SELECT 'PHASE_TIME_CPUEND %proc ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') AS catctl_timestamp FROM SYS.DUAL;\n/;
my $COMMITCMD         = qq/COMMIT;\n/;       # Commit command
my $CATCTLTAG         = "--CATCTL";
my $CATCTLMTAG        = "-M";
my $CATCTLCSTAG       = "-CS";
my $CATCTLCETAG       = "-CE";
my $CATCTLSETAG       = "-SE";
my $CATCTLMETAG       = "-ME";
my $CATCTLRESTARTTAG  = "-R";
my $EOLTAG            = "EOL";
my $CONTAINERTAG      = "==== Current Container = "; # Container tag
my $CONTAINERIDTAG    = " Id = ";                # Container Id Tag
my $ENDCONTAINERTAG   = " ====";               # End Container tag
my $CATCONDSPTAG      = qq/select '$CONTAINERTAG' || SYS_CONTEXT('USERENV','CON_NAME') || '$CONTAINERIDTAG' || SYS_CONTEXT('USERENV','CON_ID') || '$ENDCONTAINERTAG' AS now_connected_to from sys.dual;\n/;
my $CATSQLDSPERR      = qq/select '** Post Upgrade Unable to run **' AS upgrade_error from sys.dual;\n/;
my $CATCTLATTAG       = "@";
my $CATCTLATATTAG     = "$CATCTLATTAG$CATCTLATTAG";
my $CATCTLCATFILETAG  = "--CATFILE";
my $CATCTLSESSIONTAG  = "-SES";
my $CATCTLERRORTAG    = "CATCTL ERROR COUNT=";    # Error Tag
my $CATCTLERRORTAGEND = "CATCTL END OF ERROR COUNT "; # Error Tag end
my $PFILETAG          = "CATCTL PFILE=";          # PFile Tag
my $CATCTLXTAG        = "-X";
my $SQLEXTNTAG        = ".sql";
my $ORA00001TAG       = "ORA-00001";              # Duplicated indexes
my $ORA00001TAGLEN    = length($ORA00001TAG);     # Tag Len
my $SELERR1           = 
    "SELECT count(distinct(substr(to_char(message),1,$ORA00001TAGLEN)))\n";
my $SELERR2           = " into cnt";
my $SELERR3           = " from $ERRORTABLE\n";
my $SELERR4           =
    " WHERE substr(to_char(message),1,$ORA00001TAGLEN) != '$ORA00001TAG'";
my $BANNERTAG         = "++++++++++++++++++++++++++++++++++++++++++++++++++++++";
my $LINETAG           = "------------------------------------------------------";
my $SERIAL            = "Serial  ";
my $PARALLEL          = "Parallel";
my $BOUNCE            = "Restart ";
my $DSPSECS           = "s";
my $DSPMINS           = "m";
my $DSPHRS            = "h";
my $DSPDAYS           = "d";
my $LASTRDBMSJOB      = "\@cmpupstr.sql";
my $LASTJOB           = "\@catupend.sql";
my $SHUTDOWNJOB       = "\@catshutdown.sql";
my $SHUTDOWNPDBJOB    = "\@catshutdownpdb.sql";
my $NOTHINGNAM        = "nothing.sql";
my $NOTHINGJOB        = "\@nothing.sql";
my $CATRESULTSJOB     = "\@catresults.sql";
my $POSTUPGRADEJOB    = "\@catuppst.sql";
my $UTLUCDIR          = "\@utlucdir.sql";
my $UTLUCDIRNAM       = "utlucdir.sql";
my $POSTUPGRADEDSP    = "catuppst.sql";
my $UTLPRPDSP         = "utlprp.sql";
my $CATUPGRADEARGS    = "--pPARALLEL=NO";  # Catupgrd Serial Argument
my $POSTUPGERRMSG     = "$POSTUPGRADEDSP unable to run in Database: ";
my $CONTAINERMSG      = "[CONTAINER NAMES]";
my $SESSIONSTARTSQL   = "sqlsessstart.sql";
my $SESSIONENDSQL     = "sqlsessend.sql";
my $CATCTLDBGENV      = 'CATCTLDEBUG';

#
# Constant Fatal Messages
#
my $MSGFUNEXPERR                = "Unexpected error encountered in";
my $MSGFINVARGS  = "\nRequired sqlplus script name (ie. catupgrd.sql) must be supplied\n";
my $MSGFCATCONINIT              = "\n$MSGFUNEXPERR catconInit; exiting\n";
my $MSGFCATCONEXEC              = "\n$MSGFUNEXPERR catconExec; exiting\n";
my $MSGFCATCONBOUNCEPROCESSES   = "\n$MSGFUNEXPERR catconBounceProcesses; exiting\n";
my $MSGFCATCONRUNSQLINEVERYPROC = "\n$MSGFUNEXPERR catconRunSqlInEveryProcess; exiting\n";
my $MSGFCATCONSHUTDOWN          = "\n$MSGFUNEXPERR catconShutdown; exiting\n";
my $MSGFCATCONISCDB             = "\n$MSGFUNEXPERR catconIsCDB; exiting\n";
my $MSGFCATCONGETCONNAMES = "\n$MSGFUNEXPERR catconGetConNames; exiting\n";
my $MSGFCATCONQUERY             = "\n$MSGFUNEXPERR catconQuery; exiting\n";
my $MSGFCATCTLREADLOGFILES = "\n$MSGFUNEXPERR catctlReadLogFiles; Can't Find Log File; exiting\n";
my $MSGFCATCTLDIED = "\n$MSGFUNEXPERR catctlMain; Error Stack Below; exiting\n";
my $MSGFCATCTLWRITELOGFILES = "\n$MSGFUNEXPERR catctlWriteStdErrMsgs; Can't Append Screen Messages to Log File; exiting\n";
my $MSGFCATCTLSETFILELOGFILES = "\n$MSGFUNEXPERR catctlSetLogFiles; Log file directory does not exist or is not writeable; exiting\n";
my $MSGFCATCTLSCANSQLFILES = "\n$MSGFUNEXPERR catctlScanSqlFiles; exiting Failed to open";
my $MSGFCATCTLREADFILES    = "\n$MSGFUNEXPERR catctlSetConnectStr; exiting Failed to open";
my $MSGFCATCTLSETFILENAMETOEXECUTE = "\n$MSGFUNEXPERR catctlSetFileNameToExecute; exiting Directory does not exist; exiting\n";
my $MSGFCATCTLCREATESQLFILE = "\n$MSGFUNEXPERR catctlCreateSqlFile; exiting Failed to open";
my $MSGFCATCTLCREATEDBGFILE = "\n$MSGFUNEXPERR catctlDebugTrace; Unexpected Error; exiting";
my $MSGFCATCTLCHECKERROR = "\n$MSGFUNEXPERR catctlCheckError; Unexpected Error; exiting";
my $MSGFBADSYNTAX = "Invalid command line syntax in the vicinity of";
my $MSGFCONTAINERLIST = "Container inclusion list is required with (-p -P) options\n".
                        "Only one inclusion item is allowed. Exclusion lists are not allowed.\n"; 
my $MSGFROOTINVALID = "$CDBROOTTAG is INVALID.\n".
 "Possible Reasons:\n".
 "    1) Version Number Mismatch between $REGISTRYTBLTAG and $INSTANCETBLTAG\n".
 "    2) $ERRORTABLETAG contains unresolved errors.\n".
 "Possible Solutions:\n".
 "    1) Upgrade the $CDBROOTTAG to the correct version.\n".
 "    2) Review errors in the $ERRORTABLETAG table.\n".
 "       For Example:\n".
 "           ALTER SESSION SET CONTAINER = $CDBROOTTAG;\n".
 "           @\$ORACLE_HOME/rdbms/admin/catresults.sql\n".
 "    3) Upgrade errors have been resolved in $CDBROOTTAG.\n".
 "       Delete the errors from the $ERRORTABLETAG table.\n".
 "       For Example:\n".
 "           ALTER SESSION SET CONTAINER = $CDBROOTTAG;\n".
 "           DELETE FROM $ERRORTABLETAG;\n".
 "           COMMIT;\n";
my $MSGFCANFINDPFILE = "Unable to locate Pfile to startup the database\n".
 "or errors found during the upgrade. Please check log files.\n\n".
 "To rerun just the post upgrade procedure specify the post upgrade phase.\n".
 "For example:\n    ".
 "\$ORACLE_HOME/perl/bin/perl catctl.pl -p <N> -P <N> catupgrd.sql\n".
 "In the above example $POSTUPGRADEDSP would run in phase <N>.  To obtain which\n".
 "phase the $POSTUPGRADEDSP is run in display the phases in the following manner:\n".
 "    \$ORACLE_HOME/perl/bin/perl catctl.pl -y catupgrd.sql\n".
 "Pick the phase number that runs $POSTUPGRADEDSP and use that\n".
 "phase number as the input into catctl.pl -p and -P options\n";
my $MSGFANOTHERPROCESS = "\n$MSGFUNEXPERR catctlGetOracleEnv; ".
                         "Exiting due to another upgrade process running.\n".
                         "Unable to lock file"; 
my $MSGFERROPENLOCKFILE = "\n$MSGFUNEXPERR catctlGetOracleEnv;\n".
                         "Unable to Open File"; 

#
# Constant Warning Messages
#
my $MSGWSCRIPTSFOUND     = "scripts found in file";
my $MSGWNOSCRIPTSFOUND   = "No $MSGWSCRIPTSFOUND";
my $MSGWNEXTPATH         = "Next path:";
my $MSGWLINENOTPROCESSED = "Line not processed:";
my $MSGWPMSG1 = "\n\n*** WARNING: ERRORS FOUND DURING UPGRADE ***\n\n";
my $MSGWPMSG2 = "Due to errors found during the upgrade process, the post\n";
my $MSGWPMSG3 = "upgrade actions in $POSTUPGRADEDSP have not been ";
my $MSGWPMSG4 = "automatically run.\n\n*** THEREFORE THE DATABASE UPGRADE";
my $MSGWPMSG5 = " IS NOT YET COMPLETE ***\n\n 1. Evaluate the errors found";
my $MSGWPMSG6 = " in the upgrade logs\n    and determine ";
my $MSGWPMSG7 = "the proper action.\n 2. Execute the post upgrade script ";
my $MSGWPMSG8 = "as described in Chapter 3\n    of the Database Upgrade Guide.\n\n";
my $MSGWPMSG9  = "$MSGWPMSG1$MSGWPMSG2$MSGWPMSG3$MSGWPMSG4";
my $MSGWPMSG10 = "$MSGWPMSG5$MSGWPMSG6$MSGWPMSG7$MSGWPMSG8";
my $MSGWMANUALPSTUPGRD = "$MSGWPMSG9$MSGWPMSG10";

#
# Constant Info Messages
#
my $MSGIVERSION       = "catctl.pl version: $CATCTLVERSION";
my $MSGIREPORT        = "Upgrade Summary Report Located in:";
my $MSGIPHASENO       = "Phase #:";
my $MSGITOTALTIME     = "Time: ";
my $MSGIGRANDTIME     = "Grand Total $MSGITOTALTIME";
my $MSGITOTALFILES    = "Files:";
my $MSGIDISP1         = "\n[phase";
my $MSGIDISP2         = "] type is";
my $MSGIDISP3         = "with";
my $MSGIDISP4         = "Files\n";
my $MSGIANALYZINGFILE = "\nAnalyzing file";
my $MSGIREVERSEODER   = "Running multiprocess phases in reverse order.\n";
my $MSGIUSING         = "Using";
my $MSGIPROCESSES     = "processes.\n";
my $MSGILOGFILES      = "Log files in";
my $MSGIRUNSERIAL     = "Running File In Serial Order FileName is";

# 17277459: Messages for printing datapatch output to log
my $MSGIDP_OUT_UPGRADE =
  "stdout from running datapatch to install upgrade SQL patches and PSUs:";
my $MSGIDP_ERR_UPGRADE =
  "stderr from running datapatch to install upgrade SQL patches and PSUs:";
my $MSGIDP_OUT_NORMAL =
  "stdout from running datapatch to install non-upgrade SQL patches and PSUs:";
my $MSGIDP_ERR_NORMAL =
  "stderr from running datapatch to install non-upgrade SQL patches and PSUs:";

#
# Booleans
#
my $gbLoadWithoutComp = $FALSE;
my $gbLoadWithComp    = $TRUE;
my $gbUpgrade         = $TRUE;   # Upgrade Run
my $gbFoundPfile      = $FALSE;  # Assume Pfile Not Found
my $gbCreatePfile     = $FALSE;  # Assume Pfile Not Created
my $gbUpgradeArgs     = $FALSE;  # Assume No Arguments
my $gbErrorFound      = $FALSE;  # Assume no Error Found
my $gbCdbDatabase     = $FALSE;  # Assume no CDB Database
my $gbShutDownCDB     = $FALSE;  # Did we shutdown the CDB once already
my $gbNotConnectMsg   = $FALSE;  # Display Oracle Not connect msg
my $gbRootProcessing  = $FALSE;  # Assume no Root Processing
my $gbSavRootProcessing = $FALSE;  # Assume no Root Processing
my $gbSeedProcessing  = $FALSE;  # Assume no Seed Processing
my $gbPdbProcessing   = $FALSE;  # Assume no Pdb  Processing
my $gbListProcessing  = $FALSE;  # Assume no Include and Exclude lists
my $gbStartStopPhase  = $FALSE;  # User gave a start or stop phase
my $gbRootOpenInUpgMode=$FALSE;  # Root Started In Migration Mode
my $gbWrapUp          = $FALSE;  # Call catconWrapUp
my $gbRestartDB       = $FALSE;  # Restart DB

#
# String Variables
#
my $gsLoadComp        = $LOADWITHCOMP;
my $gsPadChr          = $SPACE;
my $gsDspPhase        = $SERIAL;
my $gsCatconEnvTag    = "";
my $gsReportName      = ""; # Summary report name
my $gUserPass         = "";
my $gsPostUpgMsg      = ""; # Post Upgrade Message 
my $gsPath            = 0;
my $gsSpoolLog        = 0;  # Spool Log without Log Dir
my $gsSpoolLogDir     = 0;  # Log Dir plus Spool Log
my $gspFileName       = 0;  # Pfile Name
my $gsPostUpgCmds     = ""; # Post Upgrade Commands
my $gsPrintCmds       = ""; # STDERR Commands
my $gsNoInclusion;          # No Inclusions
my $gsNoIdentifier;         # No Identifier
my $gsNoExclusion;          # No Exclusion
my $gsRTInclusion     = ""; # Runtime Inclusions
my $gsRTExclusion     = ""; # Runtime Exclusions
my $gsRTIdentifier    = ""; # Runtime Exclusions
my $gsParsedInclusion = 0;  # Parsed Inclusion List for Containers
my $gsParsedExclusion = 0;  # Parsed Exclusion List for Containers
my $gsOracleEnv       = 0;  # Oracle Enviroment 
my $gsSelectErrors    = ""; # Sql Error Checking statement
my $gsTempDir         = ""; # Temp Directory
my $gsUpgLockFile     = ""; # Upgrade Lock File to prevent 2 upgrades on same DB
my $gsRptLockFile     = ""; # Report Lock File to prevent multiple writers 
my $gsDbName          = 0;  # Database Name
my $gsErrorMsg        = 0;  # Global Error Message

#
# File Handles
#
my $ghUpgLockFile;  # Upgrade Lock File Handle
my $ghRptLockFile;  # Report Lock File Handle

# Outputs from running datapatch in upgrade mode
my $gsDatapatchLogUpgrade = "";
my $gsDatapatchErrUpgrade = "";

# Outputs from running datapatch in normal mode
my $gsDatapatchLogNormal = "";
my $gsDatapatchErrNormal = "";

#
# Integer Variables
#
my $giStartPhase      = 0;  # User Input Start Phase
my $giStopPhase       = 0;  # User Input Stop  Phase
my $giStartPhaseNo    = 0;  # Calculated Start Phase
my $giStopPhaseNo     = 0;  # Calculated Stop  Phase
my $giEndPhaseNo      = 0;  # Calculated End Phase
my $giUseDir          = 0;
my $giProcess         = 0;  # Number of sql processors
my $giPdbProcess      = 0;  # Number of PDB sql processors
my $giCpus            = 0;  # Number of Cpu's
my $giPdbInstances    = 0;  # Number of PDB Instances
my $giph              = 0;
my $gidepth           = 0;  # degree of nested scripts (-X control)
my $giNumOfPhaseFiles = 0;  # Number of files in phase
my $giRetCode         = 0;
my $giLastNumOfPhaseFiles = 0;
my $giDelimiter1      = 0;
my $giDelimiter2      = 0;
my $giLastJob         = 0;  # Last Job Phase Number
my $giPostJob         = 0;  # Post Upgrade Phase Number
my $giCatResultsCnt   = 0;  # Catresults counter

#
# Date and time Variabes
#
my $gtLastTime        = time();
my $gtSTime           = 0;
my $gtSDifSec         = 0;
my $gtTotSec          = 0;

#
# Parse command line arguments
#
getopts("u:n:N:d:t:l:s:f:p:P:i:c:C:Z:eaxrozyISM");

#
#  Print out Arguments.
#
catctlPrintMsg ("\nArgument list for [$0]\n",$TRUE,$TRUE);
catctlPrintMsg ("SQL Process Count     n = $opt_n\n",$TRUE,$TRUE);
catctlPrintMsg ("SQL PDB Process Count N = $opt_N\n",$TRUE,$TRUE);
catctlPrintMsg ("Input Directory       d = $opt_d\n",$TRUE,$TRUE);
catctlPrintMsg ("Phase Logging Table   t = $opt_t\n",$TRUE,$TRUE);
catctlPrintMsg ("Log Dir               l = $opt_l\n",$TRUE,$TRUE);
catctlPrintMsg ("Script                s = $opt_s\n",$TRUE,$TRUE);
catctlPrintMsg ("Serial Run            S = $opt_S\n",$TRUE,$TRUE);
catctlPrintMsg ("Upgrade Mode active   M = $opt_M\n",$TRUE,$TRUE);
catctlPrintMsg ("Start Phase           p = $opt_p\n",$TRUE,$TRUE);
catctlPrintMsg ("End Phase             P = $opt_P\n",$TRUE,$TRUE);
catctlPrintMsg ("Log Id                i = $opt_i\n",$TRUE,$TRUE);
catctlPrintMsg ("Run in                c = $opt_c\n",$TRUE,$TRUE);
catctlPrintMsg ("Do not run in         C = $opt_C\n",$TRUE,$TRUE);
catctlPrintMsg ("Echo OFF              e = $opt_e\n",$TRUE,$TRUE);
catctlPrintMsg ("No Post Upgrade       x = $opt_x\n",$TRUE,$TRUE);
catctlPrintMsg ("Reverse Order         r = $opt_r\n",$TRUE,$TRUE);
catctlPrintMsg ("Open Mode Normal      o = $opt_o\n",$TRUE,$TRUE);
catctlPrintMsg ("Debug catcon.pm       z = $opt_z\n",$TRUE,$TRUE);
catctlPrintMsg ("Debug catctl.pl       Z = $opt_Z\n",$TRUE,$TRUE);
catctlPrintMsg ("Display Phases        y = $opt_y\n",$TRUE,$TRUE);
catctlPrintMsg ("Child Process         I = $opt_I\n",$TRUE,$TRUE);

#
#  Global Args
#
my $gUser             = $opt_u; # User
my $gSrcDir           = $opt_d; # Directory where scripts are located
my $gLogDir           = $opt_l; # Log File Directory
my $gTable            = $opt_t; # No-opt
my $gScript           = $opt_s; # User Session Init Script
my $gbDebugCatcon     = $opt_z; # Debug catcon
my $giDebugCatctl     = $opt_Z; # Debug catctl
my $gPwdFile          = $opt_f; # File
my $gbDBUA            = $opt_a; # DBUA flag
my $gbDisplayPhases   = $opt_y; # Display phases only
my $giPostUpgStat     = $opt_x; # Do not run Post upgrade catcon
my $gbByPassPostUpg   = $opt_x; # Do not run Post upgrade catcon
my $gbOpenModeNormal  = $opt_o; # Open Mode normal and leave database open
my $gIdentifier       = $opt_i; # Unique Identifier
my $gCInclusion       = $opt_c; # Cdb Inclusion Containers
my $gCExclusion       = $opt_C; # Cdb Exclusion Containers
my $gbInstance        = $opt_I; # Instance
my $gbSerialRun       = $opt_S; # Serial Run
my $gbUpgradeMode     = $opt_M; # CDB$ROOT is opened in upgrade mode


#
# Arguments
#
my $gsFile = $ARGV[0] or die "$MSGFINVARGS $!";
if (@ARGV > 1) {
    die "$MSGFBADSYNTAX '$ARGV[0]' or '$ARGV[1]'.  Exiting.\n";
}
 

#
#  Arrays
#

#
# SQL statements which need to be executed in every process before it runs 
# any scripts.  These statements may contain 0 or more instances of %proc 
# string which will be replaced with a process number.
#
my @PerProcInitStmts = ();

#
# SQL statements which need to be executed in every process after it finishes 
# running all scripts assigned to it. These statements may contain 0 or more 
# instances of %proc string which will be replaced with a process number.
#
my @PerProcEndStmts = ();
my @SqlAry;                   # Sql to be feed to each process
my @phase_type;               # Multi or single
my @phase_compile;            # Load with or without compile 
my @phase_files;              # References to file name array
my @phase_files_ro;           # Phase files in reverse order
my @session_files;            # Sql Session Files
my @session_phase;            # Sql Session Phase to start running in
my @files_to_delete;         # Files to delete
my @ContainerIds;             # Processed Containers
my @ContainerNames;           # Catcon Containers Names
my @AryParsedList;            # Inclusion Or Exclusion List array
my @AryPDBInstanceList;       # Inclusion Or Exclusion List array


#
# Initialize phases and scripts array
#
push (@phase_compile, $gbLoadWithComp); # Default first phase to compile on
push (@phase_type,    $SINGLE);         # Default first phase to single threaded
push (@phase_files,   []);              # Default a reference to an empty array
push (@phase_files_ro,[]);              # Default a reference to an empty array
push (@SqlAry,      $LOADWITHCOMP);     # Default to load with compile on
#push (@PerProcEndStmts, $TIMEENDCPU);  Track End time for CPU

####################################################################
# Start of MAIN Routine
####################################################################


    #
    # Trap Errors display and write to file
    #
    eval
    {
        local $SIG{__DIE__} = \&Carp::confess;
        catctlMain();
    };
    if ($@)
    {
        $gsErrorMsg = $MSGFCATCTLDIED."$@";
    }

    #
    # Check for Error. If found wrapup catcon
    # and write trace message 
    #
    if ($gsErrorMsg)
    {
        if ($gbWrapUp)
        {
            $gbWrapUp = $FALSE;
            catconWrapUp();
        }
        catctlWriteTraceMsg($gsErrorMsg);
    }

    #
    # Success
    #
    exit (0); 


####################################################################
# End of MAIN Routine
####################################################################

######################################################################
# 
# catctlMain - Main Routine for catctl.pl
#
# Description:
#   This is the main routine for catctl.
#
# Parameters:
#   - None
######################################################################
sub catctlMain
{

    #
    # Catctl Initialize
    #
    catctlInit();

    #
    # Log into the database
    #
    if (!$gbDisplayPhases)
    {   
        catctlLogon();
    }
    else
    {
        return (0); # Success
    }

    #
    # Run Serial or Parallel
    #
    if ($gbSerialRun)
    {
        #
        # Run command file from start to finish no phases
        #
        catctlRunSerial();
    }
    else
    {
        #
        # Run Phases for CDB and Non-cdb Database
        #
        catctlRunMainPhases();

        #
        # Run the PDB Upgrade Instances 
        #
        catctlRunPDBInstances($giPdbProcess);
    }

    #
    # End it
    #
    catctlEnd();

    return (0);
}

######################################################################
# 
# catctlCheckPostUpgrade - Check to see if we need to call the
#                          post upgrade procedure.
#
# Description:
#   Check to see if we should run the Post Upgrade.
#
# Parameters:
#   - phase number (IN)
#   - number phase files (IN)
#   - Inclusion list (IN)
#   - Exclusion list (IN)
# Returns:
#   - TRUE  = Move onto Next Phase if the following is true.
#                No files to process within phase.
#                Nothing.sql is the job (no opt).
#                Run the Upgrade summary report.
#     FALSE = Process this phase
#                This is not the post upgrade job.
#                Errors were found in the upgrade.
#
######################################################################
sub catctlCheckPostUpgrade
{
    my $phaseNo       = $_[0];   # Phase No
    my $phaseNoFiles  = $_[1];   # Number of Phase Files
    my $pInclusion    = $_[2];   # Inclusion List for Containers
    my $pExclusion    = $_[3];   # Exclusion List for Containers
    my $FIRSTTIME     = 1;       # First Time
    my $bRetStat      = $FALSE;
    my $TmpFileName   = 0;
    my $AtTmpFileName = 0;
    my $ErrMsg        = "";      # Error Message

    #
    # If no files to process then Next Phase
    #
    if ($phaseNoFiles == 0)
    {
        return($NEXTPHASE);
    }

    #
    # Do Nothing Next Phase
    #
    if ($phase_files[$phaseNo][0] eq $NOTHINGJOB)
    {
        return($NEXTPHASE);
    }

    #
    # Run Report Phase only if we are not running post upgrade
    # Otherwise we will run it right after catuppst.sql
    #
    if ($phase_files[$phaseNo][0] eq $CATRESULTSJOB)
    {
        #
        # Increment Counter
        #
        $giCatResultsCnt++;

        #
        # Check for Errors
        #
        if (!$gbErrorFound)
        {
            catctlLogErrors($pInclusion,
                            $pExclusion,
                            $gsNoIdentifier);
            $ErrMsg = catctlReadLogFiles($READERRORS);
        }

        #
        # To aviod running the upgrade summary report
        # twice since we may run it before or after
        # the post upgrade procedure. We will run it in
        # the following scenarios.
        # During Upgrade.
        #   Run if Errors are found
        #   Run if we are not running post upgrade procedure
        #   First Time will be TRUE.
        # During Post Upgrade.
        #   Skip running in upgrade and run after post upgrade
        #   procedure.
        #
        if ((!$gbErrorFound) &&
            ($giCatResultsCnt == $FIRSTTIME) &&
            (!$gbByPassPostUpg))
        {
            return($NEXTPHASE);
        }
        else
        {
            #
            # Get a lock before we run the report
            #
            catctlGetRptLockFile();
            return($bRetStat);
        }
    }

    #
    # Get out if not post upgrade job
    #
    if ($phase_files[$phaseNo][0] ne $POSTUPGRADEJOB)
    {
        return($bRetStat);
    }

    #
    # Close Report Lock files. We don't want
    # to hold it while running the post upgrade
    # Let it go after the report has run.
    # The close will release any locks held on the
    # file.  If catctl.pl crashes perl
    # will automatically release the lock.
    #
    if ($ghRptLockFile)
    {
        close ($ghRptLockFile);
        $ghRptLockFile = 0;
    }

    #
    # Setup for the Post Upgrade
    # If we are running the post upgrade
    # procedure only then just run in the
    # current opened database as instructed
    # by DBA and don't startup the database.
    #
    if ($giStartPhase != $phaseNo)
    {
        #
        # Setup for the Post Upgrade
        #
        if ($giPostUpgStat > $PSTUPGNORUN)
        {
            catctlPostUpgrade($pInclusion, $pExclusion, $DBOPENNORMAL);
        }

        #
        # Don't Run the Post Upgrade When errors are found
        #
        if ($gbErrorFound)
        {
            $giph = @phase_type;
            return($NEXTPHASE);
        }
    }


    #
    # 17277459: Call datapatch again in normal mode, this time to install any
    # remaining PSUs or bundles that did not require upgrade mode.
    #
    catctlDatapatch("normal");

    # Create Post Upgrade Commands File
    #
    $TmpFileName = catctlCreateSqlFile($gsPostUpgCmds,"catuppst");
    $AtTmpFileName = "\@".$TmpFileName;
    $phase_files[$phaseNo][0] = $AtTmpFileName;
    $giPostJob = $phaseNo;
    push (@files_to_delete, $TmpFileName);

    return($bRetStat);

} # End of catctlCheckPostUpgrade

######################################################################
# 
# catctlCheckShutdown - Calls Shutdown
#
# Description:
#   Check to see if we should Shutdown the database
#
# Parameters:
#   - phase number (IN)
#   - pInclusion   (IN) Inclusion List for Containers
#   - pExclusion   (IN) Exclusion List for Containers
# Returns:
#   - TRUE  = Move onto Next Phase
#     FALSE = Process this phase
#
######################################################################
sub catctlCheckShutdown
{
    my $phaseNo    = $_[0];       # Phase No
    my $pInclusion = $_[1];       # Inclusion List for Containers
    my $pExclusion = $_[2];       # Exclusion List for Containers
    my $bRetStat   = $FALSE;

    #
    # Shutdown pdb's.
    #
    if ($SHUTDOWNPDBJOB eq $phase_files[$phaseNo][0])
    {
        #
        # Shutdown pdb's
        #
        if ($gbCdbDatabase)
        {
            catctlShutDownDatabase($SHUTDOWNPDBJOB,
                                   $RUNEVERYWHERE,
                                   $pInclusion,
                                   $pExclusion);
        }
        return($NEXTPHASE);
    }

    #
    # Shutdown database.
    #
    if ($SHUTDOWNJOB eq $phase_files[$phaseNo][0])
    {
        #
        # Shutdown database.  In the CDB Case only
        # if we upgrading the root. 
        # 
        if ($gbCdbDatabase)
        {
            if ($gbRootProcessing)
            {
                #
                # Only shutdown the root once
                #
                if (!$gbShutDownCDB)
                {
                    #
                    # Close all session except one
                    #
                    $giRetCode = catconUpgEndSessions();

                    catctlShutDownDatabase($SHUTDOWNJOB,
                                           $RUNROOTONLY,
                                           $gsNoInclusion,
                                           $gsNoExclusion);
                    $gbShutDownCDB = $TRUE;
                }
            }
        }
        else
        {
            #
            # Close all session except one
            #
            $giRetCode = catconUpgEndSessions();

            catctlShutDownDatabase($SHUTDOWNJOB,
                                   $RUNROOTONLY,
                                   $gsNoInclusion,
                                   $gsNoExclusion);
        }
        return($NEXTPHASE);
    }


    return($bRetStat);
} # End of catctlCheckShutdown

######################################################################
# 
# catctlCheckRestartSqlProcesses - Check for Restarting SQL Processor
#
# Description - Check to see if we need to bounce the SQL Processors.
#
# Parameters:
#   - phase number (IN)
# Returns:
#   - TRUE  = Move onto Next Phase
#     FALSE = Process this phase
#
######################################################################
sub catctlCheckRestartSqlProcesses
{
    my $phaseNo  = $_[0];       # Phase No
    my $bRetStat = $FALSE;

    #
    # Restart Sql Process
    #
    if ($phase_files[$phaseNo][0] eq $RESTART)
    {
        $giRetCode = catconBounceProcesses();
        if ($giRetCode)
        {
            die "$MSGFCATCONBOUNCEPROCESSES $!";
        }
        return($NEXTPHASE);
    }

    return($bRetStat);
} # End of catctlCheckRestartSqlProcesses

######################################################################
# 
# catctlCheckRestartSqlProcesses - Check for loading compile option
#
# Description:
#   Check for loading with or without compiling.
#
# Parameters:
#   - phase number (IN)
# Returns:
#   - TRUE  = Move onto Next Phase
#     FALSE = Process this phase
#
######################################################################
sub catctlCheckLoadCompile
{
    my $phaseNo  = $_[0];       # Phase No
    my $bRetStat = $FALSE;


    #
    # No Opts for us just send the alter session command
    #
    if (($phase_files[$phaseNo][0] eq $LOADCOMPILEOFF) ||
        ($phase_files[$phaseNo][0] eq $LOADCOMPILEON))
    {
        return($NEXTPHASE);
    }

    return($bRetStat);
} # End of catctlCheckLoadCompile

######################################################################
# 
# catctlRunSerial - Run command in serially
#
# Description:
#   Does not break files into phase but just runs file as is.
#
# Parameters:
#   - None
# Returns:
#   - None
#
######################################################################
sub catctlRunSerial
{

    my @SqlArray;

    $giStartPhase = @phase_type;
    $gtLastTime = time();

    #
    # Display Serial inclusion if any take directly from user.
    #
    catctlPrintMsg(
        "PDB Serial Inclusion:[$gCInclusion] Exclusion:[$gCExclusion]\n",
         $TRUE,$TRUE);

    #
    # run all scripts in this phase single-threaded
    #
    catctlPrintMsg("$MSGIRUNSERIAL $gsPath\n",$TRUE,$TRUE);

    push (@SqlArray, "\@$gsPath");

    #
    # If upgrading add in parallel=no param
    #
    if ($gbUpgradeArgs)
    {
        push (@SqlArray, $CATUPGRADEARGS);
    }

    $giRetCode =
        catconExec(@SqlArray,
                   1,  # run single-threaded
                   0,  # run in every Container if the DB is Consolidated
                   0,  # Don't issue process init/completion statements
                   $gCInclusion,       # Inclusion list 
                   $gCExclusion,       # Exclusion List
                   $gsNoIdentifier);   # No SQL Identifier


    if ($giRetCode)
    {
        die "$MSGFCATCONEXEC $!";
    }

} # End of catctlRunSerial


######################################################################
# 
# catctlRunPhase - Run SQL Phase
#
# Description:
#   Run Sql Phase.
#
# Parameters:
#   - phase number (IN)
#   - Number of files in phase (IN)
#   - Inclusion List for Containers (IN)
#   - Exclusion List for Containers (IN)
#   - SQL identifier (IN)
# Returns:
#   - None
#
######################################################################
sub catctlRunPhase
{
    my $phaseNo         = $_[0];  # Phase No
    my $numOfPhaseFiles = $_[1];  # No of Phase Files
    my $pInclusion      = $_[2];  # Inclusion List for Containers
    my $pExclusion      = $_[3];  # Exclusion List for Containers
    my $SqlIdentifier   = $_[4];  # SQL Identifier

    #
    # Start Phase Info After shutdown only the
    # one process is active errors on all the
    # others.
    #
    catctlStartPhase($phaseNo,
                     $pInclusion,
                     $pExclusion);

    #
    # Check if the phase has some files to process
    #
    if ($numOfPhaseFiles > 0)
    {
        # Execute phase files
        catctlExecutePhaseFiles($phaseNo,
                                $numOfPhaseFiles,
                                $pInclusion,
                                $pExclusion,
                                $SqlIdentifier);
    }

    #
    # End Phase Info
    #
    catctlEndPhase($phaseNo,
                   $pInclusion,
                   $pExclusion);

} # End of catctlRunPhase

######################################################################
# 
# catctlRunPhases - Runs SQL Phases
#
# Description:
#   Runs Sql Phases. Driver routine for running all phases.
#
# Parameters:
#   - Starting phase no (IN)
#   - End phase no (IN)
#   - Inclusion List for Containers (IN)
#   - Exclusion List for Containers (IN)
#   - SQL identifier (IN)
# Returns:
#   - None
#
######################################################################
sub catctlRunPhases
{
    my $StartPhaseNo  = $_[0];     # Start Phase
    my $StopPhaseNo   = $_[1];     # Stop Phase
    my $DspStopPhaseNo = ($StopPhaseNo - 1); 
    my $pInclusion    = $_[2];     # Inclusion List for Containers
    my $pExclusion    = $_[3];     # Exclusion List for Containers
    my $SqlIdentifier = $_[4];     # SQL Identifier
    my $DateTime      = 0;         # Time Data
    my $pInc = $pInclusion ? $pInclusion : $NONE;
    my $pExc = $pExclusion ? $pExclusion : $NONE;
    my $CdbMsg = $gbCdbDatabase ? 
        "Container Lists Inclusion:[$pInc] Exclusion:[$pExc]\n" :
        "";

    #
    # Display Info To Screen
    #
    if ($StartPhaseNo < $StopPhaseNo)
    {
        $DateTime  = "        Start Time:[".catctlGetDateTime()."]";
        catctlPrintMsg("\n$LINETAG\n".
                       "Phases [$StartPhaseNo-$DspStopPhaseNo] $DateTime\n".
                       $CdbMsg.
                       "$LINETAG\n", $TRUE,$TRUE);
    }

    #
    # Loop Through the phases
    #
    for ($giph = $StartPhaseNo; $giph < $StopPhaseNo; $giph++)
    {
        #
        # Set Number of Files
        #
        $giNumOfPhaseFiles = @{$phase_files[$giph]};

        #
        # Check to see if we move onto the next phase
        #
        if (catctlCheckPostUpgrade($giph,
                                   $giNumOfPhaseFiles,
                                   $pInclusion,
                                   $pExclusion) == $NEXTPHASE)
        {
            next;
        }

        #
        # Display Info To Screen
        #
        catctlDisplayPhaseInfo($giph,
                               $giNumOfPhaseFiles,
                               $pInclusion,
                               $pExclusion);

        #
        # Check For Shutdown
        #
        if (catctlCheckShutdown($giph, $pInclusion, $pExclusion) == $NEXTPHASE)
        {
            next;
        }

        #
        # Check For Restart Sql Processes
        #
        if (catctlCheckRestartSqlProcesses($giph) == $NEXTPHASE)
        {
            next;
        }

        #
        # Check Loading with Compile on or off
        #
        if (catctlCheckLoadCompile($giph) == $NEXTPHASE)
        {
            next;
        }

        catctlRunPhase($giph,
                       $giNumOfPhaseFiles,
                       $pInclusion,
                       $pExclusion,
                       $SqlIdentifier);
    }

    #
    # Collect Timings
    #
    $gtSTime   = time();
    $gtSDifSec = $gtSTime  - $gtLastTime;
    $gtTotSec  = $gtTotSec + $gtSDifSec;
    catctlPrintMsg("    $MSGITOTALTIME$gtSDifSec$DSPSECS    $gsRTInclusion\n",
                   $TRUE,$TRUE);
    $gtLastTime = time();

   #
   # Display Info To Screen
   #
   if ($StartPhaseNo < $StopPhaseNo)
   {
       $DateTime  = "        End Time:[".catctlGetDateTime()."]";
       catctlPrintMsg("\n$LINETAG\n".
                      "Phases [$StartPhaseNo-$DspStopPhaseNo] $DateTime\n".
                      $CdbMsg.
                      "$LINETAG\n", $TRUE,$TRUE);
   }


} # End of catctlRunPhases

######################################################################
# 
# catctlRunMainPhases - Runs Root Phases and non-cdb phases 
#
# Description:
#   This routine runs the Root or Non-cdb phases 
#
# Parameters:
#   - None
# Returns:
#   - None
#
######################################################################
sub catctlRunMainPhases
{

    #
    # If we are not processing the root and this is not
    # an instance then get out
    #
    if ($gbCdbDatabase)
    {
       if ((!$gbRootProcessing) && (!$gbInstance))
       {
           return;
       }

       #
       # Process the root only
       #
       if ($gbRootProcessing)
       {
           #
           # Problems when shutting down Pdb's
           # Ctrl C and Restarting upgrade leaves
           # pdb$seed in mounted state.
           # Double catconForce above works around
           # the original problem where catcon
           # would kick us out saying closed pdb
           # was invalid.
           #
           #catctlShutDownDatabase($SHUTDOWNJOB,
           #                       $RUNEVERYWHERE,
           #                       $gsNoInclusion,
           #                       $CDBROOT);
           $gsRTInclusion = $CDBROOT;
           $gsRTExclusion = $gsNoExclusion;
       }
    }

    #
    # Run the phases For CDB Root or Non-CDB Database
    #
    $giLastJob    = @phase_type;
    $giEndPhaseNo = $giStopPhase ? ($giStopPhase+1) : $giLastJob;
    catctlRunPhases($giStartPhase,
                    $giEndPhaseNo,
                    $gsRTInclusion,
                    $gsRTExclusion,
                    $gsRTIdentifier);

    #
    # If we are processing root and user specified
    # Not to Run Post upgrade we still need to reopen the
    # database and process the Pdb's
    #
    if (($gbRootProcessing) && 
        ($gbByPassPostUpg)  &&
        (($gbSeedProcessing) ||
         ($gbPdbProcessing)))
    {
        $gbRestartDB   = $TRUE;
    }
    else
    {
        #
        # Set Root Processing False
        #
        $gbRootProcessing = $FALSE;
    }
}

######################################################################
# 
# catctlRunPDBInstances - Runs PDB Instances 
#
# Description:
#   This routine runs the PDB upgrade in a separate catctl.pl instance. 
#
# Parameters:
#   Input: PDB Process Count.
#
# Returns:
#   - None
#
######################################################################
sub catctlRunPDBInstances
{
    my $pPdbProcess = $_[0]; # PDB Process count
    my $ErrMsg      = "";    # Error Message

    #
    # Get out if we are already running a PDB Instance
    #
    if ($gbInstance)
    {
        return;
    }

    #
    # Only Do for CDB databases and when
    # No Start and Stop phases have been
    # specified.
    #
    if (($gbCdbDatabase    == $FALSE) ||
        ($gbErrorFound     == $TRUE))
    {
        return;
    }


    #
    # Troll Log Files for errors
    #
    $ErrMsg = catctlReadLogFiles($READERRORS);

    #
    # If Errors found get out.
    #
    if ($gbErrorFound     == $TRUE)
    {
        return;
    }

    #
    # Startup Database in Normal Mode
    #
    if ($gbRestartDB)
    {
        $gsRTInclusion    = $CDBROOT;
        $gsRTExclusion    = $gsNoExclusion;
        catctlStartDatabase($gsRTInclusion,$gsRTExclusion,$DBOPENNORMAL);
        $gbRootProcessing = $FALSE;
        $gbRestartDB      = $FALSE;
    }

    #
    # Reset Inclusion/Exclusion lists back to the PDB's
    #
    $gsRTInclusion = $gsParsedInclusion;
    $gsRTExclusion = $gsParsedExclusion;

    #
    # Startup the Instances
    #
    catctlStartPdbInstances($pPdbProcess);

} # End of catctlRunPDBInstances

######################################################################
# 
# catctlStartPdbInstances - Start PDB Instances          
#
# Description:
#
#   This starts the PDB instances that runs Parallel within a PDB.
#
# Parameters:
#   Input: PDB Process Count.
#
# Returns:
#   - None
#
######################################################################
sub catctlStartPdbInstances
{
    my  $pPdbProcess =  $_[0]; # PDB Process count
    my  $CatctlArgs = ""; # Construct Catctl Command
    my  $argno = 0;
    my  $argcnt = $#gArgs;
    my  $argloop = ($argcnt -1);
    my  $tmp = "";
    my  $bIgnore = $FALSE;
    my  @threads;
    my  $PdbItem;
    my  $PdbFileName;
    my  $CatctlProgram = $^X." ".$0;


    #
    # Set up communications with catcon
    #
    if ($gUser)
    {
        $gsCatconEnvTag = catconGetUsrPasswdEnvTag(); 
        $gUserPass = catconUserPass();
        $ENV{$gsCatconEnvTag} = $gUserPass;
    }

    #
    # Startup the PDB's in upgrade mode
    #
    foreach $PdbItem (@AryPDBInstanceList)
    {
        #
        # Contruct base filename by replacing
        # illegal character with _
        #
        $PdbFileName = lc($PdbItem);
        $PdbFileName =~ s/\W/_/g;

        #
        # Open pdb for upgrade
        #
        if ($PdbItem ne $PDBSEEDTAG)
        {
            #
            # Open the pdb container in upgrade mode
            #
            catctlStartDatabase($PdbItem,
                                $gsNoExclusion,
                                $DBOPENUPGPDB);
        }
        else
        {
            #
            # Open Seed container in upgrade mode
            #
            catctlStartDatabase($PdbItem,
                                $gsNoExclusion,
                                $DBOPENUPGSEED);
        }
    }

    #
    # Close all sessions except one. PDB's will start there own.
    #
    $giRetCode = catconUpgEndSessions();

    #
    # Wrap up sessions in master catctl controller we are done.
    #
    catconWrapUp();
    $gbWrapUp = $FALSE;

    foreach $PdbItem (@AryPDBInstanceList)
    {
        #
        # Initialize for each PDB
        #
        $bIgnore    = $FALSE;
        $tmp        = "";
        $CatctlArgs = "";

        #
        # Contruct base filename by replacing
        # illegal character with _
        #
        $PdbFileName = lc($PdbItem);
        $PdbFileName =~ s/\W/_/g;


        #
        # Construct the PDB instance by
        # re-assembling the command
        #
        foreach $argno (0 .. $argloop)
        {
            #
            # Skip Next Arg
            #
            if ($bIgnore)
            {
                $bIgnore = $FALSE;
                next;
            }

            #
            # Take Arg by default
            #
            $tmp = " ".$gArgs[$argno];

            #
            # Contruct base file name
            #
            if ($gArgs[$argno] eq "-i")
            {
                $bIgnore = $TRUE;
                $tmp = " -i "."$gArgs[$argno+1]"."$PdbFileName";
            }

            #
            # Set Process count equal to Pdb Process count
            #
            if ($gArgs[$argno] eq "-n")
            {
                $bIgnore = $TRUE;
                $tmp = " -n $pPdbProcess";
            }

            #
            # Set Inclusion Container
            #
            if ($gArgs[$argno] eq "-c")
            {
                $bIgnore = $TRUE;
                $tmp = " -c ".$CONTAINERQUOTE.$PdbItem.$CONTAINERQUOTE;
            }

            #
            # Ignore Exclusion Container
            #
            if ($gArgs[$argno] eq "-C")
            {
                $bIgnore = $TRUE;
                $tmp = "";
            }

            #
            # Concat the command
            #
            $CatctlArgs = $CatctlArgs.$tmp;
            $tmp = "";

            #
            # Call Child in debug mode
            #
            if ($gArgs[$argno] eq "-Z")
            {
                $CatctlProgram = $^X." -d ".$0;
            }

        } # End foreach arg

        #
        # Identify myself as a PDB Instance
        #
        $CatctlArgs = $CatctlArgs." -I";

        #
        # Set Base Filename
        #
        if (!$opt_i)
        {
            $CatctlArgs = $CatctlArgs." -i $PdbFileName";
        }

        #
        # Set process count equal to PDB Process count
        #
        if (!$opt_n)
        {
            $CatctlArgs = $CatctlArgs." -n $pPdbProcess";
        }

        #
        # Set Inclusion PDB
        #
        if (!$opt_c)
        {
            $CatctlArgs = $CatctlArgs." -c '$PdbItem'";
        }

        #
        # Add Filename to execute in PDB
        #
        $CatctlArgs = $CatctlArgs." ".$gArgs[$argcnt];

        #
        # Now start the instance in a thread
        #
        push(@threads,
             threads->create (\&catctlProcessInstance,
                              $CatctlProgram, $CatctlArgs, $PdbItem));
        #
        # Limit threads running
        #
        sleep(1) while(scalar threads->list(threads::running) >= $giPdbInstances);

    } # End foreach pdbitem 

    #
    # Thread cleanup
    #
    foreach (threads->list()) { $_->join(); }
    delete $ENV{$gsCatconEnvTag};

} # end of catctlStartPdbInstances

######################################################################
# 
# catctlEnd - Catctl Ending statements         
#
# Description:
#
#   This is the final statements run in the perl script.
#
# Parameters:
#
#
# Returns:
#   - None
#
######################################################################
sub catctlEnd
{
    my $RtDisplay = "";
    my $ErrMsg    = "";      # Error Message
    my $bWriteMsg = $TRUE;   # Write messages
    my $PostMsg   = "\n";    # Post Message
    my $RptName   = "\n";    # Report Name

    #
    # Read Error log to get Report Name and Error Messages
    #
    $ErrMsg = catctlReadLogFiles($READERRORS);
    if ($ErrMsg)
    {
        $gsPostUpgMsg = $gsPostUpgMsg.$ErrMsg;
    }

    #
    # Bring up the PDB$SEED database
    #
    if (($gbInstance)    &&
        ($gbSeedProcessing))
    {
        #
        # Defaults to opening pdb$seed container in read-only mode.
        # If errors are found during the upgrade of the pdb$seed
        # container then open the pdb$seed in upgrade mode.
        #
        if ($gbErrorFound)
        {
            catctlStartDatabase($PDBSEED,
                                $gsNoExclusion,
                                $DBOPENUPGPDB);
        }
        else
        {
            catctlStartDatabase($PDBSEED,
                                $gsNoExclusion,
                                $DBOPENROSEED);
        }
    }

    #
    # Collect Timings
    #
    $gtSTime   = time();
    $gtSDifSec = $gtSTime  - $gtLastTime;
    $gtTotSec  = $gtTotSec + $gtSDifSec;

    #
    # Calculate ROOT and Pdb Times
    #
    if (($gbCdbDatabase) && (!$gbInstance))
    {
        $gtSTime   = $gtTotSec - $gtSDifSec;
        catctlPrintMsg("\n", $TRUE,$TRUE);
        if ($gbSavRootProcessing)
        {
            catctlPrintMsg(
                  "     $MSGITOTALTIME$gtSTime$DSPSECS For $CDBROOT\n",
                  $TRUE,$TRUE);
        }
        if ($gbPdbProcessing)
        {
            catctlPrintMsg(
                  "     $MSGITOTALTIME$gtSDifSec$DSPSECS For PDB(s)\n",
                  $TRUE,$TRUE);
        }

    }

    #
    # Display PDB
    #
    if ($gbInstance)
    {
        $RtDisplay = $gsRTInclusion;
    }
    catctlPrintMsg("\n$MSGIGRANDTIME$gtTotSec$DSPSECS $RtDisplay\n",$TRUE,$TRUE);


    #
    # Display Post Upgrade Message and summary report name
    #
    if ($gbUpgrade)
    {

        #
        # Don't Display messages if this is cdb database
        # and we are not processing the root.  The instances
        # will display the messages to the user.
        #
        if (($gbCdbDatabase) && 
            (!$gbInstance)   &&
            (!$gbSavRootProcessing))
        {
            $bWriteMsg = $FALSE;
        }

        #
        # Display Post Upgrade Message
        #
        if ($giPostUpgStat == $PSTUPGWITHERR)
        {
            if ($bWriteMsg)
            {
                $PostMsg = "\n$MSGWMANUALPSTUPGRD \nREASON:\n$gsPostUpgMsg\n";
            }
        }
        if ($giPostUpgStat == $PSTUPGNORUN)
        {
            if ($bWriteMsg)
            {
                $PostMsg = "\n$POSTUPGERRMSG \nREASON:\n$gsPostUpgMsg\n";
            }
        }

        catctlPrintMsg($PostMsg, $TRUE,$TRUE);
        catctlPrintMsg("LOG FILES: ($gsSpoolLog*.log)\n",$TRUE,$TRUE);

        if ($gsReportName)
        {
            if ($bWriteMsg)
            {
                $RptName = "\n$MSGIREPORT\n$gsReportName\n";
            }
            catctlPrintMsg($RptName,$TRUE,$TRUE);
        }
    }

    #
    # That's a wrap
    #
    if ($gbWrapUp)
    {
        catconWrapUp();
    }
    catctlCleanUp();
    catctlWriteStdErrMsgs();

}  # end of catctlEnd


######################################################################
# 
# catctlProcessInstance - Process PDB instances in a thread          
#
# Description:
#
#   This starts the PDB instance in a thread and waits till completion.
#
# Parameters:
#
# Returns:
#   - None
#
######################################################################
sub catctlProcessInstance($$)
{
    my ($pCatctlProgram,$pCatctlArgs,$pPdbItem) = @_;
    
    #
    #
    #
    catctlPrintMsg ("\nStart processing of $pPdbItem\n",1,1);
    catctlPrintMsg ("[$pCatctlProgram$pCatctlArgs]\n",1,1);

    #
    # Call system to execute the command and wait
    # Trap any errors and warn user of the error.
    # We can't die here because we want the other
    # PDB's to run
    #
    eval { system("$pCatctlProgram$pCatctlArgs") };
    if ($@)
    {
        catctlPrintMsg ("\nError Executing $@\n[$pCatctlProgram$pCatctlArgs for $pPdbItem]\n",
                         1,1);
        warn();
    }

    threads->exit(0);

} # End of catctlProcessInstance


######################################################################
# 
# catctlLogon - Logon onto the database
#
# Description:
#   Logs into the database and sets global inclusion and exclusion fields
#
# Parameters:
#   - None
######################################################################
sub catctlLogon
{

    #
    # Upper Case Lists
    #
    if ($gCInclusion)
    {
        $gCInclusion = uc($gCInclusion);
    }
    if ($gCExclusion)
    {
        $gCExclusion = uc($gCExclusion);
    }

    #
    # Continue to process PDB's if one PDB is closed
    #
    catconForce($TRUE);

    #
    # Login, setup Sql processors etc...
    #
    $giRetCode =
        catconInit($gUser,            # UserName and Password
                   undef,             # UserName and Password
                   $gSrcDir,          # Script directory
                   $gLogDir,          # Log directory
                   $gsSpoolLog,       # Base of spool log file name
                   $gCInclusion,      # Container names included
                   $gCExclusion,      # Container names excluded
                   $giProcess,        # Processes
                   0,                 # Simultaneous invocations
                   $opt_e,            # Echo on or off
                   undef,             # Spool On
                   $giDelimiter1,     # regular argument delimiter
                   $giDelimiter2,     # secret argument delimiter
                   $ERRORTABLE,       # Error Logging
                   1,                 # Turn off setting Error Logging Id
                   @PerProcInitStmts, # Init statements per process
                   @PerProcEndStmts,  # End statements per process
                   0,                 # PDB$SEED will not be re-opened
                   $gbDebugCatcon,    # Debugging flag
                   $gbDBUA,           # Dbua Flag
                   0);                # cdb_sqlexec flag

    if ($giRetCode)
    {
        die "$MSGFCATCONINIT $!";
    }

    #
    # Continue to process PDB's if one PDB is closed
    #
    catconForce($TRUE);


    #
    # Wrap up can now be called
    #
    $gbWrapUp = $TRUE;

    #
    # Get Upgrade Lock File
    #
    catctlGetUpgLockFile();


    #
    # Set Calculated Threads Based in Cores
    #
    $giCpus = catctlGetCpus();
    $giPdbProcess = catctlSetPDBProcessLimits($giPdbProcess);
    $giProcess = catctlSetProcessLimits($giCpus, $giProcess);

    #
    # Clean out Summary report if found
    #
    if (($gbUpgrade) && (!$gbInstance))
    { 
        catctlSearchForReport($gsOracleEnv);
    }


    if (catconIsCDB())
    {
        catctlSetCDBLists();
    }

    #
    # Set up the post upgrade commands
    #
    $gsPostUpgCmds = $CATCONDSPTAG.
        "VARIABLE catuppst_name VARCHAR2(256)\n".
        "COLUMN  :catuppst_name NEW_VALUE catuppst_file NOPRINT\n".
        "VARIABLE utlrp_name VARCHAR2(256)\n".
        "COLUMN  :utlrp_name NEW_VALUE utlrp_file NOPRINT\n".
        "DECLARE\n".
        "cnt         NUMBER:=0;\n".
        "BEGIN\n".
        ":catuppst_name := '$POSTUPGRADEDSP';\n".
        ":utlrp_name    := '$UTLPRPDSP $giPdbProcess';\n".
        $gsSelectErrors.
        "IF cnt > 0 THEN\n".
        " :catuppst_name := dbms_registry.nothing_script;\n".
        " :utlrp_name    := dbms_registry.nothing_script;\n".
        "END IF;\n".
        "END;".$SQLTERM;

    $gsPostUpgCmds = $gsPostUpgCmds."SELECT :catuppst_name FROM sys.dual;\n".
                     "@@&catuppst_file\n";

    #
    #  If this is the PDB$SEED we also run utlprp. This recompiles any
    #  procedure that is mark as invalid.  We want to avoid any customer
    #  interaction with the PDB$SEED.  We force the running of both
    #  catuppst and utlprp by setting the global $gbByPassPostUpg switch
    #  to FALSE.  This overrides the -x option.  In the DBUA case they
    #  will no longer run catuppst and utlprp post upgrade operations for
    #  the PDB$SEED.  We will do it for them.  The process count allocated to
    #  pdb ($giPdbProcess) is used as the input into utlprp. This way pdb$seed
    #  won't hog all the resources while running the recompilation phase
    #  but only use the resources that have been allocated to it.
    #
    if (($gbSeedProcessing) && ($gbInstance))
    {
       $gsPostUpgCmds = $gsPostUpgCmds.
          "SET ERRORLOGGING ON TABLE $ERRORTABLE IDENTIFIER 'UTLRP';\n".
          "SELECT :utlrp_name FROM sys.dual;\n".
          "@@&utlrp_file\n";
       $gbByPassPostUpg = $FALSE;
    }

    #
    # Set Post Upgrade Message
    #
    if ($gbByPassPostUpg)
    {
       $gsPostUpgMsg = $gsPostUpgMsg.
           "$POSTUPGRADEDSP unable to run -x option has been turned on\n";
       $giPostUpgStat = $PSTUPGNORUN;
    }
    else
    {
       $giPostUpgStat = $PSTUPGNOERR;
    }

} # End of catctlLogon

######################################################################
# 
# catctlInit - General Initialization
#
# Description:
#   This subroutine is where startup initialization occurs
#
# Parameters:
#   - None
######################################################################
sub catctlInit
{
    my $DebugEnvValue = 0;

    #
    # Display our version
    #
    catctlPrintMsg ("\n$MSGIVERSION\n",$TRUE,$TRUE);

    #
    # Set OS Environment
    #
    catctlSetOSEnv();

    #
    # Get Oracle Environment
    #
    $gsOracleEnv = catctlGetOracleEnv();

    #
    # Set Debug Flag or Environment Variable set
    #
    $DebugEnvValue = catctlGetEnv($CATCTLDBGENV);
    if (($giDebugCatctl > 0) || ($DebugEnvValue))
    {
        catctlUnSetEnv($CATCTLDBGENV);
        #
        # Exit if we can't find debug file for tracing
        #
        if (!catctlDebugTrace($DebugEnvValue))
        {
            exit(1);
        }
        exit(0);
    }

    #
    # Set up SQL Error message query
    #
    $gsSelectErrors = $SELERR1.$SELERR2.$SELERR3.$SELERR4.";\n";

    #
    # Setup Process Number
    #
    catctlSetProcessNo();

    #
    # Set up sql file to execute
    #
    catctlSetFileNameToExecute();

    #
    # Set Log file directory
    #
    catctlSetLogFiles();

    #
    # Set Connect String
    #
    catctlSetConnectStr();
        

    #
    # Set Start Phase
    #
    if ($opt_p)
    {
        $giStartPhase = $opt_p;
        $gbStartStopPhase = $TRUE;
    }

    if ($opt_P)
    {
        $giStopPhase = $opt_P;
        $gbStartStopPhase = $TRUE;
    }

    #
    # Add User Session File
    #
    if ($gScript)
    {
        my $tmpvar = $giUseDir ? "@".$gSrcDir."/".$gScript : "@".$gScript;
        push (@session_files, $tmpvar);  # Session File
        push (@session_phase, 0);        # Session Phase
    }

    #
    # Set Default Runtime Args for catconExec
    #
    catctlSetDefRTArgs();

    #
    # Scan Sql Files
    #
    if (!$gbSerialRun)
    {
        catctlScanSqlFiles($gsPath);   # recursively scan through control files
        catctlLoadPhasesRO();          # Load Phases in reverse order
        catctlDisplayPhases();         # Display Phases
    }

} # End of catctlInit


######################################################################
# 
# catctlDisplayPhaseInfo - Load phase with or without compilation of sql files
#
# Description:
#   Display Phase Info to Screen
#
# Parameters:
#   - phase number (IN)
#   - Number of phase files (IN)
#   - Inclusion List (IN)
#   - Exclusion List (IN)
######################################################################
sub catctlDisplayPhaseInfo
{
   my $phaseno = $_[0];           # phase no
   my $numofphasefiles = $_[1];   # Number of phase files
   my $pInclusion    = $_[2];     # Inclusion List for Containers
   my $pExclusion    = $_[3];     # Exclusion List for Containers
   my $pList         = "";
   my $PdbPad        = $SPACE;    

   #
   # Set List up to Display
   #
   if ($gbCdbDatabase)
   {
       if($pExclusion)
       {
           $pList = $pExclusion;
       }

       if ($pInclusion)
       {
           $pList = $pInclusion;
       }
   }

   if ($phaseno != 0)
   {
       $gtSTime  = time();
       $gtSDifSec = $gtSTime - $gtLastTime;
       $gtTotSec = $gtTotSec + $gtSDifSec;
       $gsPadChr = $SPACE;
       if ($giLastNumOfPhaseFiles < 10)
       {
           $gsPadChr = $SPACE.$SPACE.$SPACE;
       }
       else
       {
           if ($giLastNumOfPhaseFiles < 100)
           {
               $gsPadChr = $SPACE.$SPACE;
           }
       }

       if ($gtSDifSec < 10)
       {
          $PdbPad = $SPACE.$SPACE.$SPACE.$SPACE;
       }
       else
       {
           if ($gtSDifSec < 100)
           {
               $PdbPad = $SPACE.$SPACE.$SPACE;
           }
           else
           {
               if ($gtSDifSec < 1000)
               {
                   $PdbPad = $SPACE.$SPACE;
               }
           }
       }

       catctlPrintMsg(
          " $gsPadChr$MSGITOTALTIME$gtSDifSec$DSPSECS$PdbPad$pList\n",
            $TRUE,$TRUE);
   }

   $gtLastTime = time();
   $giLastNumOfPhaseFiles = $numofphasefiles;

   $gsPadChr = $phaseno < 10 ? $SPACE : $NOSPACE;

   if ($opt_r || $giProcess == 1)
   {
       $gsDspPhase = $SERIAL;
   }
   else
   {
       if ($phase_files[$phaseno][0] eq $RESTART)
       {
           $gsDspPhase = $BOUNCE;
       }
       else
       {
           $gsDspPhase = ($phase_type[$phaseno] == $MULTI) 
               ? $PARALLEL : $SERIAL;
       }
   }
   catctlPrintMsg(
 "$gsDspPhase $MSGIPHASENO$gsPadChr$phaseno $MSGITOTALFILES $numofphasefiles ",
                  $TRUE,$TRUE);

} # End of catctlDisplayPhaseInfo

######################################################################
# 
# catctlExecutePhaseFiles - Execute the sql scripts for the phase.
#
# Description:
#   This subroutine decides how to run the sql scripts with a phase.
#
# Parameters:
#   - phase number (IN)
#   - Number of Phase Files (IN)
#   - Inclusion List for Containers (IN)
#   - Exclusion List for Containers (IN)
#   - SQL identifier (IN)
######################################################################
sub catctlExecutePhaseFiles
{
   my $phaseno    = $_[0];   # phase no
   my $numoffiles = $_[1];   # Num of Phase Files
   my $Inclusion = $_[2];    # Inclusion List for Containers
   my $Exclusion = $_[3];    # Exclusion List for Containers
   my $SqlIdentifier = $_[4];    # SQL Identifier
   my @SqlAry;               # Sql Array
   my $x          = 0;       # Index

   if ($phase_type[$phaseno] == $SINGLE)
   {
       #
       # Create Pfile if last job.
       #
       if ($LASTJOB eq $phase_files[$phaseno][0])
       {
           #
           # 17277459: Call datapatch in upgrade mode, to install any pending
           # PSUs or patches that require upgrade mode
           catctlDatapatch("upgrade");

           catctlCreatePFile();
       }

       # Load files in Sql Array
       for ($x = 0; $x < $numoffiles; $x++)
       {
           push (@SqlAry, $phase_files[$phaseno][$x]);
       }

       # run all scripts in this phase single-threaded
       $giRetCode =
           catconExec(@SqlAry, 
                      1,  # run single-threaded
                      0,  # run in every Container if the DB is Consolidated
                      0,  # Don't issue process init/completion statements
                      $Inclusion,      # Inclusion List for Containers
                      $Exclusion,      # Exclusion List for Containers
                      $SqlIdentifier); # SQL Identifier

       if ($giRetCode)
       {
           die "$MSGFCATCONEXEC $!";
       }
   }
   else
   {  # script in this phase run in serial reverse order
      # to catch dependency problems
       if ($opt_r)
       {
           # Load files in Sql Array
           for ($x = 0; $x < $numoffiles; $x++)
           {
               push (@SqlAry, $phase_files_ro[$phaseno][$x]);
           }

           # run all scripts in this phase single-threaded
           $giRetCode =
               catconExec(@SqlAry, 
                          1,  # run single-threaded
                          0,  # run in every Container if DB is Consolidated
                          0,  # Don't issue process init/completion statements
                          $Inclusion,      # Inclusion List for Containers
                          $Exclusion,      # Exclusion List for Containers
                          $SqlIdentifier); # SQL Identifier
           if ($giRetCode)
           {
               die "$MSGFCATCONEXEC $!";
           }
       }
       # scripts in this phase may be run in parallel
       else
       {
           # Load files in Sql Array
           for ($x = 0; $x < $numoffiles; $x++)
           {
               push (@SqlAry, $phase_files[$phaseno][$x]);
           }

           $giRetCode =
               catconExec(@SqlAry, 
                          0,  # run multi-threaded
                          0,  # run in every Container if Consolidated
                          0,  # Don't issue process init/completion statements
                          $Inclusion,      # Inclusion List for Containers
                          $Exclusion,      # Exclusion List for Containers
                          $SqlIdentifier); # SQL Identifier
           if ($giRetCode)
           {
               die "$MSGFCATCONEXEC $!";
           }
       }
   }

} # End of catctlExecutePhaseFiles


######################################################################
# 
# catctlStartPhase - Send a bunch of Sql Commands to processors.
#
# Description: Sends Sql commands to do the following:
#              Update internal phase tables
#              Display start phase times in log files
#              Run Sql Session init script.
#   
#
# Parameters:
#   - phase number (IN)
#   - Inclusion List for Containers (IN)
#   - Exclusion List for Containers (IN)
######################################################################
sub catctlStartPhase
{
    my $ph = $_[0];         # phase no
    my $pInclusion = $_[1]; # Inclusion List
    my $pExclusion = $_[2]; # Exclusion List
    my $TIMESTART = qq/SELECT 'PHASE_TIME___START $ph ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') AS catctl_timestamp FROM SYS.DUAL;\n/;
    my $Sql           = "";
    my $TmpFileName   = "";
    my $AtTmpFileName = "";
    my $x             = 0;  # Index counter


    #
    # Don't turn on load with compile switch until
    # after phase 0 otherwise we get errors
    #
    if ($ph != 0)
    {
        #
        # Turn on and off Compile switch as script dictates
        #
        $gsLoadComp = ($phase_compile[$ph] == $gbLoadWithComp) 
            ? $LOADWITHCOMP 
            : $LOADWITHOUTCOMP;

        #
        # Load without Compile is turn on in phase 1
        # We will get errors if we turn on before phase 1.
        #
        $SqlAry[0] = $gsLoadComp;
        $giRetCode = catconRunSqlInEveryProcess(@SqlAry);
        if ($giRetCode)
        {
           die "$MSGFCATCONRUNSQLINEVERYPROC $!";
        }
    }

    #
    # Show Time Start in Log Files
    #
    $SqlAry[0] = $TIMESTART;
    $giRetCode = catconRunSqlInEveryProcess(@SqlAry);
    if ($giRetCode)
    {
        die "$MSGFCATCONRUNSQLINEVERYPROC $!";
    }

    #
    # run session initialization script in every process
    # except for phase 0. phase 0 is a single process by default
    # NOTE: even if this phase is single-threaded, multiple processes may be 
    #       involved in executing its scripts if we are operating on a 
    #       Consolidated DB
    if ($ph != 0)
    {
        for ($x = 0; $x < @session_files; $x++) 
        {
            # Run only in the phase found and beyond
            if ($session_phase[$x] <= $ph)
            {
                #
                # For non-cdb run session files in every process
                #
                $SqlAry[0] = $session_files[$x]; 
                $giRetCode = catconRunSqlInEveryProcess(@SqlAry);
                if ($giRetCode)
                {
                    die "$MSGFCATCONRUNSQLINEVERYPROC $!";
                }
            }
        }
    }

} # End of catctlStartPhase

######################################################################
# 
# catctlEndPhase - Send Sql Commands at the end of phase.
#
# Description: Sends Sql commands to do the following:
#              Update internal phase tables
#              Display end phase times in log files
#   
#
# Parameters:
#   - phase number (IN)
#   - Inclusion List for Containers (IN)
#   - Exclusion List for Containers (IN)
######################################################################
sub catctlEndPhase
{
    my $ph = $_[0];   # phase no
    my $pInclusion = $_[1]; # Inclusion List
    my $pExclusion = $_[2]; # Exclusion List
    my $TIMEEND = qq/SELECT 'PHASE_TIME___END $ph ' || TO_CHAR(SYSTIMESTAMP,'YY-MM-DD HH:MI:SS') AS catctl_timestamp FROM SYS.DUAL;\n/;
    my $Sql           = "";
    my $TmpFileName   = "";
    my $AtTmpFileName = "";

    #
    # Show End Start in Log Files
    #
    $SqlAry[0] = $TIMEEND;
    $giRetCode = catconRunSqlInEveryProcess(@SqlAry);
    if ($giRetCode)
    {
        die "$MSGFCATCONRUNSQLINEVERYPROC $!";
    }

} # End of catctlEndPhase


######################################################################
# 
# catctlSetDefRTArgs - Set Default RunTime Arguments
#
# Description:
#   This subroutine sets the default RunTime Arguments for catconExec.
#
#
# Parameters:
#   - None
######################################################################
sub catctlSetDefRTArgs {

    $gsRTInclusion  = $gsNoInclusion;
    $gsRTExclusion  = $gsNoExclusion;
    $gsRTIdentifier = $gsNoIdentifier;

} # end catctlSetDefRTArgs


######################################################################
# 
# catctlSetCDBLists - Set up Inclusion and Exclusion Lists
#
# Description:
#   This subroutine sets up Inclusion and Exclusion Lists for us
#   to run ROOT first.  Also it detects if user list contains root
#   for inclusion or execlusion.  It must parse out the root information
#   and set the appropriate flags to indicate what the user has passed.
#   We only want PDB's in the Inclusion and Exclusion Lists.  The
#   Root procession will be controlled by us.
#
#
# Parameters:
#   - None
######################################################################
sub catctlSetCDBLists {

    my $idx = 0;
    my $bRootValid = $TRUE;


    #
    # Set Flags
    #
    $gbCdbDatabase    = $TRUE;
    $gbRootProcessing = $TRUE;
    $gbSeedProcessing = $TRUE;
    $gbPdbProcessing  = $FALSE;

    #
    # Get Container Names
    #
    @ContainerNames = catconGetConNames();

    #
    # Print Out the Container Names
    #
    catctlPrintMsg ("\n$CONTAINERMSG\n\n",$TRUE,$TRUE);
    for ($idx = 0; $idx < @ContainerNames; $idx++)
    {
        catctlPrintMsg ("$ContainerNames[$idx]\n",$TRUE,$TRUE);
    }

    #
    # If Inclusion and Exlcusion Lists
    #
    catctlParseLists($gCInclusion, $gCExclusion);

    #
    # Is Root opened in upgrade mode?
    #
    $gbRootOpenInUpgMode = catctlGetOpenMode();

    #
    # Start and stop phases must have an
    # a container list for CDBs.
    #
    if ($gbStartStopPhase)
    {
        #
        # Set Inclusions to be that of the users
        # Don't override
        #
        $gsRTInclusion = $gCInclusion;
        $gsRTExclusion = $gCExclusion;

        #
        # When specifying Start and Stop phases we must have a container
        # inclusion list when upgrading a CDB or PDB only one inclusion
        # list item is allowed per CDB.
        #
        if ( ($gbListProcessing == $FALSE) ||
             (!$gCInclusion)               ||
             (@AryParsedList != 1) ) 
        {
            catctlPrintMsg("\n$MSGFCONTAINERLIST\n",$TRUE,$TRUE);
            catconWrapUp();
            exit(0);
        }
    }

    #
    # Check to make sure Root is valid
    #
    $bRootValid = catctlIsRootValid($gbUpgrade,
                                    $gbRootProcessing,
                                    $gbPdbProcessing,
                                    $gbInstance);

    #
    # Get out if CDB$ROOT is invalid
    #
    if (!$bRootValid)
    {
        catctlPrintMsg("\n$MSGFROOTINVALID\n",$TRUE,$TRUE);
        catconWrapUp();
        exit(0);
    }

} # end catctlSetCDBLists

######################################################################
# 
# catctlParseLists - Parse Inclusion and Exclusion Lists
#
# Description:
#   Parse Inclusion and Exclusion Lists
#
#
# Parameters:
#   pInclusion - IN  Inclusion list
#   pExclusion - IN  Exclusion list
# Returns
#   - None
######################################################################
sub catctlParseLists {

    my $pInclusion  = $_[0];  # Inclusion List
    my $pExclusion  = $_[1];  # Exclusion List
    my $AryItem     = "";     # Exclusion or Inclusion list item
    my $ConItem     = "";     # Container List item
    my $pList       = $pInclusion; # Default to Inclusion List
    my $bFirstTime  = $TRUE;  # First Time Flag
    my $bFound      = $TRUE;  # Found Flag
    my $idx         = 0;      # Index counter

    #
    # Initialize Lists
    #
    $gsRTInclusion     = "";
    $gsRTExclusion     = "";
    $gsParsedInclusion = "";
    $gsParsedExclusion = "";

    #
    # Set List to Exclusion if present
    #
    if ($pExclusion)
    {
        $pList = $pExclusion;
    }

    #
    # Parse out the array lists
    #
    if ($pList)
    {
        #
        # Split out list into an array
        #
        $gbListProcessing  = $TRUE;
        $pList =~ s/^'(.*)'$/$1/;  # strip single quotes
        $pList =~ s/^"(.*)"$/$1/;  # strip double quotes

        @AryParsedList = split(' ', $pList);

        #
        # Take All PDB's excluding root.
        # If this is an inclusion list.
        #
        if ($pInclusion)
        {
            #
            # Initialize
            #
            $gbRootProcessing  = $FALSE;
            $gbSeedProcessing  = $FALSE;
            $bFirstTime        = $TRUE;

            #
            # Check Inclusion List
            #
            foreach $AryItem (@AryParsedList)
            {
                #
                # Found Root Tag Including ROOT
                #
                if ($AryItem eq $CDBROOTTAG)
                {
                    $gbRootProcessing = $TRUE;
                }

                #
                # Found Seed Tag Including SEED
                #
                if ($AryItem eq $PDBSEEDTAG)
                {
                    $gbSeedProcessing = $TRUE;
                }

                if ($AryItem ne $CDBROOTTAG)
                {
                    if (catctlIsPDBOkay($AryItem,$giStartPhase))
                    {
                        if ($bFirstTime)
                        {
                            $bFirstTime    = $FALSE;
                            $gsRTInclusion = $AryItem;
                        }
                        else
                        {
                            $gsRTInclusion = $gsRTInclusion." ".$AryItem;
                        }
                        push(@AryPDBInstanceList, $AryItem);
                        $gbPdbProcessing  = $TRUE;
                    }
                }
            } # end for AryItem
        } # end if inclusion list

        #
        # Take everything in the container list
        # except what is in the exclusion list
        #
        if ($pExclusion)
        {
            #
            # Initialize
            #
            $bFirstTime        = $TRUE;
            $gbRootProcessing  = $TRUE;
            $gbSeedProcessing  = $TRUE;

            #
            # Check exclusion list for root or seed
            #
            foreach $AryItem (@AryParsedList)
            {
                #
                # Found Root Tag Excluding ROOT
                #
                if ($AryItem eq $CDBROOTTAG)
                {
                    $gbRootProcessing = $FALSE;
                }

                #
                # Found Seed Tag Excluding SEED
                #
                if ($AryItem eq $PDBSEEDTAG)
                {
                    $gbSeedProcessing = $FALSE;
                }
            } # end for AryItem

            #
            # Check exclusion list
            #
            foreach $ConItem (@ContainerNames)
            {
                $bFound = $FALSE;
                foreach $AryItem (@AryParsedList)
                {
                    if ($AryItem eq $ConItem)
                    {
                        $bFound = $TRUE;
                        last;
                    }
                }

                #
                # Not Found add it to the list
                #
                if (!$bFound) 
                {
                    if ($ConItem ne $CDBROOTTAG)
                    {
                        if (catctlIsPDBOkay($ConItem,$giStartPhase))
                        {
                            if ($bFirstTime)
                            {
                                $bFirstTime    = $FALSE;
                                $gsRTExclusion = $ConItem;
                            }
                            else
                            {
                                $gsRTExclusion = $gsRTExclusion." ".$ConItem;
                            }
                            push(@AryPDBInstanceList, $ConItem);
                            $gbPdbProcessing  = $TRUE;
                        }
                    }
                }
            } # end for ConItem
        } # end if exclusion list
    } # end if list
    else
    {
        #
        # Initialize
        #
        $gbRootProcessing  = $FALSE;
        $gbSeedProcessing  = $FALSE;
        $bFirstTime        = $TRUE;

        #
        # No List take everything in container list
        # but the root.
        #
        foreach $ConItem (@ContainerNames)
        {
            #
            # Found Root Tag Including ROOT
            #
            if ($ConItem eq $CDBROOTTAG)
            {
                $gbRootProcessing = $TRUE;
            }

            #
            # Found Seed Tag Including SEED
            #
            if ($ConItem eq $PDBSEEDTAG)
            {
                $gbSeedProcessing = $TRUE;
            }

            #
            # Everything in list but ROOT
            #
            if ($ConItem ne $CDBROOTTAG)
            {
                if (catctlIsPDBOkay($ConItem,$giStartPhase))
                {

                    if ($bFirstTime)
                    {
                        $bFirstTime    = $FALSE;
                        $gsRTInclusion = $ConItem;
                    }
                    else
                    {
                        $gsRTInclusion = $gsRTInclusion." ".$ConItem;
                    }
                    push(@AryPDBInstanceList, $ConItem);
                    $gbPdbProcessing  = $TRUE;
                }
            }

        }
    } # End if for lists


    #
    # Save Original Root Processing value
    #
    $gbSavRootProcessing = $gbRootProcessing;

    #
    # Set the Parsed Inclusion/Exclusion Lists
    #
    $gsParsedInclusion = $gsRTInclusion;
    $gsParsedExclusion = $gsRTExclusion;

    catctlPrintMsg(
     "PDB Inclusion:[$gsParsedInclusion] Exclusion:[$gsParsedExclusion]\n",
      $TRUE,$TRUE);

}
######################################################################
# 
# catctlSetProcessNo - Set Process Number
#
# Description: Set the number of sql processors to start up.
#              0 runs catupgrd.sql the old fashion way.
#
# Parameters:
#   - None
######################################################################
sub catctlSetProcessNo
{
    #
    # Sql Processors
    #
    if ($opt_n)
    {
       $giProcess = $opt_n;
    }


    #
    # Sql PDB Processors
    #
    if ($opt_N)
    {
        $giPdbProcess = $opt_N;
    }

    #
    # Serial Run
    #
    if ($gbSerialRun)
    {
        $giProcess   = 1;
    }


} # End of catctlSetProcessNo


######################################################################
# 
# catctlSetFileNameToExecute - Set Filename to execute
#
# Description: Parse out the file to execute.
#
# Parameters:
#   - None
######################################################################
sub catctlSetFileNameToExecute
{
    my $mFile = '';

    if ($gSrcDir)
    {
        if (-r "${gSrcDir}")
        {
            $giUseDir = 1;
            $gsPath = $gSrcDir."/".$gsFile;
        }
        else
        {
            die "$MSGFCATCTLSETFILENAMETOEXECUTE $!";
        }
    }
    else
    {
        $gsPath = $gsFile;
    }

    #
    # Check for Upgrade
    #
    $mFile = lc($gsFile); # Lower Case File
    if (rindex($mFile, "catupgrd") == -1)
    {
        $gbUpgrade = $FALSE;
    }


    #
    # If running serially check for
    # catupgrd.sql and add parallel=no
    #
    if ($gbSerialRun)
    {
        if (rindex($mFile, "catupgrd") != -1)
        {
            $gbUpgradeArgs = $TRUE;
        }
    }


} # End of catctlSetFileNameToExecute


######################################################################
# 
# catctlSetLogFiles - Set Log files
#
# Description: Parse out the Log file(s).
#
# Parameters:
#   - None
######################################################################
sub catctlSetLogFiles
{
    my $DirName = $gLogDir;   # Directory Name

    $gsSpoolLog = index($gsFile,".") > 0 
                  ? substr($gsFile,0,index($gsFile,'.')) : $gsFile;

    #
    # Add in unique log identifier
    # Ie catupgrd(Sid)#.log
    #
    if ($gIdentifier)
    {
        $gsSpoolLog = $gsSpoolLog.$gIdentifier;
    }

    $gsSpoolLogDir = $gsSpoolLog;

    print "$MSGIANALYZINGFILE $gsPath\n";

    #
    # Set Directory Name to what user specified or
    # to the current working directory
    #
    $DirName = $gLogDir;
    if (!$DirName)
    {
        $DirName = cwd;
    }
    print "$MSGILOGFILES $DirName\n";

    #
    # Check Log Directory or Current Directory to make sure
    # it is valid for writing files
    #
    if (catctlValidDir($DirName,"W"))
    {
        if ($gLogDir)
        {
            $gsSpoolLogDir = $gLogDir."/".$gsSpoolLog;
        }
        $gsDatapatchLogUpgrade = $gsSpoolLogDir . "_datapatch_upgrade.log";
        $gsDatapatchErrUpgrade = $gsSpoolLogDir . "_datapatch_upgrade.err";
        $gsDatapatchLogNormal = $gsSpoolLogDir . "_datapatch_normal.log";
        $gsDatapatchErrNormal = $gsSpoolLogDir . "_datapatch_normal.err";
    }
    else
    {
        die "$MSGFCATCTLSETFILELOGFILES $!";
    }


    #
    # Delete old Log Files greater than or
    # equal to process count
    #
    catctlDelLogFiles($giProcess, $MAXPROC_NO_CDB-1); 

} # End of catctlSetLogFiles

######################################################################
# 
# catctlValidDir - Validate Directory
#
# Description: Validate Directory
#
# Parameters:
#   DirName (IN)
#   ReadOrWrite (IN) Values "W" - Write "R" - Read
# Returns
#   TRUE  - Directory Okay
#   FALSE - Directory Not Okay
######################################################################
sub catctlValidDir
{
    my $DirName     = $_[0];     # Directory Name
    my $ReadOrWrite = $_[1];     # Read Or Write directory

    #
    # No directory name specified
    #
    if (!$DirName)
    {
        return ($FALSE);
    }

    stat($DirName);

    #
    # Directory does not exits or is not a directory
    #
    if (! -e _ || ! -d _)
    {
        return ($FALSE);
    }


    #
    # Directory is not writeable
    #
    if ($ReadOrWrite eq "W")
    {
        if (! -w _)
        {
            return ($FALSE);
        }
    }

    return ($TRUE);

}  # End catctlValidDir


######################################################################
# 
# catctlDebugTrace - Create Perl Debug File
#
# Description: Create Perl Debug File
#
# Another way to do this is to set the enviromental variable
#    PERLDB_OPTS "NonStop AutoTrace=1 frame=2 LineInfo=catctl.trc"
#
# Parameters:
#   None
# Returns
#   TRUE  - Ran in Debug Mode
#   FALSE - Could Not Run In Debug Mode
######################################################################
sub catctlDebugTrace
{
    my $pDebugEnvValue     = $_[0];          # Environmental Variable
    my $mode               = 0400;           # Owner gets read privs
    my $PerlDebugNameUnix  = ".perldb";      # Perl Unix Name Unix
    my $PerlDebugNameWin   = "perldb.ini";   # Perl Windows Name
    my $PerlDebugName      = $PerlDebugNameUnix;   # Perl Windows Name
    my $CatctlProgram      = $^X." -d ".$0;  # Catctl Program
    my $CatctlArgs         = "";             # Construct Catctl Command
    my $argno              = 0;              # Index
    my $argcnt             = $#gArgs;        # Arg Count
    my $argloop            = ($argcnt -1);   # Max Arg Loop
    my $RetStat            = $TRUE;          # Return Status
    my $bContainer         = $FALSE;         # Processing Containers
    my $bAddSpace          = $TRUE;          # Add Space
    my $dash               = "";             # Dash field

    #
    # Bug In Perl you should not have to do this
    #
    if ($^O eq 'MSWin32')
    {
        $PerlDebugName = $PerlDebugNameWin;
    }

    #
    # No debug file found create one
    #
    if (! -e $PerlDebugName)
    {
        #
        # Create Perl Debug file
        #
        open(FileOut, '>', $PerlDebugName) or 
            die "$MSGFCATCTLCREATEDBGFILE - $PerlDebugName $!";
        print FileOut "print STDERR \"\\n\";\n";
        print FileOut "print STDERR \"Running $PerlDebugName\";\n";

        #
        # Create Trace File in the format catctl_YYYYMMDDHHMNSC_pid_trace.log
        #
        print FileOut 
            "(\$s,\$m,\$h,\$md,\$mon,\$y,\$wd,\$yday,\$isd)=localtime();\n";
        print FileOut 
            "\$f=sprintf(\"%04d%02d%02d%02d%02d%02d\",\$y+1900,\$mon+1,\$md,\$h,\$m,\$s);\n";
        print FileOut 
            "\$t=\"catctl_\".\$f.\"_\".\$\$.\"_trace.log\";\n";
        print FileOut "print STDERR \"\\n\";\n";
        print FileOut "print STDERR \"FileName generated is:[\$t]\";\n";
        print FileOut "print STDERR \"\\n\";\n";
        print FileOut 
            "parse_options(\"NonStop Autotrace frame=16 LineInfo=\$t\");\n";
        close(FileOut);

        #
        # Change protection
        #
        chmod($mode,$PerlDebugName);

        #
        # Display Creation Message
        #
        catctlPrintMsg("\nFileName: [$PerlDebugName] has been created\n", $TRUE,$TRUE);
    }

    #
    # Trace Message Displayed
    #
    catctlPrintMsg("This will produce a debug trace file In the following format:\n",
                   $TRUE,$TRUE);
    catctlPrintMsg("    (catctl_YYYYMMDDHHMNSC_pid_trace.log)\n\n",
                   $TRUE,$TRUE);

    #
    # Construct the arg and
    # re-assembling the command
    # so we can invoke the tracing
    # debugger
    #
    foreach $argno (0 .. $argloop)
    {
        #
        # Parse out first character in argument
        #
        $dash = substr($gArgs[$argno], 0, 1);

        #
        # Evaluate the arguments
        #
        if ($gArgs[$argno] eq "-Z")
        {
            #
            # Prevent Infinite loop when we call ourselves by
            # replacing 1 with 0 so we don't trigger
            # the debugging in the main loop when we call ourselves
            #
            $CatctlArgs = $CatctlArgs." ".$gArgs[$argno];
            $gArgs[$argno+1] = 0;
        }
        elsif ($gArgs[$argno] eq "-c" || $gArgs[$argno] eq "-C")
        {
            #
            # Put Back Start Single Quote
            #
            $bContainer = $TRUE;
            $bAddSpace  = $FALSE;
            $CatctlArgs = $CatctlArgs." ".$gArgs[$argno]." ".$CONTAINERQUOTE;
        }
        elsif (($bContainer) && ($dash eq "-"))
        {
            #
            # Put Back End Single Quote
            #
            $CatctlArgs = $CatctlArgs.$CONTAINERQUOTE;
            $bContainer = $FALSE;
            $CatctlArgs = $CatctlArgs." ".$gArgs[$argno];
        }
        elsif ($bAddSpace)
        {
            #
            # Add Space and Argument 
            #
            $CatctlArgs = $CatctlArgs." ".$gArgs[$argno];
        }
        else
        {
            #
            # Add just the Argument
            #
            $CatctlArgs = $CatctlArgs.$gArgs[$argno];
            $bAddSpace  = $TRUE;
        }

    } # End Foreach Args

    #
    # Put Back End Single Quote if we have not
    # done it in the foreach Arg loop
    #
    if ($bContainer)
    {
        $CatctlArgs = $CatctlArgs.$CONTAINERQUOTE;
        $bContainer = $FALSE;
    }

    #
    # Add -Z 0 argument if invoked by the
    # environmental variable
    #
    if ($pDebugEnvValue)
    {
        $CatctlArgs = $CatctlArgs." -Z 0";
    }

    #
    # Add Filename to execute in PDB
    #
    $CatctlArgs = $CatctlArgs." ".$gArgs[$argcnt];

    #
    # Display Starting Message
    #
    catctlPrintMsg ("\nStarting in Debug Mode\n[$CatctlProgram$CatctlArgs]\n",
                    $TRUE,$TRUE);

    eval { system("$CatctlProgram$CatctlArgs") };
    if ($@)
    {
        $RetStat = $FALSE;
        catctlPrintMsg ("\nError Executing In Debug Mode $@\n[$CatctlProgram$CatctlArgs]\n",
                         $TRUE,$TRUE);
        warn();
    }

    return ($RetStat);

}  # End catctlDebugTrace

######################################################################
# 
# catctlDelLogFiles - Delete Log files
#
# Description: Delete Old Log Files
#
# Parameters:
#   Starting Index (IN)
#   Ending  Index (IN)
######################################################################
sub catctlDelLogFiles
{
    my $pStartIdx = $_[0];    # Start Index
    my $pEndIdx   = $_[1];    # End Index
    my $x         = 0;        # Counter
    my $LogFile   = "";       # Log File

    #
    # Get out if this is a PDB instance.  Only
    # Main instance should remove obsolete
    # files.
    #
    if ($gbInstance)
    {
        return;
    }

    for ($x = $pStartIdx; $x <= $pEndIdx; $x++)
    {
        $LogFile = $gsSpoolLogDir.$x.".log";
        if (-e $LogFile)
        {
            unlink($LogFile);
        }
    }

} # End of catctlDelLogFiles

######################################################################
# 
# catctlSetConnectStr - Set Log files
#
# Description: Add Password to UserName
#
# Parameters:
#   - None
######################################################################
sub catctlSetConnectStr
{
    #
    # User from upgraded database
    #
    if ($gUser)
    {
        if ($gPwdFile)
        {
            my $password;
            open (FileIn, '<', $gPwdFile) or 
                die "$MSGFCATCTLREADFILES - $gPwdFile $!";
            $password = <FileIn>;
            close (FileIn);
            chomp $password;
            $gUser = $gUser.$PWDSLASH.$password;
        }
    }

} # End of catctlSetConnectStr

######################################################################
# 
# catctlDisplayPhases - Display Phase Files.
#
# Description: This displays Sql Files that will execute
#              for each phase.
#
# Parameters:
#   - None
######################################################################
sub catctlDisplayPhases
{
    my $numofphasefiles = 0;
    my $bLogtoScreen    = $FALSE;
    my $i               = 0;
    my $x               = 0;
    my $j               = 0;
    my $z               = 0;
    my $fldsize         = 0;
    my $strsize         = 0;

    if ($gbDisplayPhases)
    {
        $bLogtoScreen = $TRUE;
    }

    #
    # Return if this is a PDB instance
    #
    if ($gbInstance)
    {
        return;
    }

    for ($i = 0; $i < @phase_type; $i++) 
    {
        $numofphasefiles = @{$phase_files[$i]};
        catctlPrintMsg(
         "$MSGIDISP1 $i$MSGIDISP2 $phase_type[$i] $MSGIDISP3 $numofphasefiles $MSGIDISP4\n",
         $TRUE,$bLogtoScreen);

        if ($numofphasefiles > 0)
        {
            $x = 0;
            $fldsize = 21;

            for ($j = 0; $j < $numofphasefiles; $j++)
            {
                if ($opt_r)
                {
                    $strsize = length($phase_files_ro[$i][$j]);
                    catctlPrintMsg("$phase_files_ro[$i][$j] ",$TRUE,$bLogtoScreen);
                }
                else
                {
                    $strsize = length($phase_files[$i][$j]);
                    catctlPrintMsg("$phase_files[$i][$j] ",$TRUE,$bLogtoScreen);
                }
                $x++;
                if ($x == 4)
                {
                    catctlPrintMsg("\n",$TRUE,$bLogtoScreen);
                    $x = 0;
                }
                else
                {
                    # Space out fields
                    for ($z = $strsize; $z < $fldsize; $z++)
                    {
                        catctlPrintMsg("$SPACE",$TRUE,$bLogtoScreen);
                    }
                }
            }
            catctlPrintMsg("\n",$TRUE,$bLogtoScreen);
        }
    }

    if($opt_r)
    {
        catctlPrintMsg("\n$MSGIREVERSEODER",$TRUE,$bLogtoScreen);
    }

} # End of catctlDisplayPhases


######################################################################
# 
# catctlLoadPhasesRO - Load Phases in reverse order
#
# Description: Load Reverse order array from phase_files array.
#
# Parameters:
#   - None
######################################################################
sub catctlLoadPhasesRO
{

    my $numofphasefiles = 0;
    my $i = 0;
    my $j = 0;

    for ($i = 0; $i < @phase_type; $i++) 
    {
        $numofphasefiles = @{$phase_files[$i]};
        if ($numofphasefiles > 0)
        {
            for ($j = $numofphasefiles-1; $j >= 0; $j--)
            {
                push(@{$phase_files_ro[$i]}, $phase_files[$i][$j]);
            }
        }
    }

} # End of catctlLoadPhasesRO

######################################################################
# 
# catctlFindConId - Find Con ID within global array.
#
# Description: Give a con id, see if it is present on our
#              global list of containers with errors.
#
# Parameters:
#   ContainerId -  IN
#
# Return - TRUE Found or False Not Found
#
######################################################################
sub catctlFindConId
{
    my $ContainerId = $_[0];  # Container id to search for
    my $x = 0;
    my $bRetStat = $FALSE;

    for ($x = 0; $x < @ContainerIds; $x++)
    {
        if ($ContainerIds[$x] eq $ContainerId)
        {
            $bRetStat = $TRUE;
            last;
        }
    }

    return ($bRetStat);
    
}

######################################################################
# 
# catctlInvalidateRDBMS - Invalidate RDBMS Component
#
# Description: Invalidate the RDBMS Component CATALOG and CATPROC.
#
# Parameters:
#   LastContainer   - IN
#   LastContainerId - IN
# Return - Status of catconExec
#
######################################################################
sub catctlInvalidateRDBMS
{
    my $LastContainer =   $_[0];  # Last Container
    my $LastContainerId = $_[1];  # Last Container id
    my $SqlStmts      = "";
    my $TmpFileName   = 0;
    my $AtTmpFileName = 0;
    my $AlterSession  = 0;       # Alter Session Set Container
    my $WriteRegistry = 0;       # Write to Registry
    my $INVCATPROC    = qq/BEGIN sys.dbms_registry.invalid('CATPROC'); END;/;
    my $INVCATALOG    = qq/BEGIN sys.dbms_registry.invalid('CATALOG'); END;/;
    my $UPDERRORREG   = qq/UPDATE $ERRORTABLE SET IDENTIFIER = 'CATPROC';\n/;
    my $bFoundContainer = $FALSE;


    #
    # Initialize
    #
    $giRetCode = 0;

    #
    # If we find the container then it's already been marked as
    # invalid just get out
    #
    $bFoundContainer = catctlFindConId($LastContainerId);
    if ($bFoundContainer == $TRUE)
    {
        return($giRetCode);
    }
    
    #
    # We are going to invalidate both components since
    # I can't tell for sure who is invalid
    #
    push(@ContainerIds, $LastContainerId);
    $WriteRegistry = 
        "INSERT INTO $ERRORTABLE VALUES ".
        "('SYS', SYSDATE, 'catctl.pl', 'CATPROC',".
        " 'Invalid Upgrade on [$LastContainer] Check catupgrd*.log',".
        " 'Invalid Upgrade');\n";

    #
    # Alter session on a cdb database
    #
    if ($gbCdbDatabase)
    {
        $AlterSession = 
            "ALTER SESSION SET CONTAINER = \"$LastContainer\";\n";
        $SqlStmts = $AlterSession;
    }

    $SqlStmts = $SqlStmts.$WriteRegistry;
    $SqlStmts = $SqlStmts.$INVCATPROC.$SQLTERM;
    $SqlStmts = $SqlStmts.$INVCATALOG.$SQLTERM;
    $SqlStmts = $SqlStmts.$UPDERRORREG;
    $SqlStmts = $SqlStmts.$COMMITCMD;

    #
    # Alter session on a cdb database
    #
    if ($gbCdbDatabase)
    {
        $SqlStmts = $SqlStmts.$CDBSETROOT;
    }

    #
    # Create the Temporary Sql File
    #
    $TmpFileName = catctlCreateSqlFile($SqlStmts,0);
    $AtTmpFileName = "\@".$TmpFileName;
    $SqlAry[0] = $AtTmpFileName;
       
    $giRetCode =
        catconExec(@SqlAry,
                   1, # run single-threaded
                   1, # run in Root 
                   0, # don't issue process init/completion stmts
                   $gsNoInclusion,     # No Inclusion list 
                   $gsNoExclusion,     # No Exclusion List
                   $gsNoIdentifier);   # No SQL Identifier
    #
    # Delete Temp File
    #
    if (-e $TmpFileName)
    {
        unlink($TmpFileName);
    }

    return ($giRetCode);

}


######################################################################
# 
# catctlCheckError - Check Log File Errors
#
# Description: Check Log File for Errors and Ignore Duplicate
#              Indexes.
#
# Parameters:
#   Filname - IN
# Return - TRUE Found or False No Found
#
######################################################################
sub catctlCheckError
{

  my $FileHandle =  $_[0];    # File Handle to log file
  my $line = 0;               # Line of data
  my $CompareStr = 0;         # Compare String

  while (<$FileHandle>)
  {
      #
      # Store the line
      #
      $line = $_;
      chomp($line);

      #
      # Check for Duplicate Index if found then
      # Ignore this error. After we get the error
      # I am expecting the Oracle Errors to follow.
      # When I find a line less than the tag length
      # I know we are done looking at the errors.
      #
      if (length($line) > $ORA00001TAGLEN)
      {
          #
          # Look for Tag at the beginning of line only
          #
          $CompareStr = substr($line, 0, $ORA00001TAGLEN);

          #
          # Duplicate Index Found
          #
          if ($CompareStr eq $ORA00001TAG)
          {
              return ($TRUE);
          }

      }
      else
      {
          return ($FALSE);
      }
  } # End While

  #
  # Shouldn't be here we should return with TRUE or FALSE
  #
  close ($FileHandle);
  die "$MSGFCATCTLCHECKERROR";
  
}

######################################################################
# 
# catctlReadLogFiles - Read Log Files
#
# Description: Read Log Files looking for errors or Pfile.
#
# Parameters:
#   - INPUT Read Flag
#           $READPFILE  - Look for PFILE
#           $READERRORS - Look for Errors
#   RETURNS 
#     Error Messages
######################################################################
sub catctlReadLogFiles
{
  my $ReadFlag =  $_[0];                       # Read Flag pfile or errors
  my $LogFile;
  my $ERRORLINETAG  = "ERROR at line ";        # Error at line error
  my $NOTFOUND      = 0;                       # Not Found
  my $ORA03114TAG   = "ORA-03114";             # Oracle Not Connected
  my $SP20604TAG    = "SP2-0640:";             # Oracle Not Connected
  my $CONTAINERTAG  = "==== Current Container = "; # Container tag
  my $CONTAINERIDTAG  = " Id = ";              # Container Id Tag
  my $ENDCONTAINERTAG = " ====";               # End Container tag
  my $CONTAINERTAGLEN = length($CONTAINERTAG); # Tag Len
  my $CONTAINERIDTAGLEN = length($CONTAINERIDTAG); # Tag Len
  my $ENDCONTAINERTAGLEN = length($ENDCONTAINERTAG); # Tag Len
  my $ORA03114TAGLEN = length($ORA03114TAG);   # Tag Len
  my $PFILETAGLEN   = length($PFILETAG);       # Tag Len
  my $CATCTLERRORTAGLEN = length($CATCTLERRORTAG); # Error Tag Len
  my $CATCTLERRORTAGENDLEN = length($CATCTLERRORTAGEND); # Error Tag End Len
  my $ERRORLINETAGLEN = length($ERRORLINETAG); # Error Line Len
  my $CATCTLRPTNAMETAG = "CATCTL REPORT = ";   # Report Name Tag
  my $CATCTLRPTNAMETAGLEN = length($CATCTLRPTNAMETAG); # Report Name Len
  my $line          = 0;                       # Line of data
  my $LineNo        = 0;                       # Line Number
  my $CompareStr    = 0;                       # Compare String
  my $LastContainer = 0;                       # Last Container
  my $LastContainerId = -1;                    # Last Container Id
  my $bFoundIt      = $FALSE;                  # Found Container
  my $bCatctlErrors = $FALSE;                  # Found Errors
  my $RetMsg        = "";                      # Return Message
  my $x             = 0;                       # Index

  #
  # Get out if instance and we are not reading errors.
  #
  if (($gbInstance) && ($ReadFlag != $READERRORS))
  {
      return($RetMsg);
  }

  #
  # No opts
  #
  if ($ReadFlag == $READPFILE)
  {
      #
      # Don't run post upgrade so don't bother with pfile
      # unless we are are a cdb database we still need pfile
      # to restart database to process pdb's.
      #
      if (($giPostUpgStat == $PSTUPGNORUN) &&
          (!$gbCdbDatabase))
      {
          return($RetMsg);
      }
      #
      # Already have pfile name
      #
      if ($gbFoundPfile == $TRUE)
      {
          return($RetMsg);
      }
  }


  #
  # Only Process 0 Log file. This has the PFILE info and the error info.
  #
  for ($x = 0; $x < 1; $x++)
  {
     #
     # Open and Read in Log Files
     #
     $LogFile = $gsSpoolLogDir.$x.".log";
     $LineNo  = 0;
     open (FileIn, '<', $LogFile) or die "$MSGFCATCTLREADLOGFILES - $LogFile $!";

     #
     # Search for SP2-1519 error in the RDBMS component of the
     # upgrade.  If found we need to mark RDBMS component as Invalid.
     # Also search for pfile so we can restart the database.
     #
     while (<FileIn>)
     {
         #
         # Store the line
         #
         $line = $_;
         chomp($line);
         $LineNo++;

         #
         # Found Errors print out all the errors
         #
         if ($bCatctlErrors == $TRUE)
         {
            if (length($line) > ($CATCTLERRORTAGENDLEN-1))
            {
                #
                # Look for Tag at the beginning of line only
                # We are done processing the errors when we
                # find the end tag 
                #
                $CompareStr = substr($line, 0, $CATCTLERRORTAGENDLEN);
                if ($CompareStr eq $CATCTLERRORTAGEND)
                {
                    $bCatctlErrors = $FALSE;
                    next;
                }
            }
            #
            # Store the errors
            #
            $RetMsg = $RetMsg."$line\n";
            next;
         }

         #
         # Get Last Container
         #
         if (length($line) > $CONTAINERTAGLEN)
         {
             #
             # Look for Tag at the beginning of line only
             #
             $CompareStr = substr($line, 0, $CONTAINERTAGLEN);

             #
             # Collect what container the Error Occurred
             # Format: ==== Current Container = CDB$ROOT Id = 1 ====
             #
             if ($CompareStr eq $CONTAINERTAG)
             {
                 $LastContainer =
                     substr($line,
                            index($line,$CONTAINERTAG)+$CONTAINERTAGLEN,
                            index($line,$CONTAINERIDTAG)-$CONTAINERTAGLEN);
                 $LastContainerId = 
                     substr($line,
                            index($line,$CONTAINERIDTAG)+$CONTAINERIDTAGLEN,
                            (index($line,$ENDCONTAINERTAG)) - 
                            (index($line,$CONTAINERIDTAG)+$CONTAINERIDTAGLEN));                     
             }

         }

         #
         # Report Name
         #
         if (length($line) > $CATCTLRPTNAMETAGLEN)
         {
             $CompareStr   = substr($line, 0, $CATCTLRPTNAMETAGLEN);
             if ($CompareStr eq $CATCTLRPTNAMETAG)
             {
                 $gsReportName = substr($line, $CATCTLRPTNAMETAGLEN, 
                                        length($line)-$CATCTLRPTNAMETAGLEN);
             }
         }

         #
         # Not Connected
         #
         if (length($line) > $ORA03114TAGLEN)
         {
             #
             # Look for Tag at the beginning of line only
             #
             $CompareStr = substr($line, 0, $ORA03114TAGLEN);

             #
             # Something very bad happened here
             #
             if (($CompareStr eq $ORA03114TAG) ||
                 ($CompareStr eq $SP20604TAG))
             {

                 #
                 # If Invalidated already then we are done read
                 # next line
                 #
                 $bFoundIt = catctlFindConId($LastContainerId);
                 if ($bFoundIt == $TRUE)
                 {
                     next;
                 }

                 $gbErrorFound      = $TRUE;
                 $gbNotConnectMsg   = $TRUE;
                 $giPostUpgStat     = $PSTUPGWITHERR;
                 $RetMsg            = $RetMsg.$POSTUPGERRMSG.
                     "$LastContainer Id: $LastContainerId\n".
                     "     ERROR FOUND: Not Connected To ORACLE\n".
                     "        FILENAME: $LogFile AT LINE NUMBER: $LineNo\n";

                 $giRetCode = catctlInvalidateRDBMS($LastContainer,
                                                    $LastContainerId);
                 if ($giRetCode)
                 {
                     close (FileIn);
                     die "$MSGFCATCONEXEC $!";
                 }
                 next;
             }
         }
 
         #
         # Scan the first few characters of the line 
         # Only if we are scanning for a pfile.
         #
         if (($ReadFlag == $READPFILE) || ($ReadFlag == $READERRORS))
         {
             #
             # Look for Errors
             #
             if (length($line) > $CATCTLERRORTAGLEN)
             {
                 #
                 # Look for Tag at the beginning of line only
                 #
                 $CompareStr = substr($line, 0, $CATCTLERRORTAGLEN);

                 #
                 # If we find the Error Tag
                 # collect the con id for the
                 # error.  We will use this to
                 # Test if we need to run
                 # Post upgrade.
                 #
                 if ($CompareStr eq $CATCTLERRORTAG)
                 {
                     $giPostUpgStat     = $PSTUPGWITHERR;
                     $RetMsg            = $RetMsg.$POSTUPGERRMSG.
                     "$LastContainer Id: $LastContainerId\n".
                     "        ERRORS FOUND: during upgrade $line\n";
                     $bCatctlErrors = $TRUE;
                     $gbErrorFound  = $TRUE;
                 }
             }

             #
             # Look for PFile
             #
             if (length($line) > $PFILETAGLEN)
             {
                 #
                 # Look for Tag at the beginning of line only
                 #
                 $CompareStr = substr($line, 0, $PFILETAGLEN);

                 #
                 # If we find the Pfile Tag
                 # then we can parse out the pfile name
                 #
                 if ($CompareStr eq $PFILETAG)
                 {
                     $gspFileName  = substr($line, $PFILETAGLEN, 
                                         length($line)-$PFILETAGLEN);
                     push (@files_to_delete, $gspFileName); 
                     $gbFoundPfile = $TRUE;
                 }
             }
         } # End if for PFile Search

     } # End while loop

     #
     # Close file
     #
     close (FileIn);

 } # End looping on log files

 #
 # Check pfile catcon
 #
 if ($ReadFlag == $READPFILE)
 {
     #
     # Did not find the pfile and no errors found catcon
     #
     if ($gbFoundPfile == $FALSE) 
     {
         $gbErrorFound      = $TRUE;
         $giPostUpgStat     = $PSTUPGNORUN;
         $RetMsg            = $RetMsg.$MSGFCANFINDPFILE;
     }
 }

 return ($RetMsg);


} # End of catctlReadLogFiles


######################################################################
# 
# catctlScanSqlFiles - Subroutine to recursive scan through the 
#                      .sql control files
#
# Description: This routines parses the .sql files looking for the
#              --CATCTL and --CATFILE tags.  Placement of these
#              specific tags in .sql files determines how to
#              group the .sql and .plb files.  These groups make
#              up each of the phases.
#
# Parameters:
#   - None
######################################################################
sub catctlScanSqlFiles
{

   # global $gidepth variable tracks recursion of -X scripts
 
   my $path = $_[0];   # first argument is file name
   my $thread;
   my @scripts;        # Sql scripts Array
   my @x;              # Depth Counter Array
   my $i = 0;          # Index

   # open the file to read from and load lines starting with @
   open(FileIn, '<', $path) or die "$MSGFCATCTLSCANSQLFILES $path: $!";
   @{$scripts[$gidepth]}= grep { /^@/ | /--CAT/ }<FileIn>;
   close (FileIn);

   if ($gbDisplayPhases)
   {
       if ( $#{$scripts[$gidepth]} < 0) {
           catctlPrintMsg("$MSGWNOSCRIPTSFOUND $path\n",$FALSE,$TRUE);
           return;  ## no scripts found
       } else {
           catctlPrintMsg("$#{$scripts[$gidepth]} $MSGWSCRIPTSFOUND $path\n",
                          $FALSE,$TRUE);
       }
   }

   # analyze scripts for control commands and populate control arrays
   for ($x[$gidepth] = 0; $x[$gidepth] < @{$scripts[$gidepth]}; $x[$gidepth]++) 
   {
     $i = $x[$gidepth];
     my $thread = $SINGLE;
     my $new_path;
     my $file;
     my $noofcompile;

     #
     # Ignore sqlsessstart.sql and sqlsessend.sql for our driver files.
     # We don't want them involved in the processing of the SQL.
     # ORACLE_SCRIPT is set in our session scripts for these files.
     #
     if (index($scripts[$gidepth][$i], $SESSIONSTARTSQL) != -1 ||
         index($scripts[$gidepth][$i], $SESSIONENDSQL)   != -1)
     {
         next;
     }

     #
     # only @@ scripts or --CATCTL lines can be in catctl files
     #
     if (substr($scripts[$gidepth][$i],0,8) eq "$CATCTLTAG") {
         # new phase
         if ((index($scripts[$gidepth][$i], "$CATCTLMTAG") > 0) ||
             (index($scripts[$gidepth][$i], "$CATCTLMETAG") > 0))
         {
              $thread = $MULTI;
         }
         else
         {
              $thread = $SINGLE;  # default to Single
         }
         push(@phase_type,$thread);
         push(@phase_files,[]);
         push (@phase_compile, $gbLoadWithComp);
         $noofcompile = $#phase_compile;

         #
         # Want to look at the last entry to
         # carry it forward to the next phase
         #
         if ($noofcompile != 0)
         {
             $phase_compile[$noofcompile] = $phase_compile[$noofcompile-1];
         }

         #
         # Start Load without Compile
         #
         if (index($scripts[$gidepth][$i], "$CATCTLCSTAG") > 0) {
             push(@{$phase_files[$#phase_files]}, $LOADCOMPILEOFF);
             $phase_compile[$noofcompile] = $gbLoadWithoutComp;
         }

         #
         # End Load without Compile
         #
         if (index($scripts[$gidepth][$i], "$CATCTLCETAG") > 0) {
             push(@{$phase_files[$#phase_files]}, $LOADCOMPILEON);
             $phase_compile[$noofcompile] = $gbLoadWithComp;
         }

         #
         # Run This file in catctl.pl only. Does not run in catupgrd.sql
         # Format is --CATCTL -SE filename.sql filename.sql ... EOL
         # We execute an -SE tag the same as we execute the -S tag the
         # only difference is that the sql found under this tag is the form of
         # a comment and does not get executed if the script is run at the
         # SQL command prompt.
         #
         if ((index($scripts[$gidepth][$i], $CATCTLSETAG) > 0) ||
             (index($scripts[$gidepth][$i], $CATCTLMETAG) > 0))
         {
             if (!$gbByPassPostUpg)
             {
                 my $tag   = "";
                 my $files = "";
                 my $idx   = "";

                 if ($thread == $MULTI)
                 {
                     $tag = $CATCTLTAG." ".$CATCTLMETAG." ";
                 }
                 else
                 {
                     $tag = $CATCTLTAG." ".$CATCTLSETAG." ";
                 }

                 # Skip tag info and parse out first file
                 $files = substr($scripts[$gidepth][$i], length($tag));
                 $idx   = index($files, " ");
                 $file  = substr($files, 0, $idx);

                 #
                 # While not at end of line add files into phase
                 #
                 while ($file ne $EOLTAG)
                 {
                     #
                     # Don't shutdown the database if open mode is normal
                     # Only done after post upgrade has run.
                     #
                     if (($gbOpenModeNormal) && 
                         (($file eq $SHUTDOWNPDBJOB) ||
                          ($file eq $SHUTDOWNJOB)))
                     {
                         $file = $NOTHINGJOB;
                     }
                     #
                     # Add File to the phase
                     #
                     push(@{$phase_files[$#phase_files]}, $file);
                     #
                     # Move to the next file
                     #
                     $files = substr($files, $idx+1);
                     $idx   = index($files, " ");
                     $file  = substr($files, 0, $idx);
                 }
             }
             else
             {
                 #
                 # Add Nothing.sql to phase -x option specified
                 #
                 my $tmpvar = $NOTHINGJOB;
                 push(@{$phase_files[$#phase_files]}, $tmpvar);
             }
         }


         # This tells us to restart the sql process
         if (index($scripts[$gidepth][$i], "$CATCTLRESTARTTAG") > 0) {
             push(@{$phase_files[$#phase_files]}, $RESTART);
         }
     } else {
        # new script
        if (substr($scripts[$gidepth][$i],0,2) eq "$CATCTLATATTAG") {
           # process script
           my $ctl = index($scripts[$gidepth][$i],"$CATCTLCATFILETAG");
           my $idx = index($scripts[$gidepth][$i]," ");
           $idx = $idx > 0 ? $idx : index($scripts[$gidepth][$i],"\n");
           $file = substr($scripts[$gidepth][$i],2,$idx-2);

           # add .sql if no suffix
           $idx = index($scripts[$gidepth][$i],".");
           $file = $idx > 0 ? $file : $file . "$SQLEXTNTAG";

           if ($ctl > 0)
           {
              # Only process -X files, -I files are ignored
              if (index($scripts[$gidepth][$i], "$CATCTLXTAG", $ctl) > 0) {
                  $new_path = $giUseDir ? $gSrcDir."/".$file : $file;
                  if ($gbDisplayPhases)
                  {
                      catctlPrintMsg("$MSGWNEXTPATH $new_path\n",$FALSE,$TRUE);
                  }
                  $gidepth++;
                  catctlScanSqlFiles($new_path);
                  $gidepth--;
              }

              # Process Session Files
              if (index($scripts[$gidepth][$i], $CATCTLSESSIONTAG, $ctl) > 0)
              {
                  my $tmpvar = $giUseDir ? "@".$gSrcDir."/".$file : "@".$file;
                  push (@session_files, $tmpvar);    # Session File
                  push (@session_phase, $#phase_type); # Session Phase
              }


           } else {  # add file to array of files for current phase
              # store script to run
              push(@{$phase_files[$#phase_files]}, "$CATCTLATTAG".$file);   
           }
         } else {  # not @@ or --CATCTL
              catctlPrintMsg(
               "$MSGWLINENOTPROCESSED $scripts[$gidepth][$i]\n",
               $FALSE,$TRUE);
	 }
     }  # end of line check
   }  # end of for loop
}  # End of catctlScanSqlFiles



######################################################################
# 
# catctlPostUpgrade - Call post upgrade routine
#
# Description:
#   This subroutine calls the startup database routine
#
#
# Parameters:
#   - Inclusion list (IN)
#   - Exclusion list (IN)
#   - Open Database Mode (IN)
######################################################################
sub catctlPostUpgrade {

    my $pInclusion   = $_[0];   # Inclusion List for Containers
    my $pExclusion   = $_[1];   # Exclusion List for Containers
    my $pDBOpenMode  = $_[2];   # Open Database Mode

    #
    # No opt get out
    #
    if ($giPostUpgStat == $PSTUPGNORUN)
    {
        return;
    }

    #
    # Startup the database
    #
    catctlStartDatabase($pInclusion,$pExclusion,$pDBOpenMode);

} # end catctlPostUpgrade


######################################################################
# 
# catctlCreateSqlFile - Create Sql File
#
# Description:
#   This subroutine create a Random Sql File given with the contents
#   of pSql.
#
#
# Parameters:
#   pSql - Sql to write to file (IN)
#   pFileName - Sql Filename to Append (IN)
#   Returns Sql File Name
######################################################################
sub catctlCreateSqlFile {

    my $pSql = $_[0];     # Sql to write to file
    my $pFileName = $_[1]; # Filename to append
    my $RandomNo = rand();
    my $RetFileName = $gsSpoolLog.$giProcess.$RandomNo.".sql"; # Ret Filename
    my $CreateFileName = 0; # Create File Name
    my $TmpFh = 0;

    #
    # Use Filename to create Temp file
    #
    if ($pFileName)
    {
        $RetFileName = $gsSpoolLog.$pFileName.$giProcess.$RandomNo.".sql";
    }

    #
    # Catcon Expects files to be in gSrcDir if it is specified otherwise
    # defaults to where your running from.
    #
    $CreateFileName = $giUseDir ? $gSrcDir."/".$RetFileName : $RetFileName; 

    #
    # Create Sql File
    #
    $TmpFh = open(FileOut, '>', $CreateFileName) or 
                die "$MSGFCATCTLCREATESQLFILE - $CreateFileName $!";

    #
    # Output to Temp File
    #
    print FileOut "$pSql";

    #
    # Close the Temp File
    #
    close(FileOut);

    return $RetFileName;
  

} # end catctlCreateSqlFile

######################################################################
# 
# catctlLogErrors - Log Errors
#
# Description:
#   This subroutine logs errors found in the upgrade at the time
#   it was called.
#
#
# Parameters:
#   - Inclusion List for Containers (IN)
#   - Exclusion List for Containers (IN)
#   - SQL identifier (IN)
######################################################################
sub catctlLogErrors {

    my $Inclusion       = $_[0];  # Inclusion List for Containers
    my $Exclusion       = $_[1];  # Exclusion List for Containers
    my $SqlIdentifier   = $_[2];  # SQL Identifier
    my $SqlCmd = "";
    my $TmpFileName = 0;
    my $AtTmpFileName = 0;

    #
    # Run everywhere
    #    
    $SqlCmd = "set linesize 5000;\nset serveroutput on;\nset echo off;\n";
    $SqlCmd = $SqlCmd.$CATCONDSPTAG;
    $SqlCmd = $SqlCmd."declare\n";
    $SqlCmd = $SqlCmd."cnt         NUMBER:=0;\n";
    $SqlCmd = $SqlCmd."begin sys.dbms_output.put_line ('$BANNERTAG');\n";
    #
    # Check for errors
    #
    $SqlCmd = $SqlCmd.$gsSelectErrors;
    $SqlCmd = $SqlCmd."if cnt > 0 then sys.dbms_output.put_line ";
    $SqlCmd = $SqlCmd."('$CATCTLERRORTAG' || cnt);\n";
    $SqlCmd = $SqlCmd."for i in (select identifier,message,statement,timestamp,script ";
    $SqlCmd = $SqlCmd."from $ERRORTABLE order by timestamp)\n loop\n";
    $SqlCmd = $SqlCmd."sys.dbms_output.put_line ('$LINETAG');\n";
    $SqlCmd = $SqlCmd.
        "sys.dbms_output.put_line('Identifier ' || substr(i.identifier,1,10)
                                  || ' ' || 
                                  to_char(i.timestamp,'YY-MM-DD HH:MI:SS') ||
                                  ' Script = ' || substr(i.script,1,40));\n";
    $SqlCmd = $SqlCmd.
        "sys.dbms_output.put_line('ERROR = [' || i.message || ']');\n";
    $SqlCmd = $SqlCmd.
        "sys.dbms_output.put_line('STATEMENT = [' || i.statement || ']');\n";
    $SqlCmd = $SqlCmd."sys.dbms_output.put_line ('$LINETAG');\nend loop;\n";
    $SqlCmd = $SqlCmd."sys.dbms_output.put_line('$CATCTLERRORTAGEND ERRORS');\n";
    $SqlCmd = $SqlCmd."else\n";
    $SqlCmd = $SqlCmd."sys.dbms_output.put_line('NO ERRORS IN $ERRORTABLE');\n";
    $SqlCmd = $SqlCmd."end if;\n";
    $SqlCmd = $SqlCmd."sys.dbms_output.put_line ('$BANNERTAG');\n";
    $SqlCmd = $SqlCmd."end;";
    $SqlCmd = $SqlCmd.$SQLTERM;
    $SqlCmd = $SqlCmd."set serveroutput off;\nset echo on;\n";

    #
    # Create the Temporary Sql File
    #
    $TmpFileName = catctlCreateSqlFile($SqlCmd,0);
    $AtTmpFileName = "\@".$TmpFileName;

    #
    # Log Errors  
    #
    $SqlAry[0] = $AtTmpFileName;
    $giRetCode =
        catconExec(@SqlAry, 
                   1,  # run single-threaded
                   0,  # run in every Container if the DB is Consolidated
                   0,  # Don't issue process init/completion statements
                   $Inclusion,
                   $Exclusion,
                   $SqlIdentifier);
    #
    # Delete Temp File
    #
    if (-e $TmpFileName)
    {
        unlink($TmpFileName);
    }

    #
    # Check Return Code
    #
    if ($giRetCode)
    {
        die "$MSGFCATCONEXEC $!";
    }
}

######################################################################
# 
# catctlCreatePFile - Create database pfile
#
# Description:
#   This subroutine create the database pfile from memory using SQL and
#   writes the status to the spool log.
#
#
# Parameters:
#   - None
######################################################################
sub catctlCreatePFile {

    my $PfileCmd = "";
    my $TmpFileName = 0;
    my $AtTmpFileName = 0;

    #
    # Just get out if this is an pdb instance
    #
    if ($gbInstance)
    {
        return;
    }

    #
    # Don't Create Pfile if we are not running post upgrade
    # We need to create the Pfile if we are running in a CDB
    # since we will continue processing the pdb$seed and pdb's.
    # But we must first restart the CDB$ROOT before we do this.
    #
    if (($giPostUpgStat == $PSTUPGNORUN) &&
        (!$gbCdbDatabase))
    {
        return;
    }

    #
    # Don't Create Pfile if we already created it.
    #
    if ($gbCreatePfile == $TRUE)
    {
        return;
    }

    #
    # Build the PL/SQL Block to create and display the pfile
    #

    #
    # Problem ORA-65040 operation not allowed in a plugable database.
    # Because we commented out in Andre's code.  Run in Root Only
    #
    #
    # Alter session on a cdb database
    #
    if ($gbCdbDatabase)
    {
        $PfileCmd = $CDBSETROOT;
    }
    $TmpFileName = $giUseDir ? "@".$gSrcDir."/".$UTLUCDIRNAM : $UTLUCDIR;
    $PfileCmd = $PfileCmd.$TmpFileName."\n";
    $PfileCmd = $PfileCmd.
        "set linesize 500;\nset serveroutput on;\nset echo off;\n";
    $PfileCmd = $PfileCmd.
        "begin\n sys.dbms_output.put_line ('$BANNERTAG');\n";
    $PfileCmd = $PfileCmd."sys.dbms_output.put_line ".
        "('$PFILETAG' || sys.dbms_registry_sys.gen_pfile_from_memory());\n";
    $PfileCmd = $PfileCmd.
        "sys.dbms_output.put_line ('$BANNERTAG');\n end;\n";
    $PfileCmd = $PfileCmd.$SQLTERM;
    $PfileCmd = $PfileCmd."set serveroutput off;\nset echo on;\n";

    #
    # Create Tempory Sql File
    #
    $TmpFileName = catctlCreateSqlFile($PfileCmd,0);
    $AtTmpFileName = "\@".$TmpFileName;

    #
    # Set the Root because of
    # Problem ORA-65040 operation not allowed in a plugable database.
    # Because we commented out in catcon code.
    #
    $SqlAry[0] = $AtTmpFileName;
    $giRetCode =
        catconExec(@SqlAry, 
                   1,  # run single-threaded
                   1,  # run in root only
                   0,  # Don't issue process init/completion statements
                   $gsNoInclusion,     # No Inclusion list 
                   $gsNoExclusion,     # No Exclusion List
                   $gsNoIdentifier);   # No SQL Identifier

    #
    # Delete Temp File
    #
    if (-e $TmpFileName)
    {
        unlink($TmpFileName);
    }

    #
    # Check Return Code
    #
    if ($giRetCode)
    {
        die "$MSGFCATCONEXEC $!";
    }

    $gbCreatePfile = $TRUE;

} # end catctlCreatePFile


######################################################################
# 
# catctlStartDatabase - Start the Database 
#
# Description:
#   This subroutine starts up the database given a pfile.
#   By default the database is open in normal mode with
#   restricted access.  If the open flag is set the database
#   is opened in normal mode without the restricted access.
#
# Parameters:
#   - Inclusion list (IN)
#   - Exclusion list (IN)
#   - Open Database Mode (IN)
######################################################################
sub catctlStartDatabase {

    my $pInclusion     = $_[0];   # Inclusion List for Containers
    my $pExclusion     = $_[1];   # Exclusion List for Containers
    my $pDBOpenMode    = $_[2];   # Open Database Mode
    my $OpenCommand    = "";
    my $PlugCommand    = "";
    my $PlugCommand2   = "";
    my $TmpFileName    = 0;
    my $AtTmpFileName  = 0;
    my $sInclusion     = $gsNoInclusion;  # Default no Inclusion List
    my $sExclusion     = $gsNoExclusion;  # Default no Inclusion List
    my $runwhere       = $RUNROOTONLY;    # Default Run Root Only
    my $bDBRestarted   = $TRUE;           # Assume True
    my $x = 0;
    my $ClosePdb       = "";
    my $ErrMsg         = "";              # Error Message

    #
    # Close all session except one
    #
    $giRetCode = catconUpgEndSessions();


    #
    # Troll Log Files
    #
    if ($pDBOpenMode == $DBOPENNORMAL)   
    {
        #
        # Only Look for Pfile if Root or
        # Not a CDB Database
        #
        if (($gbRootProcessing) ||
            (!$gbCdbDatabase))
        {
            #
            # Look for pfile in the log file
            #
            $ErrMsg = catctlReadLogFiles($READPFILE);
            if ($ErrMsg)
            {
                $gsPostUpgMsg = $gsPostUpgMsg.$ErrMsg;
            }

            #
            # If Errors found get out
            #
            if ($gbErrorFound     == $TRUE)
            {
                return;
            }
        }
    }

    $ClosePdb = "begin execute immediate 'alter pluggable ".
        "database $PDBSEED close immediate instances=all';\n".
        "exception when others then if sqlcode = -65020 then null;\n".
        "else raise; end if; end;".$SQLTERM;

    #
    # Open Mode Normal or Restricted 
    #
    if ($gbCdbDatabase)
    {
        #
        # Start Root database in upgrade mode or normal mode
        #
        if ($gbUpgradeMode)
        {
            $OpenCommand  = "startup upgrade pfile=$gspFileName;\n";
            $gbRootOpenInUpgMode = $TRUE;
        }
        else
        {
            $OpenCommand  = "startup pfile=$gspFileName;\n";
        }

        #
        # Pdb Processing
        #
        if ($gbOpenModeNormal)
        {
            $PlugCommand2 = "alter pluggable database open;\n";
        }
        else
        {
            $PlugCommand2 = "alter pluggable database open restricted;\n";
        }

        #
        # If Root opened in upgrade mode then everybody
        # else must be opened in upgrade mode
        #
        if ($gbRootOpenInUpgMode)
        {
            $PlugCommand2 = "alter pluggable database open upgrade;\n";
        }

        #
        # Seed Processing
        #
        if ($gbSeedProcessing)
        {
            #
            # Open Read write or Upgrade
            #
            if ($gbRootOpenInUpgMode)
            {
                $PlugCommand2  = $ClosePdb."alter pluggable database $PDBSEED "
                    ."open upgrade;\n";
            }
            else
            {
                $PlugCommand2  = $ClosePdb."alter pluggable database "
                    ."$PDBSEED open read write restricted;\n";
            }
        }
    }
    else
    {
        if ($gbOpenModeNormal)
        {
            $OpenCommand  = "startup pfile=$gspFileName;\n";
        }
        else
        {
            $OpenCommand  = "startup restrict pfile=$gspFileName;\n";
        }
    }

    #
    # Don't startup the database in a CDB if we are not
    # processing the root.  We didn't shut it down.
    #
    if (($gbCdbDatabase) && 
        (!$gbRootProcessing) && 
        ($pDBOpenMode == $DBOPENNORMAL))
    {
        $OpenCommand  = "";
        $PlugCommand  = $PlugCommand2;   # Startup PDB's for Post Upgrade
        $bDBRestarted = $FALSE;          # DataBase Not Restarted
        $sInclusion   = $pInclusion;     # Inclusion List
        $sExclusion   = $pExclusion;     # Exclusion List
        $runwhere     = $RUNEVERYWHERE;  # Run Everywhere
    }

    #
    # Root already started in normal mode 
    # Open Seed database in read only mode
    #
    if (($gbCdbDatabase) &&
	($pDBOpenMode == $DBOPENROSEED))
    {
        #
        # Close any instances on the seed
        # and reopen read only
        #
        $OpenCommand  = "";
        $PlugCommand  = $ClosePdb."alter pluggable database $PDBSEED ".
                        "open read only instances=all;\n";

        #
        # If Root opened in upgrade mode then everybody
        # else must be opened in upgrade mode
        #
        if ($gbRootOpenInUpgMode)
        {
            $PlugCommand = $ClosePdb.
                "alter pluggable database open upgrade;\n";
        }

        $bDBRestarted = $FALSE;          # DataBase Not Restarted
        $sInclusion   = $pInclusion;     # Inclusion List
        $sExclusion   = $pExclusion;     # Exclusion List
        $runwhere     = $RUNEVERYWHERE;  # Run Everywhere 
    }

    #
    # Root already started in normal mode
    # Startup the PDB in Upgrade Mode ignore
    # PDB already open messages. If already
    # in upgrade mode then do nothing.
    # Ignore ORA-24344 if the PDB is opened
    # with warnings.
    #
    if (($gbCdbDatabase) && 
        ($pDBOpenMode == $DBOPENUPGPDB))
    {
        $OpenCommand  = "";
        $PlugCommand  = "DECLARE\n stat VARCHAR2(30) := '';\n".
          "BEGIN\n select status into stat from v\$instance;\n".
          "  IF stat != 'OPEN MIGRATE' THEN\n".
          "    BEGIN\n      execute immediate 'alter pluggable database ".
          "open upgrade';\n      exception when others then ".
          "if sqlcode = -65019 or sqlcode = -24344 then null;\n".
          "else raise; end if;\n    END;\n".
          "  END IF;\n END;\n".$SQLTERM;
        $bDBRestarted = $FALSE;          # DataBase Not Restarted
        $sInclusion   = $pInclusion;     # Inclusion List
        $sExclusion   = $pExclusion;     # Exclusion List
        $runwhere     = $RUNEVERYWHERE;  # Run Everywhere 
    }

    #
    # Root already started. Open
    # Seed in upgrade mode
    #
    if (($gbCdbDatabase) && 
        ($pDBOpenMode == $DBOPENUPGSEED))
    {

        #
        # Close any instances on the seed
        # and reopen in upgrade mode
        #
        $OpenCommand  = "";
        $PlugCommand  = $ClosePdb."alter pluggable database $PDBSEED ".
                        "open upgrade;\n";

        $bDBRestarted = $FALSE;          # DataBase Not Restarted
        $sInclusion   = $pInclusion;     # Inclusion List
        $sExclusion   = $pExclusion;     # Exclusion List
        $runwhere     = $RUNEVERYWHERE;  # Run Everywhere 
    }


    #
    # Open Database and PDB's
    #
    if ($gbCdbDatabase)
    {
        #
        # Only set oracle script if
        # we are not restarting the
        # database
        #
        if ($bDBRestarted)
        {
            $OpenCommand = $OpenCommand.$PlugCommand;
        }
        else
        {   
            $OpenCommand = $ORCLSCIPTTRUE.$OpenCommand.$PlugCommand;
        }
    }

    #
    # Create the Temporary Sql File
    #
    $TmpFileName = catctlCreateSqlFile($OpenCommand,0);
    $AtTmpFileName = "\@".$TmpFileName;

    #
    # Startup the database
    #
    $SqlAry[0] = $AtTmpFileName;
    $giRetCode =
        catconExec(@SqlAry, 
                   1,  # run single-threaded
                   $runwhere, # run in root only or everywhere
                   0,  # Don't issue process init/completion statements
                   $sInclusion,        # Inclusion list 
                   $sExclusion,        # Exclusion List
                   $gsNoIdentifier);   # No SQL Identifier

    #
    # Delete the tmp file
    #
    if (-e $TmpFileName)
    {
        unlink($TmpFileName);
    }


    if ($giRetCode)
    {
        die "$MSGFCATCONEXEC $!";
    }

    #
    # Restart and Bounce the Sessions
    #
    $giRetCode = catconUpgStartSessions($giProcess);
    $giRetCode = catconBounceProcesses();
    if ($giRetCode)
    {
        die "$MSGFCATCONBOUNCEPROCESSES $!";
    }

} # end catctlStartDatabase

######################################################################
# 
# catctlShutDownDatabase - ShutDown the Database
#
# Description:
#   Shutdown the database
#
# Parameters:
#   pSqlScript   - Sql Shutdown Script to Run
#   pWhereToRun  - Flag to Run in Root or everywhere
#   pInclusion =  (IN) Inclusion List for Containers
#   pExclusion =  (IN) Exclusion List for Containers
######################################################################
sub catctlShutDownDatabase {

    my $pSqlScript  = $_[0];  # Sql Script to run
    my $pWhereToRun = $_[1];  # Run in Root Only or EveryWhere
    my $pInclusion  = $_[2];  # Inclusion List for Containers
    my $pExclusion  = $_[3];  # Exclusion List for Containers

    #
    # Guarantee Process complete before
    # we shutdown the database
    #
    $giRetCode = catconBounceProcesses();
    if ($giRetCode)
    {
        die "$MSGFCATCONBOUNCEPROCESSES $!";
    }

    #
    # Flush out left over processors
    #
    $SqlAry[0] = $NOTHINGJOB;
    $giRetCode =
        catconExec(@SqlAry, 
                   1,             # run single-threaded
                   $pWhereToRun,  # Where to run command
                   0, # Don't issue process init/completion statements
                   $pInclusion,     # Inclusion list 
                   $pExclusion,     # Exclusion List
                   $gsNoIdentifier);   # No SQL Identifier

    if ($giRetCode)
    {
        die "$MSGFCATCONEXEC $!";
    }

    $SqlAry[0] = $pSqlScript;
    $giRetCode =
        catconExec(@SqlAry, 
                   1,             # run single-threaded
                   $pWhereToRun,  # Where to run command
                   0, # Don't issue process init/completion statements
                   $pInclusion,     # Inclusion list 
                   $pExclusion,     # Exclusion List
                   $gsNoIdentifier);   # No SQL Identifier

    if ($giRetCode)
    {
        die "$MSGFCATCONEXEC $!";
    }

} # end catctlShutDownDatabase


######################################################################
# 
# catctlPrintMsg - Print Message to STDERR and store results.
#
# Description:
#   Print Message to Screen and store results.  This will allows
#   us to dump messages to log file.
#
# Parameters:
#   pMsg     - Message to Print
#   pbLogMsg - Log Message to catupgrd0.log
#   pbLogScreen -  Log Message to screen
######################################################################
sub catctlPrintMsg {
    my $pMsg     = $_[0];    # Message to Print
    my $pbLogMsg = $_[1];    # Log Message to file
    my $pbLogScreen = $_[2]; # Print to Screen

    #
    # Accumlate message to write to log file
    #
    if ($pbLogMsg)
    {
        $gsPrintCmds =  $gsPrintCmds.$pMsg;
    }

    #
    # Print message to screen
    #
    if ($pbLogScreen)
    {
        print STDERR "$pMsg";
    }
}  #End catctlPrintMsg

######################################################################
# 
# catctlWriteTraceMsg - Write trace messages to log files.
#
# Description:
#   Write trace messages to log files.
#
# Parameters:
#   None
######################################################################
sub catctlWriteTraceMsg
{
        my $psErrorMsg   = $_[0];   # Trace Mesage
        my $TraceLogFile = $gsSpoolLogDir."_trace.log";
        my $SpoolLogFile = $gsSpoolLogDir."0.log";

        #
        # Print Final Messages
        #
        catctlPrintMsg("$psErrorMsg", $TRUE,$FALSE);
        catctlPrintMsg("LOG FILES: ($gsSpoolLog*.log) ($gsSpoolLog\_trace.log)\n",
                       $TRUE,$TRUE);

        #
        # Write trace file for write
        #
        open (FileOut, '>', $TraceLogFile) or 
            die "$MSGFCATCTLWRITELOGFILES - $TraceLogFile $!";
        print FileOut "\n$gsPrintCmds\n";
        close (FileOut);

        #
        # Open Log file for append
        #
        open (FileOut, '>>', $SpoolLogFile) or 
            die "$MSGFCATCTLWRITELOGFILES - $SpoolLogFile $!";
        print FileOut "\n$gsPrintCmds\n";
        close (FileOut);

}  #End catctlWriteTraceMsg

######################################################################
# 
# catctlWriteStdErrMsgs - Write STDERR MessageS to log file.
#
# Description:
#   Write all STDERR Msgs to the end of the log file.
#
# Parameters:
#   None
######################################################################
sub catctlWriteStdErrMsgs {

    my $LogFile = $gsSpoolLogDir."0.log";
    my $Line = "";
    my $TOTALTAG = "Total Upgrade Time: ";
    my $idx1 = 0;
    my $counter = 0;
    my @GrandTotals;
    my @SortedTotals;
    my $Days  = int($gtTotSec/(24*60*60));
    my $Hours = ($gtTotSec/(60*60))%24;
    my $Mins  = ($gtTotSec/60)%60;
    my $Sec   = $gtTotSec%60;
    my $TotalTime = "Grand $TOTALTAG   [";

    #
    # If a pdb is being processed
    # then just say total upgrade
    # time.
    #
    if ($gbInstance)
    {
        $TotalTime = "$TOTALTAG         [";
    }

    #
    # Put together the display for the user
    #
    $TotalTime = $TotalTime.$Days.$DSPDAYS.":".
                 $Hours.$DSPHRS.":".$Mins.$DSPMINS.":".
                 $Sec.$DSPSECS."]";
    #
    # Display Total Time in human readable format
    #
    catctlPrintMsg ("\n$TotalTime\n",$TRUE,$TRUE);

    #
    # Open catupgrd0.log and Write stderr messages and close file
    #
    open (FileOut, '>>', $LogFile) or 
        die "$MSGFCATCTLWRITELOGFILES - $LogFile $!";
    print FileOut "\n$gsPrintCmds\n";

    # 17277459: Append datapatch logs also
    if (-e $gsDatapatchLogUpgrade) {
      print FileOut "$MSGIDP_OUT_UPGRADE\n";
      open (FileIn, '<', $gsDatapatchLogUpgrade);
      while (<FileIn>)
      {
        print FileOut $_;
      }
      close (FileIn);
    }

    if (-e $gsDatapatchErrUpgrade) {
      print FileOut "$MSGIDP_ERR_UPGRADE\n";
      open (FileIn, '<', $gsDatapatchErrUpgrade);
      while (<FileIn>)
      {
        print FileOut $_;
      }
      close (FileIn);
    }

    if (-e $gsDatapatchLogNormal) {
      print FileOut "$MSGIDP_OUT_NORMAL\n";
      open (FileIn, '<', $gsDatapatchLogNormal);
      while (<FileIn>)
      {
        print FileOut $_;
      }
      close (FileIn);
    }

    if (-e $gsDatapatchErrNormal) {
      print FileOut "$MSGIDP_ERR_NORMAL\n";
      open (FileIn, '<', $gsDatapatchErrNormal);
      while (<FileIn>)
      {
        print FileOut $_;
      }
      close (FileIn);
    }

    close (FileOut);

    #
    # Open catupgrd0.log and Write Summary report at the end
    # of our log file.  We don't do it for individual PDB's
    # wanted to avoid the overhead.
    #
    if (($gsReportName) && (!$gbInstance))
    {
        open (FileOut, '>>', $LogFile) or 
            die "$MSGFCATCTLWRITELOGFILES - Writing $LogFile $!";
        open (FileIn, '<', $gsReportName) or
            die "$MSGFCATCTLWRITELOGFILES - Reading $gsReportName $!";
        while(<FileIn>)
        {
             #
             # Store the line
             #
             $Line = $_;
             chomp($Line);

             #
             # Combine Grand Totals for a CDB database
             #
             if ($gbCdbDatabase)
             {
                 $idx1 = index($Line, $TOTALTAG);
                 if ($idx1 != -1)
                 {
                     $counter++;
                     push(@GrandTotals, $Line."\n");
                 }
             }

             #
             # Write the line to log file
             #
             print FileOut "$Line\n";

        }

        #
        # Write combined grand totals at the end catupgrd0.log
        #
        if (($gbCdbDatabase) && ($counter > 1))
        {
            # sort by time at position 21 (note the 20) for length of 8
            # sort in reverse (descending) order, hence the b before a in
            # sort{ cmp } statement
            @SortedTotals = map{$_->[0]}
                            sort {$b->[1] cmp $a->[1]}
                            map {[$_,substr($_,20,8)]} @GrandTotals;

            print FileOut "\nUpgrade Times Sorted In Descending Order\n\n";
            print FileOut @SortedTotals;
        }

        #
        # Write Total Time to catupgrd*0 log file
        #
        print FileOut "$TotalTime\n";

        #
        # Close Files
        #
        close (FileIn);
        close (FileOut);

        open (FileOut, '>>', $gsReportName) or
            die "$MSGFCATCTLWRITELOGFILES - Writing $gsReportName $!";

        #
        # Write combined grand totals at the end of summary report
        #
        if (($gbCdbDatabase) && ($counter > 1))
        {
            print FileOut "\nUpgrade Times Sorted In Descending Order\n\n";
            print FileOut @SortedTotals;
        }

        #
        # Write Total Time to upgrade summary report file
        #
        print FileOut "$TotalTime\n";
        close(FileOut);
    }
}



######################################################################
# 
# catctlGetOpenMode  - Tell us if database is in Migration Mode
#
# Description:
#
#   Tell me weather the root is open in migration mode.
#   If an Inclusion/Exclusion list is used and the rootctl
#   is open in upgrade mode then we can only open the PDB's
#   in upgrade mode.  We must detect this an perform
#   post upgrade procedures in upgrade mode.
#
# Parameters:
#
# Returns:
#   - TRUE  - Root in Upgrade mode
#   - FALSE - Root not in Upgrade mode
#
######################################################################
sub catctlGetOpenMode
{
    my $Mode;
    my $Sql  = "select status from v\$instance;\n";
    my $MIGMODE = "OPEN MIGRATE";


    #
    # Must be in migration mode
    #
    if (!$gbCdbDatabase)
    {
        return ($TRUE);
    }

    #
    # If Processing Root we will restart
    # the database in the correct mode
    # just return false.
    #
    if ($gbRootProcessing)
    {
        return ($FALSE);
    }

    #
    # If we are processing a inclusion list then
    # the root database may have been started
    # in upgrade mode we have to be able
    # to handle that and force the PDB's to
    # start in upgrade mode when we the post upgrade.
    #
    $Mode = catctlQuery ($Sql);

    if ($Mode eq $MIGMODE)
    {
        catctlPrintMsg ("Open Mode             = $Mode\n",$TRUE,$TRUE);
        return ($TRUE);
    }

    return ($FALSE);

}  # End of catctlGetOpenMode

######################################################################
# 
# catctlIsPDBOkay - Is PDB in migrate mode for upgrade or 
#                   read write for post upgrade.
#
# Description:  We call this routine for a container list that
#               is provided to us by the user.  This routine
#               will ensure that the containers specified in
#               the list are in upgrade mode or read write mode
#               for the post upgrade procedures.  If a re-run
#               of an upgrade was specified and any of the
#               pdb containers were in mounted state catcon
#               would kick out the mounted pdb as invalid and
#               stop the re-run.  So now we will only process
#               Pdb's within a list that are in upgrade
#               mode or read write mode for the post upgrade.
#               An example of a case where this would happen
#               is as follows:
#                 perl catctl.pl -C 'CDB$ROOT' catupgrd.sql
#               This means upgrade all the Pdb's. If any of the Pdb's
#               were in mounted state the entire upgrade would have
#               been stopped.
#
# Parameters:
#
#   INPUT - 
#      pContainerName - Container Name
#      pStartPhaseNo  - Start Phase #
#
# Returns:
#   - TRUE  PDB okay to upgrade or run post upgrade
#   - FALSE PDB not okay
#
######################################################################
sub catctlIsPDBOkay
{
    my $pContainerName = $_[0];     # Container Name
    my $pStartPhaseNo  = $_[1];     # Start Phase No
    my $RetStat        = $FALSE;    # Assume Bad
    my $Msg            = "";        # Message
    my $OpenMode       = "";        # Open Mode

    #
    # Check to see if user specified post upgrade run
    # if yes then check pdb is in write mode or
    # upgrade mode.  If no then make sure pdb is in
    # upgrade mode.
    #
    if ($pStartPhaseNo == catctlPostUpgradePhase())
    {
        $Msg = "NO POST UPGRADE WILL BE PERFORMED";
        if (catctlIsWrite($pContainerName) || 
            catctlIsMigrate($pContainerName))
        {
            $RetStat = $TRUE;
        }
    }
    else
    {
        $Msg = "NO UPGRADE WILL BE PERFORMED";
        if (catctlIsMigrate($pContainerName))
        {
            $RetStat = $TRUE;
        }
    }


    #
    # Not in the correct mode
    #
    if (!$gbInstance && !$RetStat)
    {
        $OpenMode = catctlGetMode($pContainerName);
        catctlPrintMsg ("$pContainerName Open Mode = [$OpenMode] ".
                        "$Msg\n", $TRUE,$TRUE);
    }

    return ($RetStat);
}

######################################################################
# 
# catctlGetMode - Get open mode of the database
#
# Description:  Return the mode of the database
#
# Parameters:
#
#   INPUT - Container Name
#
# Returns:
#   - Database Mode (READ WRITE) (MIGRATE) etc...
#
######################################################################
sub catctlGetMode
{
    my $pContainerName = $_[0];    # Container Name
    my $Sql = "select open_mode from v\$containers ".
              "where name = \'$pContainerName\'\n/\n";

    return(catctlQuery ($Sql));

}

######################################################################
# 
# catctlIsMigrate - Is PDB in upgrade mode.
#
# Description:  Check to see if we are in upgrade mode.
#
# Parameters:
#
#   INPUT - Container Name
#
# Returns:
#   - TRUE  PDB in Upgrade Mode
#   - FALSE PDB not in Upgrade Mode
#
######################################################################
sub catctlIsMigrate
{
    my $pContainerName = $_[0];    # Container Name
    my $MIGRATEMODE = "MIGRATE";
    my $OpenMode =  catctlGetMode ($pContainerName);
    my $RetStat  =  $FALSE;

    if ($OpenMode eq $MIGRATEMODE)
    {
        $RetStat = $TRUE;
    }

    #
    # Return TRUE or FALSE
    #
    return $RetStat;
}  # End of catctlIsMigrate

######################################################################
# 
# catctlIsWrite - Is Database in write mode.
#
# Description:  Check to see if the database is in write mode.
# Parameters:
#
#   INPUT - Container Name
#
# Returns:
#   - TRUE  Database/PDB in write mode
#   - FALSE Database/PDB not in write mode
#
######################################################################
sub catctlIsWrite
{
    my $pContainerName = $_[0];    # Container Name
    my $WRITEMODE = "READ WRITE";
    my $OpenMode =  catctlGetMode ($pContainerName);
    my $RetStat  =  $FALSE;

    if ($OpenMode eq $WRITEMODE)
    {
        $RetStat = $TRUE;
    }

    #
    # Return TRUE or FALSE
    #
    return $RetStat;
}  # End of catctlIsWrite

######################################################################
# 
# catctlPostUpgradePhase - Return the Post Upgrade Phase.
#
# Description:  Return the post upgrade phase.
# Parameters:
#
#   None
#
# Returns:
#   - Post Upgrade Phase or zero if not found
#
######################################################################
sub catctlPostUpgradePhase
{
    my $PostUpgradePhase = 0;
    my $i = 0;
    my $NoOfFiles = 0;

    for ($i = 0; $i < @phase_type; $i++) 
    {
        $NoOfFiles = @{$phase_files[$i]};
        #
        # No Files then get next phase
        #
        if ($NoOfFiles == 0)
        {
            next;
        }
        #
        # Check for Post Upgrade
        #
        if ($phase_files[$i][0] eq $POSTUPGRADEJOB)
        {
            $PostUpgradePhase = $i;
            last;
        }
    }

    return ($PostUpgradePhase);

}  # End catctlPostUpgradePhase

######################################################################
# 
# catctlGetCpus      - Get Number of cpus        
#
# Description:
#
# Parameters:
#
# Returns:
#   - Number of cpus
#
######################################################################
sub catctlGetCpus
{
    my $Sql = "select p.value from v\$parameter p where p.name=\'cpu_count\'\n/\n";
    my $NumCores = catctlQuery ($Sql);
 
    catctlPrintMsg ("Number of Cpus        = $NumCores\n",$TRUE,$TRUE);

    #
    # Return Number of cpus
    #
    return $NumCores;
}  # End of catctlGetCpus


######################################################################
# 
# catctlGetDbName - Get Database Name        
#
# Description:  Return Database Unique name
#
# Parameters:
#
# Returns:
#   - Database Name
#
######################################################################
sub catctlGetDbName
{

    #
    # Look up database name if not called yet.
    #
    if (!$gsDbName)
    {
        my $Sql = "select p.value from v\$parameter p ".
            "where p.name=\'db_unique_name\'\n/\n";
        $gsDbName = catctlQuery ($Sql);        
    }

    #
    # Return Database Name
    #
    return $gsDbName;
}  # End of catctlGetDbName


######################################################################
# 
# catctlQuery      - Query returning results
#
# Description:  Simple Query statements return a result set.
#
# Parameters:
#   Input: Sql Statement.
#
# Returns:
#   - Result
#
######################################################################
sub catctlQuery
{
    my $pSql = $_[0];       # Sql Query
    my @RetResults;         # Return Results

    @RetResults = catconQuery ($pSql);

    #
    # Return Results
    #
    return $RetResults[0];

}  # End of catctlQuery

######################################################################
# 
# catctlSetPDBProcessLimits  -  Set PDB process limits
#
# Description:  Set the process limits for how many sql processes
#               will be used during the PDB upgrade.
#
# For PDB.
#
#   Default SQL Processes  = DEFPROC_PDB (2)
#   Max Sql Processes      = MAXPROC_PDB (8)
#
#
# Parameters:
#
# Returns:
#   - The number of SQL Processors
#
######################################################################
sub catctlSetPDBProcessLimits
{
    my $pProcess  = $_[0];    # Number of Process from user
    my $RetSqlProcs = 0;      # Return Number of SQL processors

    #
    # Get out if running serial
    #
    if ($gbSerialRun == $TRUE)
    {
        return($pProcess);
    }

    #
    # Set Equal to what user passed
    #
    $RetSqlProcs = $pProcess;

    #
    # No More than the max
    #
    if ($pProcess > $MAXPROC_PDB)
    {
        $RetSqlProcs = $MAXPROC_PDB;
    }

    #
    # Check for no user input then default
    # the value
    #
    if ($pProcess == $MINPROC)
    {
        $RetSqlProcs = $DEFPROC_PDB;
    }

    #
    # Return Value
    #
    return ($RetSqlProcs);

}

######################################################################
# 
# catctlSetProcessLimits      -  Set process limits
#
# Description:  Set the process limits for how many sql processes
#               will be used during the upgrade.
#
# For Non CDB.
#
#   Default SQL Processes  = DEFPROC_NO_CDB (4)
#   Max Sql Processes      = MAXPROC_NO_CDB (8)
#
# For CDB.
#
#   Default SQL Processes  = # Cpus
#   Max Sql Processes      = $MAXPROC_CDB (64) 
#
#   PDB Instances (Number of PDB upgrades running at the same time)
#   are calculated as follows
#
#   Number of Instances    = (SQL Processes/2)
#   Each Instance          = 2 SQL Processes
#
#   Max Sql Processes for  = $MAXROOT_CDB (8)
#   CDB$ROOT
#   
#
# Parameters:
#
# Returns:
#   - The number of SQL Processors
#
######################################################################
sub catctlSetProcessLimits
{
    my $pCpus     = $_[0];    # Cpu Count
    my $pProcess  = $_[1];    # Number of Process from user
    my $RetSqlProcs = 0;      # Return Number of SQL processors
    my $LogNumber = $pCpus*2; # Number of Logs

    #
    # Get out if running serial
    #
    if ($gbSerialRun == $TRUE)
    {
        return($pProcess);
    }

    #
    # Set Equal to what user passed
    #
    $RetSqlProcs = $pProcess;

    #
    # Set Log number to the higher number
    #
    if ($pProcess > $LogNumber)
    {
        $LogNumber = $pProcess;
    } 
    
    #
    # Calculate Processors
    #
    if (catconIsCDB())
    {
        #
        # Check for the MAX allowed
        #
        if ($pProcess > $MAXPROC_CDB)
        {
            $RetSqlProcs = $MAXPROC_CDB;
        }

        #
        # Check for no user input calculate based
        # on cpu count.
        #
        if ($pProcess == $MINPROC)
        {
            if ($pCpus > $MAXPROC_CDB)
            {
                $RetSqlProcs = $MAXPROC_CDB;
            }
            else
            {
                $RetSqlProcs = $pCpus;
            }
        }

        #
        # Caclulate PDB Instances and make sure it not
        # less the the minimun PDB Instances.
        #
        $giPdbInstances = int($RetSqlProcs/2);
        if ($giPdbInstances < $MINPDBINSTANCES)
        {
            $giPdbInstances = $MINPDBINSTANCES;
        }

        #
        # Print out the Process counts
        #
        if (!$gbInstance)
        {
            catctlPrintMsg ("Parallel PDB Upgrades = $giPdbInstances\n",
                            $TRUE,$TRUE);
        }
        catctlPrintMsg ("SQL PDB Process Count = $giPdbProcess\n",
                        $TRUE,$TRUE);


        #
        # Set Root and Seed Processing down
        # to the max threads
        #
        if ($RetSqlProcs > $MAXROOT_CDB)
        {
            $RetSqlProcs = $MAXROOT_CDB;
        }

    }
    else
    {
        #
        # Check for the MAX allowed otherwise
        # take the default processors.
        #
        if ($pProcess > $MAXPROC_NO_CDB)
        {
            $RetSqlProcs = $MAXPROC_NO_CDB;
        }

        #
        # Check for no user input then default
        # to what we used to do.
        #
        if ($pProcess == $MINPROC)
        {
            $RetSqlProcs = $DEFPROC_NO_CDB;
        }
    }


    #
    # Print the given SQL process Count
    #
    catctlPrintMsg ("SQL Process Count     = $pProcess\n",$TRUE,$TRUE);

    #
    # We only need to do adjust SQL processors if 
    # different than what user gave us or what
    # was caluclate by catcon when given default 0.
    #
    if ($RetSqlProcs != $pProcess)
    {

        #
        # Print the new SQL Process count
        #
        catctlPrintMsg ("New SQL Process Count = $RetSqlProcs\n",$TRUE,$TRUE);

        #
        # End all the Sql session except 1
        #
        $giRetCode = catconUpgEndSessions();

        #
        # Start up all the sessions with new SQL Process count
        #
        $giRetCode = catconUpgStartSessions($RetSqlProcs);

        #
        # Clean up Extra Log Files
        #
        catctlDelLogFiles($RetSqlProcs, $LogNumber-1); 
    }

    #
    # Return the number of SQL Processors
    #
    return($RetSqlProcs);

}  # End of catctlSetProcessLimits


######################################################################
# 
# catctlGetEnv     - Get Environmental Variable
#
# Description:     Get Environmental Variable
#
# Note:
#
# Parameters:
#   INPUT - Environmental Variable
#
# Returns:
#   NULL   - not Found
#   Value  - Value of environmental Variable
#
######################################################################
sub catctlGetEnv
{
    my $pEnvVar     = $_[0];    # Environmental Variable
    my $EnvValue    = $ENV{$pEnvVar};

    return ($EnvValue);

} # catctlGetEnv

######################################################################
# 
# catctlUnSetEnv - Set Environmental Variable
#
# Description:       UnSet Environmental Variable
#
# Note:  Only for this process parent process will remain set.
#
# Parameters:
#   INPUT
#      Environmental Variable
#
# Returns:
#   None
#
######################################################################
sub catctlUnSetEnv
{
    my $pEnvVar     = $_[0];    # Environmental Variable

    delete $ENV{$pEnvVar};

} # catctlUnSetEnv

######################################################################
# 
# catctlSetOSEnv - Set Operating System environment
#
# Description:     Set Operating System environment
#                      Set temp directory.
#
#
# Parameters:
#   None
#
# Returns:
#   None
#
######################################################################
sub catctlSetOSEnv
{
    #
    #   Assume Unix Temp Directory
    #
    $gsTempDir         = "/tmp/";

    #
    # Set Windows Environment
    #
    if ($^O eq 'MSWin32')
    {
        $SLASH       = $WINDOWSLASH;
        $CONTAINERQUOTE = $DOUBLEQUOTE;
        $gsTempDir   = catctlGetEnv("TEMP").$SLASH;
    }

} # end of catctlSetOSEnv

######################################################################
# 
# catctlGetUpgLockFile - Get Lock File to protect against multiple
#                        upgrades on a database.
#
# Description:     Get an exclusive lock on a file to prevent multiple
#                  upgrades on a database.  We will use the database
#                  unique name when creating the lock file so we can
#                  ensure the lock is held for the correct database.
#
#
# Parameters:
#   None
#
# Returns:
#   None
#
######################################################################
sub catctlGetUpgLockFile
{

    #
    # Don't do if catctl instance
    #
    if ($gbInstance)
    {
        return;
    }

    #
    # Lock file is used to prevent two upgrades
    # running at the same time on the same database.
    # Two upgrades may be run on the same system
    # using different databases.
    #

    #
    # Construct the lock file
    #
    $gsUpgLockFile = $gsTempDir.catctlGetDbName().".dat";
    $gsRptLockFile = $gsTempDir.catctlGetDbName().".rpt";

    #
    # Open file
    #
    open ($ghUpgLockFile, '>', $gsUpgLockFile) or
        die "$MSGFERROPENLOCKFILE $gsUpgLockFile\n $!\n";

    #
    # Obtain an exclusive lock or kill ourselves.
    # Only one catctl upgrade per database.  We
    # take out an exclusive lock in non-blocking
    # mode so we don't wait for the lock.  If we
    # cannot get an exclusive lock on the file
    # then we kill ourselves notifying the user
    # that another upgrade process is running.
    # This is done for both CDB and traditional
    # databases.
    #
    flock ($ghUpgLockFile, LOCK_EX|LOCK_NB) or 
        die "$MSGFANOTHERPROCESS $gsUpgLockFile\n $!\n";

    #
    # Delete File at the end
    #
    push (@files_to_delete, $gsUpgLockFile);
    push (@files_to_delete, $gsRptLockFile);

} # end of catctlGetUpgLockFile


######################################################################
# 
# catctlGetRptLockFile - Get Report Lock File to protect against multiple
#                        writes to the summary file.
#
# Description:     Get an exclusive lock on a file to prevent multiple
#                  upgrades on a database.  We will use the database
#                  unique name when creating the lock file so we can
#                  ensure the lock is held for the correct database.
#                  This lock will spin and wait until it can get the
#                  lock.
#
#
# Parameters:
#   None
#
# Returns:
#   None
#
######################################################################
sub catctlGetRptLockFile
{

    my $pEnvVar     = $_[0];    # Environmental Variable

    #
    # Only needed for pdb's
    #
    if (!$gbInstance)
    {
        return;
    }

    #
    # Lock file is used to prevent process writing
    # to the summary report at the same time.
    #

    #
    # Construct the lock file
    #
    $gsRptLockFile = $gsTempDir.catctlGetDbName().".rpt";

    #
    # Open file
    #
    open ($ghRptLockFile, '>', $gsRptLockFile) or
        die "$MSGFERROPENLOCKFILE $gsRptLockFile\n $!\n";

    #
    # Obtain an exclusive lock and wait if we can't get it.
    # Only one catcatl instance can write to the summary
    # report.  We take out an exclusive lock in blocking
    # mode so we wait for the lock. This is done for the
    # PDB databases only.
    #
    flock ($ghRptLockFile, LOCK_EX);

} # end of catctlGetRptLockFile

######################################################################
# 
# catctlGetOracleEnv - Attempt to determine the Oracle environment.
#
# Description:     Look for summary report using environment variables
#                  ORACLE_BASE and ORACLE_HOME or by executing orabase.
#
#
# Parameters:
#   None
#
# Returns:
#   Oracle BASE or
#   Oracle HOME or
#   Value From orabase
#
######################################################################
sub catctlGetOracleEnv
{
    my $OracleEnv = 0;

    #
    # Get Oracle Base Environment
    #
    $OracleEnv = catctlGetOB();

    #
    # Get  Oracle Home Environment
    #
    if (!$OracleEnv)
    {
        $OracleEnv = catctlGetOH();
    }

    #
    # Get orabase output
    #
    if (!$OracleEnv)
    {
        $OracleEnv = catctlGetOrabase($gsTempDir);
    }

    #
    # Return Oracle environment maybe
    #
    return ($OracleEnv);

} # end of catctlGetOracleEnv


######################################################################
# 
# catctlSearchForReport - Look for summary report
#
# Description:     Look for summary report using environment variables
#                  ORACLE_BASE and ORACLE_HOME or by executing orabase.
#
# This is done at the startup of any upgrade.  Here's how we decide how
# to do this.
#    1) Look for it in the database if we found it then delete it
#       and return.
#    2) Otherwise Look for enviromental variables in this order.
#         ORACLE_BASE or
#         ORACLE_HOME or
#         by running the orabase executable.
#
#       If we don't find ORACLE_BASE, then we use ORACLE_HOME.
#       If we don't find ORACLE_HOME, then we run the orabase utility.
#       If we are able to get the environment then we construct
#       and delete the report name as the following:
#
#         oracle_env/cfgtoollogs/dbname/upgrade/upg_summary.log
#         oracle_env/rdbms/log/upg_summary.log
#
# Parameters:
#   pOracleEnv = ORACLE_BASE, ORACLE_HOME, value returned by orabase or null.
#
# Returns:
#   None
#
######################################################################
sub catctlSearchForReport
{
    my $pOracleEnv = $_[0];    # Oracle Environment
    my $OracleEnv = 0;
    my $REPORTNAME = "upg_summary.log";


    #
    # Found in database just delete and get out
    #
    $gsReportName = catctlGetRptName();
    if (($gsReportName) && (-e $gsReportName))
    {
        unlink($gsReportName);
        $gsReportName = "";
        return;
    }

    #
    # Initialize
    #
    $gsReportName = "";

    #
    #  If we have the Oracle Environment then construct the
    #  the summary report name.  If we find it we will delete it.
    #
    if ($pOracleEnv)
    {
        #
        # Generate Summary directory and Report Name
        #
        $gsReportName = $pOracleEnv.$SLASH."cfgtoollogs".$SLASH.
            catctlGetDbName().$SLASH."upgrade".$SLASH.
            $REPORTNAME;

        #
        # If found then delete otherwise try rdbms/log
        #
        if (-e $gsReportName)
        {
            unlink($gsReportName);
        }
        else
        {
            $gsReportName = $pOracleEnv.$SLASH."rdbms".$SLASH.
                "log".$SLASH.$REPORTNAME;
            if (-e $gsReportName)
            {
                unlink($gsReportName);
            }
        }
        $gsReportName = "";
    }

}  # End of catctlSearchForReport

######################################################################
# 
# catctlGetOH      - Determine Oracle Home
#
# Description:     Determine the Oracle Home
#
# Note:            Can't use oracle home Oracle Grid inforstucture
#                  tells user to unset ORACLE_HOME environmental
#                  variable see bug 17810688.
#
# Parameters:
#
# Returns:
#   Returns Oracle Home
#
######################################################################
sub catctlGetOH
{
    my $OracleHome = $ENV{'ORACLE_HOME'};

    if ($OracleHome)
    {
        catctlPrintMsg ("Oracle Home           = $OracleHome\n",$TRUE,$TRUE);
    }

    # 
    # Return Oracle Home
    #
    return $OracleHome;
}  # End of catctlGetOH

######################################################################
# 
# catctlGetOB      - Determine Oracle Base
#
# Description:    Determine the Oracle Base
#
# Note:            
#
# Parameters:
#
# Returns:
#   Returns Oracle Base
#
######################################################################
sub catctlGetOB
{
    my $OracleBase = $ENV{'ORACLE_BASE'};


    if ($OracleBase)
    {
        catctlPrintMsg ("Oracle Base           = $OracleBase\n",$TRUE,$TRUE);
    }

    # 
    # Return Oracle Home
    #
    return $OracleBase;
}  # End of catctlGetOB

######################################################################
# 
# catctlGetOrabase - Run orabase to get the Oracle Home/Base
#
# Description:     Determine the Oracle Home/Base
#
# Note:            
#
# Parameters:
#
# Returns:
#   Returns Value From orabase
#
######################################################################
sub catctlGetOrabase
{
    my $pTempDir  = $_[0];         # Temp Directory
    my $OracleBase = "orabase";
    my $id;                    # process id
    my $LogFile = $pTempDir."orabase.log";
    my $OracleBaseDir = 0;

    #
    # Trap any errors and continue
    #
    eval
    {
        #
        # Run orabase and store results in log file.
        # If File found then read it into a variable
        # and validate the directory.
        #
        system("orabase > $LogFile 2>&1");
        if (-e $LogFile)
        {
            open (FileIn, '<', $LogFile);
            $OracleBaseDir = <FileIn>;
            close (FileIn);
            chomp $OracleBaseDir;
            if (!catctlValidDir($OracleBaseDir, "R"))
            {
                $OracleBaseDir = 0;
            }
            unlink($LogFile);
        }


    };
    if ($@)
    {
        warn();
    }
    catctlPrintMsg ("orabase               = $OracleBaseDir\n",$TRUE,$TRUE);    

    # 
    # Return orabase directory output
    #
    return $OracleBaseDir;

}  # End of catctlGetOrabase


######################################################################
# 
# catctlGetRptName - Get Summary Report Name
#
# Description: Get Summary Report Location and name.
#
# Location is in the format of 
#    Default to $ORACLE_BASE/cfgtoollogs/<db-unique-name>/upgrade
#    if $ORACLE_BASE is not defined then use 
#    $ORACLE_HOME/cfgtoollogs/<db-unique-name>/upgrade
#
# Report Name
#    upg_summary.log
#
# Parameters:
#
# Returns:
#   Returns Summary Report Location and Name
#
######################################################################
sub catctlGetRptName
{
    my $Sql = 
        "select reportname from $SUMMARYTBL where con_id=-1;\n";

    # 
    # Return report name
    #
    return (catctlQuery($Sql));

}  # End of catctlGetRptName


######################################################################
# 
# catctlGetDateTime - Get Date and Time
#
# Description: Get Date and Time in YYMMDD HH:MN:SC format.
#
#
# Parameters:
#
#   None
#
# Returns:
#   Returns Current Data and Time in YYYY_MM_DD HH:MN:SC format.
#
######################################################################
sub catctlGetDateTime
{

    my $sec   = 0;         # Seconds of minutes 0 to 61
    my $min   = 0;         # Minutes of the hour 0 to 59
    my $hour  = 0;         # Hours of day 0 to 24
    my $day   = 0;         # Day of month from 1 to 31
    my $month = 0;         # Month of year from 0 to 11
    my $year1900  = 0;     # Year since 1900
    my $wday  = 0;         # Days since sunday
    my $yday  = 0;         # Days since January 1st
    my $isdst = 0;         # Hours of daylight savings time
    my $RetDate = "";      # Return Date

    ($sec,$min,$hour,$day,$month,$year1900,$wday,$yday,$isdst)=localtime();
    $RetDate = sprintf("%04d_%02d_%02d %02d:%02d:%02d",
                       $year1900+1900,
                       $month+1,
                       $day,
                       $hour,
                       $min,
                       $sec);

    return ($RetDate);

}  # End of catctlGetDateTime


######################################################################
# 
# catctlIsRootValid - 
#
# Description: Determine if the CDB$ROOT has be upgraded.
#
# Parameters:
#   INPUT - Boolean Upgrade Flag
#   INPUT - Boolean CDB$ROOT Flag
#   INPUT - Boolean PDB processing flag
#   INPUT - Boolean PDB Instance Flag
#
# Returns:
#   TRUE   - CDB$ROOT has been upgraded.
#   FALSE  - CDB$ROOT has not been upgraded.
#
######################################################################
sub catctlIsRootValid
{
    my $pbUpgrade  = $_[0];         # Upgrade Mode
    my $pbRootProcessing = $_[1];   # Root Processing
    my $pbPdbProcessing = $_[2];    # Pdb Processing
    my $pbInstance = $_[3];         # Pdb Instance
    my $RetCode = $TRUE;            # Assume all is well with the world

    #
    # Check the following:
    #   1) Upgrading
    #   2) This is not a pdb instance
    #   3) CDB$ROOT is not being upgraded
    #   4) We are going to upgrade PDB(s)
    #   Make sure that the CDB$ROOT has
    #   been upgraded before proceeding.
    #   If we are upgrading the CDB$ROOT or
    #   we are currently upgrading a PDB
    #   then just return TRUE.
    #
    if (($pbUpgrade)          && 
        (!$pbInstance)        && 
        (!$pbRootProcessing)  &&
        ($pbPdbProcessing))
    {
        $RetCode = catctlIsDBUpgraded();
    }

    #
    # Return
    #
    return ($RetCode);

}  # End of catctlIsRootValid

######################################################################
# 
# catctlIsDBUpgraded - 
#
# Description: Determine if the CDB$ROOT has be upgraded using the following
#              criteria:
#
#              Protect against upgrading a PDB before the CDB$ROOT has been
#              upgraded successfully.
#
#              1) Compare the version of CATPROC in registry$ table
#                 with the version from v$instance table.
#                   SELECT version FROM registry$ WHERE cid = 'CATPROC' 
#                   AND version = (select version from v$instance)
#
#                   Fail Check if version does not match.
#
#              2) Are there any errors in the registry$error table.
#                   SELECT count(distinct(substr(to_char(message),1,9)))
#                   FROM registry$error
#                   WHERE substr(to_char(message),1,9) != 'ORA-00001')=0 
#
#                   Fail Check if upgrade errors have been logged
#
#              3) Have we completed the upgrade
#                   SELECT count(*) FROM registry$upg_summary 
#                   WHERE con_id = -1 and starttime = endtime)=0
#
#                   At the beginning of the the upgrade we set
#                   starttime and endtime equal.  At the end of
#                   the upgrade we update the endtime.  If the
#                   upgrade dies in the middle then this check
#                   will fail.
#
#                CDB$ROOT has to satisfy all three conditions
#                to let a PDB upgrade proceed.
#
# Parameters:
#
# Returns:
#   TRUE   - CDB$ROOT has been upgraded successfully.
#   FALSE  - CDB$ROOT has not been upgraded successfully.
#
######################################################################
sub catctlIsDBUpgraded
{
    my $RPTSTARTTIME = 
        "SELECT count(*) FROM $SUMMARYTBL ".
        "WHERE con_id = -1 AND starttime = endtime";
    my $Sql = 
        "SELECT version FROM $REGISTRYTBL WHERE cid = 'CATPROC' AND ".
        "version = (SELECT version FROM $INSTANCETBL) AND (".
        $SELERR1.$SELERR3.$SELERR4.") = 0 AND ($RPTSTARTTIME) = 0\n";
    my $RegistryVersion = "";
    my $RetCode = $FALSE;

    #
    # Send the query and check for a return version.
    # If version is not returned then database has
    # not been upgraded.
    #
    $RegistryVersion = catctlQuery($Sql);
    if ($RegistryVersion)
    {
        $RetCode = $TRUE;   
    }

    #
    # Return
    #
    return ($RetCode);

}  # End of catctlIsDBUpgraded



######################################################################
# 
# catctlCleanUp    - Cleanup 
#
# Description:     Cleanup at the end of the upgrade
#
#                  Cleanup generated files.  Post upgrade and
#                  pfile.
#
# Parameters:
#
# Returns:
#   None
#
######################################################################
sub catctlCleanUp
{
    my $x = 0;

    #
    # Close Lock files.  This will
    # release any locks held on the
    # file.  If catctl.pl crashes perl
    # will automatically release the lock.
    #
    if ($ghUpgLockFile)
    {
        close($ghUpgLockFile);
        $ghUpgLockFile = 0;
    }
    if ($ghRptLockFile)
    {
        close ($ghRptLockFile);
        $ghRptLockFile = 0;
    }

    #
    # Delete the pfile(s)
    #
    for ($x = 0; $x < @files_to_delete; $x++)
    {
        $gspFileName = $files_to_delete[$x];
        if (-e $gspFileName)
        {
            unlink($gspFileName);
            $gspFileName  = 0;
            $files_to_delete[$x] = 0;
            $gbFoundPfile = $TRUE;
        }
    }

} # end of catctlCleanUp


######################################################################
#
# catctlDatapatch - Call datapatch to install SQL patches
#
# Description:      Calls datapatch in either normal or upgrade mode
#                   to apply or rollback any necessary SQL patches or
#                   bundles.
#
# Parameters:
#   - mode (IN) "normal" or "upgrade"
#
# Returns:
#   None
#
######################################################################
sub catctlDatapatch
{
  my $mode = $_[0];  # mode in which to call datapatch

  # We need to find the location of the sqlpatch perl script sqlpatch.pl.
  # In a shiphome we can do this based on the location of catctl.pl
  # itself, which is ?/rdbms/admin.  But customers may copy this script
  # somewhere else (which we also do in our testing), so if we can't find
  # it based on ?/rdbms/admin then look in the same directory as catctl.pl.
  my $catctl_dir = dirname(File::Spec->rel2abs(__FILE__));

  # First look in ../../sqlpatch
  my $sqlpatch_dir = File::Spec->catdir($catctl_dir,
                                        File::Spec->updir(),
                                        File::Spec->updir(),
                                        "sqlpatch");

  my $sqlpatch_pl = File::Spec->catfile($sqlpatch_dir, "sqlpatch.pl");
  my $sqlpatch_cmd = "";

  if (-e $sqlpatch_pl) {
    # 18986292: Ensure that $ORACLE_HOME/lib is in LD_LIBRARY_PATH
    # for non Windows systems
    if ($^O ne "MSWin32") {
      my $oh_dir = 
        Cwd::realpath(File::Spec->catdir($sqlpatch_dir, File::Spec->updir()));

      my $lib_dir = File::Spec->catfile($oh_dir, "lib");
    
      $sqlpatch_cmd =
        "LD_LIBRARY_PATH=$lib_dir; export LD_LIBRARY_PATH; ";

      # 19178851: Other flavors of unix use different variables, so set
      # those too.  They will do no harm if we are not on those platforms.
      
      # AIX
      $sqlpatch_cmd .=
        "LIBPATH=$lib_dir; export LIBPATH; ";

      # Solaris
      $sqlpatch_cmd .=
        "LD_LIBRARY_PATH_64=$lib_dir; export LD_LIBRARY_PATH_64; ";

      # Darwin
      $sqlpatch_cmd .=
        "DYLD_LIBRARY_PATH=$lib_dir; export DYLD_LIBRARY_PATH; ";
    }

    $sqlpatch_cmd .= "$^X -I $catctl_dir -I $sqlpatch_dir $sqlpatch_pl";

  }
  else {
    # Now check in the same directory
    $sqlpatch_pl = File::Spec->catfile($catctl_dir, "sqlpatch.pl");
    if (-e $sqlpatch_pl) {
      $sqlpatch_cmd = "$^X -I $catctl_dir $sqlpatch_pl";
    }
    else {
      catctlPrintMsg(
        "Could not find sqlpatch.pl in $sqlpatch_dir or\n", $TRUE, $TRUE);
      catctlPrintMsg(
        "$catctl_dir, not installing any SQL patches\n", $TRUE, $TRUE);
      return;
    }
  }

  $sqlpatch_cmd .= " -verbose";

  if ($mode eq "upgrade")
  {
    $sqlpatch_cmd .= " -upgrade_mode_only";
  }

  if ($gbCdbDatabase)
  {
    # Set -pdbs parameter.
    if ($gbSavRootProcessing)
    {
      # 19409212: Quote pdb name to escape dollar signs.
      $sqlpatch_cmd .= " -pdbs '" . $CDBROOT . "'";
    }
    else
    {
      # 19189317: Enclose the pdbs in single quotes to escape any dollar signs
      # in the PDB names.  On Unix the quotes will be absorbed by the shell,
      # on windows they will end up being passed through to sqlpatch, which
      # can handle them.
      $sqlpatch_cmd .= " -pdbs '" . join(',', @AryPDBInstanceList) . "'"
    }
  }

  if (($gbDebugCatcon > 0) || ($giDebugCatctl > 0)) {
    $sqlpatch_cmd .= " -debug";
  }

  if ($mode eq "upgrade")
  {
    $sqlpatch_cmd .= " > $gsDatapatchLogUpgrade 2> $gsDatapatchErrUpgrade";
  }
  else
  {
    $sqlpatch_cmd .= " > $gsDatapatchLogNormal 2> $gsDatapatchErrNormal";
  }

  catctlPrintMsg("Calling sqlpatch with $sqlpatch_cmd\n", $TRUE, $TRUE);
  # First save and then remove the SIGCHLD handler installed by catcon
  my $saved_handler = $SIG{CHLD};
  $SIG{CHLD} = 'DEFAULT';

  system($sqlpatch_cmd);

  # Now restore the original handler
  $SIG{CHLD} = $saved_handler;

  catctlPrintMsg("returned from sqlpatch\n", $TRUE, $TRUE);
  return;

} # end of catctlDatapatch
