Rem
Rem $Header: oraolap/admin/xoqclnup.sql /st_rdbms_12.1.0.2.0dbpsu/1 2015/05/26 00:35:03 ddedonat Exp $
Rem
Rem xoqclnup.sql
Rem
Rem Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      xoqclnup.sql - Bug 20424899 - script to remove old OLAP Objects that
Rem                     may have been left behind in the database that may cause
Rem                     Privilege Escalation problems
Rem
Rem    DESCRIPTION
Rem      Revoke Public Privileges and remove old OLAP Objects from database.
Rem
Rem    NOTES
Rem      NONE
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: oraolap/admin/xoqclnup.sql 
Rem    SQL_SHIPPED_FILE: oraolap/admin/xoqclnup.sql 
Rem    SQL_PHASE: INSTALL
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: oraolap/admin/xoqu112.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    ddedonat    05/25/15 - 12.1.0.2.4dbpsu
Rem    ddedonat    03/06/15 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

Rem old releases granted unnecessary privileges
begin
  execute immediate('revoke all on olapsys.olap_session_dims from public');
  execute immediate('revoke all on olapsys.olap_session_cubes from public');
exception
  when others then
    null;
end;
/

begin
  execute immediate('revoke all on olapsys.cwm2$awcubecreateaccess from public');
  execute immediate('revoke all on olapsys.cwm2$awdimcreateaccess from public');
exception
  when others then
    null;
end;
/

begin
  execute immediate('revoke all on sys.olaptablevels from public');
  execute immediate('revoke all on sys.olaptableveltuples from public');
exception
  when others then
    null;
end;
/


Rem old OLAP objects no longer needed
DROP PUBLIC SYNONYM GV_Olapi_Session_History FORCE;
DROP PUBLIC SYNONYM V_Olapi_Session_History FORCE;
DROP PUBLIC SYNONYM GV_Olapi_Iface_Object_History FORCE;
DROP PUBLIC SYNONYM V_Olapi_Iface_Object_History FORCE;
DROP PUBLIC SYNONYM GV_Olapi_Iface_Op_History FORCE;
DROP PUBLIC SYNONYM V_Olapi_Iface_Op_History FORCE;
DROP PUBLIC SYNONYM GV_Olapi_Memory_Op_History FORCE;
DROP PUBLIC SYNONYM V_Olapi_Memory_Op_History FORCE;
DROP PUBLIC SYNONYM Olapi_History_Seq FORCE;
DROP PUBLIC SYNONYM Olapi_History FORCE;
DROP PUBLIC SYNONYM Olapi_Session_History FORCE;
DROP PUBLIC SYNONYM Olapi_Iface_Object_History FORCE;
DROP PUBLIC SYNONYM Olapi_Iface_Op_History FORCE;
DROP PUBLIC SYNONYM Olapi_Memory_Op_History FORCE;
DROP PUBLIC SYNONYM Olapi_Memory_Heap_History FORCE;

DROP VIEW GV_Olapi_Session_History;
DROP VIEW V_Olapi_Session_History;
DROP VIEW GV_Olapi_Iface_Object_History;
DROP VIEW V_Olapi_Iface_Object_History;
DROP VIEW GV_Olapi_Iface_Op_History;
DROP VIEW V_Olapi_Iface_Op_History;
DROP VIEW GV_Olapi_Memory_Op_History;
DROP VIEW V_Olapi_Memory_Op_History;
DROP SEQUENCE Olapi_History_Seq;
DROP TABLE Olapi_History CASCADE CONSTRAINTS;
DROP TABLE Olapi_Session_History CASCADE CONSTRAINTS;
DROP TABLE Olapi_Iface_Object_History CASCADE CONSTRAINTS;
DROP TABLE Olapi_Iface_Op_History CASCADE CONSTRAINTS;
DROP TABLE Olapi_Memory_Op_History CASCADE CONSTRAINTS;
DROP TABLE Olapi_Memory_Heap_History CASCADE CONSTRAINTS;

@?/rdbms/admin/sqlsessend.sql
