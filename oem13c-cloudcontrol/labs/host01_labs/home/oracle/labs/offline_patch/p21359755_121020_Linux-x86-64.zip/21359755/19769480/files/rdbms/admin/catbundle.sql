Rem
Rem $Header: rdbms/admin/catbundle.sql /st_rdbms_12.1.0.2.0dbpsu/2 2014/12/07 21:49:28 surman Exp $
Rem
Rem catbundle.sql
Rem
Rem Copyright (c) 2008, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catbundle.sql - Patch bundle installation script
Rem
Rem    DESCRIPTION
Rem      This script is now deprecated.  Use datapatch to install any
Rem      necessary SQL patches and bundles into the database.
Rem
Rem      For more details refer to MOS Note 1609718.1.
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      12/06/14 - Backport surman_bug-20074391 from
Rem                           st_rdbms_11.2.0.4.0dbpsu
Rem    surman      10/04/14 - Backport surman_ojvm_fixes_12.1.0.2dbpsu from
Rem                           st_rdbms_12.1.0.2.0dbpsu
Rem    surman      10/03/14 - 19727057: Always call jvmpsu.sql if it exists
Rem    surman      06/05/14 - Backport surman_bug-17277459 from main
Rem    surman      05/26/14 - 17277459: Deprecate catbundle.sql
Rem    surman      08/29/13 - 17360958: Add con_name to logfile name
Rem    surman      08/22/13 - 17343514: Remove java
Rem    talliu      06/28/13 - Add CDB view for DBA view
Rem    surman      06/21/13 - 13866822: Call apply after rollback
Rem    surman      10/19/11 - 13114257: More checks for Java
Rem    surman      07/18/11 - 12766056: Always create CatbundleCreateDir
Rem    surman      05/31/11 - 11937509: Create log directory in java
Rem    surman      05/17/11 - 10413872: Filename priority
Rem    surman      05/16/11 - 10413872: Bundledata version
Rem    surman      07/27/10 - 9938689: Create log directory using ORACLE_BASE
Rem    surman      05/08/09 - 8498426: Set namespace
Rem    surman      03/30/09 - 8358067: Specify nls_language
Rem    surman      03/04/09 - 7710405: Correct INSTR platform checks
Rem    rvadraha    09/03/13 - 7658224: Check mount points using _kolfuseslf
Rem    surman      09/10/08 - 7391049: Invalid dba_registry_history synonym
Rem    surman      06/13/08 - Use proper action in registry update
Rem    surman      06/10/08 - Change logging behavior
Rem    surman      06/09/08 - Still more comments
Rem    surman      06/06/08 - Determine directory names in catbundle
Rem    surman      06/05/08 - Generate rollback script at apply time
Rem    surman      06/05/08 - Remove bundle_script and spool commands
Rem    surman      05/28/08 - More comments
Rem    surman      05/21/08 - Generic bundle names
Rem    surman      05/20/08 - Change to catbundle from catbp
Rem    surman      05/20/08 - Support rollback
Rem    surman      05/19/08 - catcpu.sql replacement project
Rem    surman      05/19/08 - Created
Rem

SET SERVEROUTPUT ON size unlimited

PROMPT This script is now deprecated.  Use datapatch to install any
PROMPT necessary SQL patches and bundles into the database.
PROMPT
PROMPT For more details refer to MOS Note 1609718.1.

REM 19727057: Except for this hackish fix to always run the OJVM fixes 
REM when this script is called by DBCA.  Sigh.

-- Returns TRUE if the specified file exists.
-- If there are any errors encountered while opening the directory and file
-- (using utl_file) then false is returned.
-- Note that only one session should call this at a time because the directory
-- is not session specific.
-- Added for bug 19727057.
CREATE OR REPLACE FUNCTION file_exists(dirname IN VARCHAR2, filename IN VARCHAR2)
   RETURN BOOLEAN IS
PRAGMA AUTONOMOUS_TRANSACTION;  -- executes DDL 

  fp UTL_FILE.FILE_TYPE;

BEGIN
  -- Try to create directory object
  BEGIN
    EXECUTE IMMEDIATE 
      'CREATE OR REPLACE DIRECTORY catbundle_testdir AS ' ||
       dbms_assert.enquote_literal(dirname);
  EXCEPTION
    WHEN OTHERS THEN
      -- We want to just quit here since the directory object can't be created
      RETURN FALSE;
  END;

  -- Attempt to open the file and  close it.
  fp := UTL_FILE.FOPEN('CATBUNDLE_TESTDIR', filename, 'r');
  UTL_FILE.FCLOSE(fp);

  EXECUTE IMMEDIATE 'DROP DIRECTORY catbundle_testdir';

  -- If we get here we're good
  RETURN TRUE;
EXCEPTION
  WHEN OTHERS THEN
    -- Try to drop the directory first
    BEGIN
      EXECUTE IMMEDIATE 'DROP DIRECTORY catbundle_testdir';
    EXCEPTION
      WHEN OTHERS THEN null;
    END;

    -- And return FALSE.  We don't care what the error was.
    RETURN FALSE;
END file_exists;
/

VARIABLE scriptFile VARCHAR2(500);

DECLARE
  platform v$database.platform_name%TYPE;
  homeDir  VARCHAR2(500);
  javavmInstallDir VARCHAR2(500);
BEGIN
  -- Determine ORACLE_HOME value and admin dir
  SELECT NLS_UPPER(platform_name)
    INTO platform
    FROM v$database;

  -- 9938689: Default to $ORACLE_BASE/cfgtoollogs/catbundle; if $ORACLE_BASE
  -- is not defined then use $ORACLE_HOME/cfgtoollogs/catbundle; if 
  -- $ORACLE_HOME is not defined then error
  DBMS_SYSTEM.GET_ENV('ORACLE_HOME', homeDir);

  IF homeDir IS NULL THEN
    RAISE_APPLICATION_ERROR(-20000, 'ORACLE_HOME is not defined');
  END IF;

  IF INSTR(platform, 'WINDOWS') != 0 THEN
    -- Windows, use '\'
    javavmInstallDir := homeDir || '\javavm\install\';
  ELSIF INSTR(platform, 'VMS') != 0 THEN
    -- VMS, use [] and .
    javavmInstallDir := REPLACE(homeDir || '[javavm.install]', '][', '.');
  ELSE 
    -- Unix and z/OS, '/'
    javavmInstallDir := homeDir || '/javavm/install/';
  END IF;

  IF file_exists(javavmInstallDir, 'jvmpsu.sql') THEN
    :scriptFile := '?/javavm/install/jvmpsu.sql';
  ELSE
    :scriptFile := '?/rdbms/admin/nothing.sql';
  END IF;
    
END;
/

COLUMN scriptFile new_value sf
SELECT :scriptFile AS scriptFile FROM dual;

@&sf

DROP FUNCTION file_exists;
