Rem
Rem $Header: rdbms/admin/bug19532017_downgrade.sql /st_rdbms_12.1.0.2.0dbpsu/2 2015/02/03 20:59:50 sschodav Exp $
Rem
Rem bug19532017_downgrade.sql
Rem
Rem Copyright (c) 2014, 2015, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      bug19532017_downgrade.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/bug19532017_downgrade.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/bug19532017_downgrade.sql 
Rem    SQL_PHASE: CATLMNR
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: ORA-01418  
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    sschodav    02/03/15 - Backport
Rem                           sschodav_ci_backport_20425790_12.1.0.2.5dbbp from
Rem                           st_rdbms_12.1.0.2.0dbbp
Rem    sschodav    01/29/15 - Backport sschodav_bug-20425790 from
Rem                           st_rdbms_12.1.0.2.0dbbp
Rem    sschodav    01/29/15 - create index can cause ORA-00439 while creating
Rem                           index
Rem    abrown      09/23/14 - Drop index added by bug19532017_upgrade.sql
Rem    abrown      09/23/14 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

@@?/rdbms/admin/sqlsessstart.sql
DROP INDEX SYSTEM.LOGMNR_I3CDEF$
/
@?/rdbms/admin/sqlsessend.sql
