Rem
Rem $Header: rdbms/admin/bug19587324.sql /st_rdbms_12.1.0.2.0dbpsu/1 2015/08/19 11:17:01 dvoss Exp $
Rem
Rem bug19587324.sql
Rem
Rem Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      bug19587324.sql - Additional install/rollback action for bug 19587324
Rem
Rem    DESCRIPTION
Rem      This script recompiles a package body which is invalidated during
Rem      the installation or rollback of bug fix 19587324.  
Rem
Rem      When installing or rolling back prvtlmd.plb in the context of this
Rem      fix, this SQL script should be run AFTER prvtlmd.plb is loaded to
Rem      recompile DBMS_LOGMNR_SESSION which may become invalid in certain
Rem      configurations.
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/bug19587324.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/bug19587324.sql 
Rem    SQL_PHASE: PATCH
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    dvoss       08/11/15 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

@@?/rdbms/admin/sqlsessstart.sql
alter package dbms_logmnr_session compile body;
@?/rdbms/admin/sqlsessend.sql
