Rem
Rem $Header: oraolap/admin/xoqu112.sql /st_rdbms_12.1.0.2.0dbpsu/1 2015/05/26 00:35:03 ddedonat Exp $
Rem
Rem xoqu112.sql
Rem
Rem Copyright (c) 2010, 2015, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      xoqu112.sql - migration script for upgrading olap api component
Rem
Rem    DESCRIPTION
Rem      Upgrade OLAP API from 11.2
Rem
Rem    NOTES
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      05/19/15 - Backport ddedonat_bug-20424899 from main
Rem    glyon       06/26/12 - LRG 7075668 - drop alter_session stuff
Rem    glyon       06/11/10 - added missing / after anonymous block
Rem    glyon       04/29/10 - Created
Rem

-- delete OlapPrivileges Security Class (never documented or used)
begin
  dbms_xdb.deleteresource('/OLAP_XDS', dbms_xdb.delete_recursive_force);
exception
  when others then
    null;
end;
/

-- Drop the alter_session table, view, synonym, and package.
-- These were eliminated for 10.2.0.4, but never dropped in an upgrade.
-- The drops are done here because even recent versions could still have
-- these objects, if the instance was created through upgrades.

drop public synonym all_olap_alter_session;
drop view v$olap_alter_session;
drop package olap_api_session_init;
drop table olap$alter_session;

-- Call xoqclnup.sql to remove old OLAP Objects that may cause privilege escalation
@@xoqclnup

