# Copyright (c) 2004, 2015, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      asmcmdsys - ASM CoMmanD line interface (Sample Module)
#
#    DESCRIPTION
#      This module is a dummy/sample module that provides a working 
#      template for module additions.
#
#    NOTES
#      usage: asmcmdcore [-p] [command]
#
#    MODIFIED  (MM/DD/YY)
#    apfwkr     01/05/15 - Backport apfwkr_blr_backport_19035573_12.1.0.2.0
#                          from st_rdbms_12.1
#    apfwkr     09/19/14 - Backport siyarlag_bug-19035573 from main
#    samjo      06/05/14 - Backport samjo_bug-18301913 from main
#    siyarlag   06/06/14 - Bug/18865657: add afd_scan
#    siyarlag   06/06/14 - Backport siyarlag_bug-18865657 from main
#    siyarlag   05/29/14 - Backport siyarlag_bug-18812974 from main
#    apfwkr     05/18/14 - Backport siyarlag_bug-18430406 from main
#    siyarlag   06/24/14 - Bug/19035573: use afdtool always to update afd conf
#    hppancha   03/26/14 - bug11634278: Add mkcc and rmcc
#    pvenkatr   01/22/14 - Bug # 18136383 Added afd commands
#    siyarlag   05/21/14 - Bug/18812974: add afd_filter afd_lsdsk
#    siyarlag   04/16/14 - Bug/18430406: add afd_configure afd_deconfigure
#                          afd_state
#    pvenkatr   01/22/14 - Bug # 18136383 Added AFD commands
#                                afd_dsget/afd_dsset/afd_label/afd_unlabel
#    pvenkatr   01/15/14 - Bug # 17998892 - Added check for SYSASM for
#                          spbackup, spcopy, spget, spmove, spset.
#    pvenkatr   11/21/13 - #17526682 - Added a check for client cluster before
#                          calling gpnptsetspfile.
#    pvenkatr   09/25/13 - 17398626 - using 'uname -n' & %COMPUTERNAME% instead
#                          of $HOSTNAME env var.
#    pvenkatr   09/03/13 - # 17365414 - invoking SQLPLUS with appropriate
#                          privileges.
#    pvenkatr   08/27/13 - Rearranged reconnect logic in dsset for FlexASM
#                          scenarios.
#    manuegar   05/08/13 - Bug13951456 Support bind parameters
#    pvenkatr   02/01/13 - Using asmcmdshare_filter_invisible_cmds
#    pvenkatr   08/24/11 - Removed flags hash table - using from XML
#    adileepk   06/20/11 - Connection Pooling.
#    soye       05/13/11 - lrg5557538: spbackup accepts DB spfile type
#    dfriedma   05/12/11 - v$asm_operation updates
#    adileepk   11/08/10 - Adding changes to integrate parser module with
#                          asmcmd.
#    moreddy    09/21/10 - 9846823 spcopy -u update gpnp when dstn is os file
#    shmubeen   08/16/10 - fix for bug 7189804. lsop enhancement
#    shmubeen   05/31/10 - change Dsk_Num header of lsop to Operation
#    moreddy    05/06/10 - bug 8667038 NLS for error messages
#    amitroy    04/21/10 - BUG 8933243 - USE DIFFERENT CHARACTER IN ASMCMD TO
#                          "HIDE COLUMN DETAILS" INSTEAD OF -H
#    pvenkatr   03/31/10 - Syntax, description, example - all from XML
#    moreddy    03/22/10 - Adding more tracing
#    moreddy    01/19/10 - Adding tracing messages
#    sanselva   12/16/09 - lrg 4067759 fix crsctl/srvctl:for NT
#    sanselva   11/02/09 - NT paths interpreted wrongly for spcopy spmove
#    pvenkatr   09/03/09 - Help message from xml file.
#    amitroy    09/24/09 - adding 'mount' option for STARTUP; bug#8676198
#    amitroy    09/22/09 - modifying the hashkey for 'normal'
#    amitroy    09/15/09 - #8676198 add NORMAL option for SHUTDOWN
#    canuprem   07/29/09 - update dsset and dsget to work in SIHA mode
#    sanselva   07/27/09 - #8683273 asm_diskstring glob string issue
#    lajain     07/23/09 - Display empty string in dsget.
#    sanselva   06/24/09 - correct syntax for command startup
#    canuprem   06/18/09 - options for dsset should be mutually exclusive.
#    gayavenk   06/11/09 - Fix pathname issue in dsset
#    shagarw    06/11/09 - add param to setds to ignore the input ds.
#    canuprem   05/29/09 - modify dsset and dsget
#    sanselva   05/14/09 - spbackup,spmove,spcopy issue when target directory
#    heyuen     04/17/09 - add dsset dsget help
#    heyuen     04/20/09 - add spbackup
#    sanselva   04/12/09 - ASMCMD long options and consistency
#    heyuen     04/06/09 - update spmove to use asmcmdsys_dualget
#    heyuen     03/23/09 - remove iostat
#    heyuen     01/30/09 - update offline commands
#    heyuen     02/09/09 - fix asmcmd_spset
#    heyuen     12/03/08 - add spmove, spset, spget
#    heyuen     10/24/08 - change zones to regions
#    heyuen     10/14/08 - use dynamic modules
#    heyuen     09/19/08 - fix ctrl-c in iostat
#    heyuen     09/17/08 - complete path for spcopy
#    heyuen     08/02/08 - fix startup/shutdown msgs
#    heyuen     07/28/08 - use command properties array
#    heyuen     07/17/08 - fix messages, rewrite iostat
#    heyuen     05/14/08 - add spcopy
#    heyuen     05/19/08 - startup restricted
#    heyuen     05/12/08 - enable iostat continuously
#    heyuen     04/15/08 - bug 6935431, reorder help
#    heyuen     03/26/08 - bug 6753856: fix shutdown hang
#    heyuen     03/17/08 - enable -g for iostat
#    heyuen     02/21/08 - disable iostat for non mounted disks
#    heyuen     09/20/07 - creation
#
############################################################################
#
############################ Functions List #################################
#
#############################################################################

package asmcmdsys;
require Exporter;
our @ISA    = qw(Exporter);
our @EXPORT = qw(asmcmdsys_init
                 %asmcmdsys_cmds
                 );

use strict;
use Getopt::Long qw(:config no_ignore_case bundling);
use asmcmdglobal;
use asmcmdshare;
use asmcmdparser;
use asmcmdbase;

use List::Util qw[min max];
use File::Find;
use File::Spec;
use File::Spec::Functions;
use File::Copy;
use Sys::Hostname;

####################### ASMCMDSYS Global Constants ######################
our ($ASMCMDSYS_SQLPLUS) = "$ENV{'ORACLE_HOME'}/bin/sqlplus -S / as sysasm";

# SQLPLUS command with appropriage roles.
our ($ASMCMDSYS_SQLPLUS_SYSASM)  =
                 "$ENV{'ORACLE_HOME'}/bin/sqlplus -S / as sysasm";
our ($ASMCMDSYS_SQLPLUS_SYSDBA)  = 
                 "$ENV{'ORACLE_HOME'}/bin/sqlplus -S / as sysdba";
our ($ASMCMDSYS_SQLPLUS_SYSOPER) = 
                 "$ENV{'ORACLE_HOME'}/bin/sqlplus -S / as sysoper" ;


####################### ASMCMDSYS Global Variables ######################
our (%asmcmdsys_lsop_header) = ('name'       ,'Group_Name',
                                'pass'       ,'Pass     ',
                                'state'      ,'State',
                                'power'      ,'Power',
                                'est_work'   ,'EST_WORK',
                                'est_rate'   ,'EST_RATE',
                                'est_minutes'   ,'EST_TIME',
                                );

our (%asmcmdsys_cmds) = (lsop            => {},
                         shutdown        => {},
                         spcopy          => {},
                         spmove          => {},
                         startup         => {},
                         spset           => {},
                         spget           => {},
                         dsset           => {},
                         dsget           => {},
                         spbackup        => {},
                         afd_configure   => {},
                         afd_deconfigure => {},
                         afd_dsset       => {},
                         afd_dsget       => {},
                         afd_filter      => {},
                         afd_label       => {},
                         afd_lsdsk       => {},
                         afd_scan        => {},
                         afd_unlabel     => {},
                         afd_state       => {},
                         mkcc            => {},
                         rmcc            => {}
                         );

# PLSQL constants
my ($PLSQL_NUMBER)      = 22;

# init script constants
my  $INITD;
my  $RCSDIR;
my  $RCKDIR;
my  $RCALLDIR;
my  $RC_START;
my  $RC_KILL;
my  $RC_KILL_OLD;
my  $IT;
my  $INIT;

if ($^O =~ /linux/i)
{
  $INITD = "/etc/init.d";
  $RCSDIR = "/etc/rc.d/rc3.d /etc/rc.d/rc5.d";
  $RCKDIR = "/etc/rc.d/rc0.d /etc/rc.d/rc1.d /etc/rc.d/rc2.d /etc/rc.d/rc4.d /etc/rc.d/rc6.d";
  $RCALLDIR = "/etc/rc.d/rc0.d /etc/rc.d/rc1.d /etc/rc.d/rc2.d /etc/rc.d/rc3.d /etc/rc.d/rc4.d /etc/rc.d/rc5.d /etc/rc.d/rc6.d";
  $RC_START = "S96";
  $RC_KILL = "K19";
  $RC_KILL_OLD = "K96";
  $IT = "/etc/inittab";
  $INIT = "/usr/sbin/init";
}
elsif ($^O =~ /solaris/i)
{
  $INITD = "/etc/init.d";
  $RCSDIR = "/etc/rc3.d";
  $RCKDIR = "/etc/rc0.d /etc/rc1.d /etc/rc2.d /etc/rcS.d";
  $RCALLDIR = "/etc/rc.d/rc0.d /etc/rc.d/rc1.d /etc/rc.d/rc2.d /etc/rc.d/rc3.d /etc/rc.d/rcS.d";
  $RC_START = "S96";
  $RC_KILL = "K19";
  $RC_KILL_OLD = "K96";
  $IT = "/etc/inittab";
  $INIT = "/sbin/init";
}
elsif ($^O =~ /aix/i)
{
  $INITD = "/etc";
  $RCSDIR = "/etc/rc.d/rc2.d";
  $RCKDIR = "/etc/rc.d/rc2.d";
  $RCALLDIR = "/etc/rc.d/rc2.d";
  $RC_START = "S96";
  $RC_KILL = "K19";
  $RC_KILL_OLD = "K96";
  $IT = "/etc/inittab";
  $INIT = "/usr/sbin/init";
}

sub is_asmcmd
{
  return 1;
}

########
# NAME
#   asmcmdsys_init
#
# DESCRIPTION
#   This function initializes the asmcmdsys module.  For now it simply 
#   registers its callbacks with the asmcmdglobal module.
#
# PARAMETERS
#   None
#
# RETURNS
#   Null
#
# NOTES
#   Only asmcmdcore_main() calls this routine.
########
sub init
{
  # All of the arrays defined in the asmcmdglobal module must be 
  # initialized here.  Otherwise, an internal error will result.
  push (@asmcmdglobal_command_callbacks, \&asmcmdsys_process_cmd);
  push (@asmcmdglobal_help_callbacks, \&asmcmdsys_process_help);
  push (@asmcmdglobal_command_list_callbacks, \&asmcmdsys_get_asmcmd_cmds);
  push (@asmcmdglobal_is_command_callbacks, \&asmcmdsys_is_cmd);
  push (@asmcmdglobal_is_wildcard_callbacks, \&asmcmdsys_is_wildcard_cmd);
  push (@asmcmdglobal_syntax_error_callbacks, \&asmcmdsys_syntax_error);
  push (@asmcmdglobal_no_instance_callbacks, \&asmcmdsys_is_no_instance_cmd);
  %asmcmdglobal_cmds = (%asmcmdglobal_cmds, %asmcmdsys_cmds);

  #Perform ASMCMD consistency check if enabled
  if($asmcmdglobal_hash{'consistchk'} eq 'y')
  {
     if(!asmcmdshare_check_option_consistency(%asmcmdsys_cmds))
     {
       exit 1;
     }
  }
}


########
# NAME
#   asmcmdsys_process_cmd
#
# DESCRIPTION
#   This routine calls the appropriate routine to process the command 
#   specified by $asmcmdglobal_hash{'cmd'}.
#
# PARAMETERS
#   dbh       (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   1 if command is found in the asmcmdsys module; 0 if not.
#
# NOTES
#   Only asmcmdcore_shell() calls this routine.
########
sub asmcmdsys_process_cmd 
{
  my ($dbh) = @_;
  my ($succ) = 0;

  # Get current command from global value, which is set by 
  # asmcmdsys_parse_asmcmd_args()and by asmcmdcore_shell().
  my ($cmd) = $asmcmdglobal_hash{'cmd'};

  # Declare and initialize hash of function pointers, each designating a 
  # routine that processes an ASMCMDSYS command.
  my (%cmdhash) = ( startup          => \&asmcmdsys_process_startup ,
                    shutdown         => \&asmcmdsys_process_shutdown ,
                    lsop             => \&asmcmdsys_process_lsop,
                    spcopy           => \&asmcmdsys_process_spcopy,
                    spmove           => \&asmcmdsys_process_spmove,
                    spset            => \&asmcmdsys_process_spset,
                    spget            => \&asmcmdsys_process_spget,
                    dsset            => \&asmcmdsys_process_dsset,
                    dsget            => \&asmcmdsys_process_dsget,
                    spbackup         => \&asmcmdsys_process_spbackup,
                    afd_configure    => \&asmcmdsys_process_afdconfigure,
                    afd_deconfigure  => \&asmcmdsys_process_afddeconfigure,
                    afd_dsset        => \&asmcmdsys_process_afddsset,
                    afd_dsget        => \&asmcmdsys_process_afddsget,
                    afd_filter       => \&asmcmdsys_process_afdfilter,
                    afd_label        => \&asmcmdsys_process_afdsetlabel,
                    afd_lsdsk        => \&asmcmdsys_process_afdlsdsk,
                    afd_scan         => \&asmcmdsys_process_afdscan,
                    afd_unlabel      => \&asmcmdsys_process_afdclrlabel,
                    afd_state        => \&asmcmdsys_process_afdstate,
                    mkcc             => \&asmcmdsys_process_mkcc,
                    rmcc             => \&asmcmdsys_process_rmcc);

  if (defined ( $cmdhash{ $cmd } ))
  {
    # If user specifies a known command, then call routine to process it. #
    $cmdhash{ $cmd }->($dbh);
    $succ = 1;
  }
  
  return $succ;
}


########
# NAME
#   asmcmdsys_process_startup
#
# DESCRIPTION
#   This function processes the asmcmd command startup.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_startup
{
  my (%args);
  my ($ret);
  my ($qry);
  my ($pfile);
  my ($sqlplus_stmt);

  my ($tempoutputfile) = $asmcmdglobal_hash{'tempdir'} . "/startuptemp.out";
  my ($tempfilehandle);
  my (@lines) = ();

  # Get option parameters, if any.
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
  return unless defined ($ret);

  #bug 6994980
  delete $ENV{'ENV'} if (defined($ENV{'ENV'}));

  if ($asmcmdglobal_hash{'contyp'} eq "sysasm")
  {
    $sqlplus_stmt = "$ASMCMDSYS_SQLPLUS_SYSASM" ;
  }
  if ($asmcmdglobal_hash{'contyp'} eq "sysdba")
  {
    $sqlplus_stmt = "$ASMCMDSYS_SQLPLUS_SYSDBA" ;
  }  if ($asmcmdglobal_hash{'contyp'} eq "sysoper")
  {
    $sqlplus_stmt = "$ASMCMDSYS_SQLPLUS_SYSOPER" ;
  }

  $qry = "startup";

  #nomount
  if (defined($args{'nomount'}))
  {
    $qry .= " nomount ";
  }

  if (defined($args{'restrict'}))
  {
    $qry .= " restrict ";
  }

  if (defined($args{'pfile'}))
  {
    $qry .= " pfile=" . $args{'pfile'};
  }

  #mount
  if (defined($args{'mount'}))
  {
    $qry .= " mount ";
  }

  # untaint sqlplus
  $sqlplus_stmt =~ m/(.*)/;
  $sqlplus_stmt = $1;
  
  unlink $tempoutputfile if(-e $tempoutputfile);
  open SQLPLUS, "| $sqlplus_stmt > $tempoutputfile";
  print SQLPLUS $qry;
  close SQLPLUS;

  eval
  {
      open($tempfilehandle, "<$tempoutputfile") or 
                        die "Could not open the temporary file $tempoutputfile";
      my @lines = <$tempfilehandle>;
      close $tempfilehandle;
      unlink $tempoutputfile;
      foreach(@lines)
      {
         print $_;
         if($_ =~ m/[A-Z]+-[0-9]+\s*:/)
         {
            $asmcmdglobal_hash{'e'} = -1;
         }
      }
  };
  asmcmdshare_trace(3, "$qry", 'y', 'n');

  return;
}




########
# NAME
#   asmcmdsys_process_shutdown
#
# DESCRIPTION
#   This function processes the asmcmd command shutdown.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_shutdown
{
  my ($dbh) = shift;
  my (%args);                             # Argument hash used by getopts(). #
  my ($ret);                      # asmcmdsys_parse_int_args() return value. #
  my ($qry);                                          # SQL query statement. #
  my ($sqlplus_stmt);
  
  my ($tempoutputfile) = $asmcmdglobal_hash{'tempdir'} . "/shutdowntemp.out";
  my ($tempfilehandle);
  my (@lines) = ();

  # Get option parameters, if any.
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  #bug 6994980
  delete $ENV{'ENV'} if (defined($ENV{'ENV'}));


  if ($asmcmdglobal_hash{'contyp'} eq "sysasm")
  {
    $sqlplus_stmt = "$ASMCMDSYS_SQLPLUS_SYSASM" ;
  }
  if ($asmcmdglobal_hash{'contyp'} eq "sysdba")
  {
    $sqlplus_stmt = "$ASMCMDSYS_SQLPLUS_SYSDBA" ;
  }  if ($asmcmdglobal_hash{'contyp'} eq "sysoper")
  {
    $sqlplus_stmt = "$ASMCMDSYS_SQLPLUS_SYSOPER" ;
  }

  $qry = "SHUTDOWN ";

  if (defined($args{'immediate'}))
  {
    $qry .= "IMMEDIATE ";
  }

  elsif (defined($args{'abort'}))
  {
    $qry .= "ABORT ";
  }

  else
  {
    $qry .= "NORMAL ";
  }

  # untaint sqlplus
  $sqlplus_stmt =~ m/(.*)/;
  $sqlplus_stmt = $1;

  if (defined($dbh))
  {
    asmcmdbase_disconnect($dbh);
  }

  unlink $tempoutputfile if(-e $tempoutputfile);
  open SQLPLUS, "| $sqlplus_stmt > $tempoutputfile";
  print SQLPLUS $qry;
  close SQLPLUS;

  eval
  {
      open($tempfilehandle, "<$tempoutputfile") or 
                        die "Could not open the temporary file $tempoutputfile";
      my @lines = <$tempfilehandle>;
      close $tempfilehandle;
      unlink $tempoutputfile;
      foreach(@lines)
      {
         print $_;
         if($_ =~ m/[A-Z]+-[0-9]+\s*:/)
         {
            $asmcmdglobal_hash{'e'} = -1;
         }
      }
  };
  asmcmdshare_trace(3, "$qry", 'y', 'n');

  return;
}

########
# NAME
#   asmcmdsys_process_lsop
#
# DESCRIPTION
#   This function processes the asmcmd command lsop.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_lsop
{
  my ($dbh) = shift;
  my (@what , @from, $sth, @where, @order);
  my (%min_col_wid, $print_format, $print_string, @what_print);
  my ($k, $v, @op_list, $h);
  my ($row);
  my (%args);
  my (@tmp_cols);  
  my $gnum; 
  my $ret;
  my @eargs;
  my $dgname;

  # Get option parameters, if any.
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);
  
  asmcmdshare_trace(3, "ASMCMD (PID = $$) - LSOP Command\n", 'y', 'n');

  push (@what, 'v$asm_diskgroup_stat.name as name');
  push (@what, 'v$asm_operation.pass as pass');
  push (@what, 'v$asm_operation.state as state');
  push (@what, 'v$asm_operation.power as power');
  push (@what, 'v$asm_operation.est_work as est_work');
  push (@what, 'v$asm_operation.est_rate as est_rate');
  push (@what, 'v$asm_operation.est_minutes as est_minutes');
 
  push (@from, 'v$asm_operation');
  push (@from, 'v$asm_diskgroup_stat');

  push (@where, 'v$asm_operation.group_number = v$asm_diskgroup_stat.group_number');

  if( defined($args{'G'}) )
  {
    $dgname = $args{'G'};
    $gnum = asmcmdshare_get_gnum_from_gname($dbh, $dgname);
    if( $gnum )
    {
      # Use the name, rather than the number. Doing so preserves the order
      # of v$asm_operation
      push (@where, 'v$asm_diskgroup_stat.name = '."UPPER('".$dgname."')");
    }

    else
    {
      @eargs = ($dgname); 
      asmcmdshare_error_msg(8001, \@eargs);
      return;
    }
  }
  $sth = asmcmdshare_do_construct_select($dbh, \@what, \@from, \@where, 
                                         \@order);

  @tmp_cols = @{$sth->{NAME}};
  @what = ();
  foreach (@tmp_cols)
  {
    push (@what, "\L$_");
  }

  #initialize the min_col_wid array
  foreach(@what)
  {
    $min_col_wid{$_} = 0;
  }

  while (defined($row = asmcmdshare_fetch($sth)))
  {
    my(%op_info) = ();

    while(($k, $v) = each(%{$row}))
    {
      $k =~ tr/[A-Z]/[a-z]/;
      if(!defined($v))
      {
        $v="";
      } 
      $op_info{$k} = $v;

      $min_col_wid{$k} = max($min_col_wid{$k}, length($v));
    }

    push (@op_list, \%op_info);
  }

  #get header length
  foreach (@what)
  {
    $min_col_wid{$_} = max($min_col_wid{$_},
                           length($asmcmdsys_lsop_header{$_}));
  }

  $print_format = '';

  foreach (@what)
  {
    $print_format .= "%-" . $min_col_wid{$_} . "s  ";
  }
  $print_format .= "\n";

  #print header
  if (!defined ($args{'suppressheader'}) )
  {
    @what_print = ();
    foreach (@what)
    {
      push (@what_print, $asmcmdsys_lsop_header{$_});
    }
    $print_string = sprintf($print_format, @what_print);
    asmcmdshare_trace(3, "ASMCMD (PID = $$) - LSOP Command - $print_string\n", 'y', 'n');
    asmcmdshare_print($print_string);
  }
  
  #print rows
  foreach $h (@op_list)
  {
    @what_print = ();
    foreach (@what)
    {
      push (@what_print, $h->{$_});
    }
    $print_string = sprintf($print_format, @what_print);
    asmcmdshare_trace(3, "ASMCMD (PID = $$) - LSOP Command - $print_string\n", 'y', 'n');
    asmcmdshare_print($print_string);
  }
  
  asmcmdshare_trace(3, "ASMCMD (PID = $$) - LSOP Command Finished\n", 'y', 'n');
  return;
}


########
# NAME
#   asmcmdsys_process_spcopy
#
# DESCRIPTION
#   This function processes the asmcmd command spcopy.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_spcopy
{
  my ($dbh) = shift;
  my ($src_path, $dst_path, $src_name, $dst_name);
  my ($sth);
  my ($hdl, $pblk, $fname, $ftyp, $blksz, $openmode);
  my (%norm, $ret);
  my ($update_gpnp) = 0;
  my ($pl_sql_number) = 22;
  my ($spfile_number) = 253;
  my (%args);
  my ($fileType, $blkSz, $fileSz);
  my ($client_mode) = 0;
  my (@eargs);

  # Get option parameters, if any.
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
  return unless defined ($ret);

  # SPCOPY operation for ASM SPFILE requires SYSASM
  if ($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg (9485, undef);
    return;
  }

  $src_path = shift(@{$args{'spcopy'}});
  $src_path =~ /(.*)/;
  $src_path = $1;
 
  $src_name = $src_path;
  #Match the last part in the src_path which is source file name
  #seperator is '/' for linux path and '\' for NT 
  $src_name =~ s,(.*/|.*\\)(.*)$,$2,;  
  
  $dst_path = shift(@{$args{'spcopy'}});

  # complete relative paths
  # paths begining with "/"(linux) or containing ":\" (NT) are OS paths
  if ($src_path !~ m':\\' and $src_path !~ m'^/')
  {
    $src_path = asmcmdshare_make_absolute($src_path);
  }

  if ($dst_path !~ m':\\' and $dst_path !~ m'^/')
  {
    # Target is ASM
    asmcmdsys_get_target_name($dbh,$src_name,$dst_path,\$dst_name);
  }
  else
  {
    # target is OS
    # if path exists it must be a directory
    if ( -d $dst_path )
    {
      $dst_name = $dst_path . '/' . $src_name;
    }
    else
    {
      $dst_name = $dst_path;
    }
  }
   
  if (!defined $src_path || !defined $dst_name)
  {
    asmcmdshare_trace(3, "NOTE: Either src_path or dst_name is not defined",
                        'n', 'n');
    return;
  }

  $update_gpnp = 1 if defined($args{'u'});
  
  $sth = $dbh->prepare(q{
     begin
       dbms_diskgroup.getfileattr(:src_path, :fileType, :fileSz, :blkSz);
     end;
     });

  # bind input params #
  $sth->bind_param( ":src_path", $src_path);

  # bind output params #
  $sth->bind_param_inout( ":fileType", \$fileType, $PLSQL_NUMBER);
  $sth->bind_param_inout( ":fileSz", \$fileSz, $PLSQL_NUMBER);
  $sth->bind_param_inout( ":blkSz", \$blkSz, $PLSQL_NUMBER);

  $ret = $sth->execute();

  if (!defined ($ret) && ($asmcmdglobal_hash{'mode'} eq 'n'))
  { 
    $asmcmdglobal_hash{'e'} = -1;
  }
  if (!defined $fileType || !defined $fileSz || !defined $blkSz)
  {
    @eargs = ( $src_path );
    asmcmdshare_error_msg(8303, \@eargs);
    asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
    return;
  }

  # reconnect
  asmcmdbase_disconnect($dbh) if defined ($dbh);

  #undef since we connect to local asm instance
  $dbh = asmcmdbase_connect(undef);

  $sth = $dbh->prepare(q{
     begin
       dbms_diskgroup.asmcopy(:src_path, :dst_name, :spfile_number, 
                              :fileType, :blkSz, :spfile_number2, 
                              :spfile_type, :client_mode);
     exception when others then
       raise;
     end;
     });

  $sth->bind_param( ":src_path", $src_path);
  $sth->bind_param( ":dst_name", $dst_name);
  $sth->bind_param( ":spfile_number", $spfile_number);
  $sth->bind_param( ":fileType", $fileType);
  $sth->bind_param( ":blkSz", $blkSz);
  $sth->bind_param( ":spfile_number2", $spfile_number);
  $sth->bind_param( ":spfile_type", $fileType);
  $sth->bind_param( ":client_mode", $client_mode);

  $ret = $sth->execute();
  if (!defined($ret))
  {
    if ($asmcmdglobal_hash{'mode'} eq 'n')	
    {	
      $asmcmdglobal_hash{'e'} = -1;	
    }	 
    asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
    return;
  }

  if ($update_gpnp)
  {

    $ret = asmcmdsys_spset($dbh, $dst_name);

    if (!defined($ret))
    {
      asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
      return;
    }
    asmcmdshare_trace(3, "NOTE: spfile $dst_name location has been set in"
                     ." gpnp profile ", 'n', 'n');
  }

  return;
}


########
# NAME
#   asmcmdsys_process_spmove
#
# DESCRIPTION
#   This function processes the asmcmd command spmove.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_spmove
{
  my ($dbh) = shift;
  my ($attr, $val);
  my ($sth);
  my ($src_path, $dst_path, $src_name, $dst_name,$spfile);
  my (%norm, $ret);
  my ($update_gpnp) = 0;
  my ($pl_sql_number) = 22;
  my ($spfile_number) = 253;
  my (%args);
  my ($fileType, $blkSz, $fileSz);
  my ($client_mode) = 0;
  my ($gname);
  my (@eargs);

  # Get option parameters, if any.
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
  return unless defined ($ret);

  # SPMOVE operation for ASM SPFILE requires SYSASM privilege
  if($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg (9485, undef);
    return;
  }

  $src_path = shift(@{$args{'spmove'}});
  $src_path =~ /(.*)/;
  $src_path = $1;

  $src_name = $src_path;
  #Match the last part in the src_path which is source file name
  #seperator is '/' for linux path and '\' for NT
  $src_name =~ s,(.*/|.*\\)(.*)$,$2,;

  $dst_path = shift(@{$args{'spmove'}});

  # complete relative paths
  # paths begining with "/"(linux) or containing ":\" (NT) are OS paths
  if($src_path !~ m':\\' and $src_path !~ m'^/')
  {
    $src_path = asmcmdshare_make_absolute($src_path);
  }

  if($dst_path !~ m':\\' and $dst_path !~ m'^/')
  {
    # Target is ASM
    asmcmdsys_get_target_name($dbh,$src_name,$dst_path,\$dst_name);
  }
  else
  {
    # target is OS
    # if path exists it must be a directory
    if ( -d $dst_path )
    {
      $dst_name = $dst_path . '/' . $src_name;
    }
    else
    {
      $dst_name = $dst_path;
    }
  }

  return if (!defined $src_path || !defined $dst_name);

  $sth = $dbh->prepare(q{
     begin
       dbms_diskgroup.getfileattr(:src_path, :fileType, :fileSz, :blkSz);
     end;
     });

  # bind input params #
  $sth->bind_param( ":src_path", $src_path);

  # bind output params #
  $sth->bind_param_inout( ":fileType", \$fileType, $PLSQL_NUMBER);
  $sth->bind_param_inout( ":fileSz", \$fileSz, $PLSQL_NUMBER);
  $sth->bind_param_inout( ":blkSz", \$blkSz, $PLSQL_NUMBER);

  $ret = $sth->execute();
  if ((!defined ($ret))  && $asmcmdglobal_hash{'mode'} eq 'n')	
  {	
     $asmcmdglobal_hash{'e'} = -1;	
  }	
  
  if (!defined $fileType || !defined $fileSz || !defined $blkSz)
  {
    @eargs = ( $src_path );
    asmcmdshare_error_msg(8303, \@eargs);
    asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
    return;
  }

  # reconnect
  asmcmdbase_disconnect($dbh) if defined ($dbh);

  #undef since we connect to local asm instance
  $dbh = asmcmdbase_connect(undef);

  $sth = $dbh->prepare(q{
     begin
       dbms_diskgroup.asmcopy(:src_path, :dst_name, :spfile_number, 
                              :fileType, :blkSz, :spfile_number2,
			      :spfile_type, :client_mode);
     exception when others then
       raise;
     end;
     });

  $sth->bind_param( ":src_path", $src_path);
  $sth->bind_param( ":dst_name", $dst_name);
  $sth->bind_param( ":spfile_number", $spfile_number);
  $sth->bind_param( ":fileType", $fileType);
  $sth->bind_param( ":blkSz", $blkSz);
  $sth->bind_param( ":spfile_number2", $spfile_number);
  $sth->bind_param( ":spfile_type", $fileType);
  $sth->bind_param( ":client_mode", $client_mode);

  $ret = $sth->execute();
  if (!defined($ret))
  {
    if ($asmcmdglobal_hash{'mode'} eq 'n')
    {
       $asmcmdglobal_hash{'e'} = -1;
    }
    asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
    return;
  }

  # if the current spfile is the active one, update gpnp
  $spfile = asmcmdsys_dualget($dbh, 'asm_spfile');

  if (!defined($spfile) or $spfile ne $dst_name)
  {
    asmcmdshare_trace(3, "NOTE: The current spfile is the active one."
        ." Updating gpnp profile to $dst_name", 'n', 'n');
    $ret = asmcmdsys_spset($dbh, $dst_name);
    if (!defined($ret))
    {
      asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
     
      # UNDO the move if GPnP update is not successful 
      if($dst_name =~ m'^\+')  
      {
        %norm = asmcmdshare_normalize_path($dbh, $src_path, 0, \$ret);
        $gname = asmcmdshare_get_gname_from_ gnum ($dbh, $norm{'gnum'}->[0]);
        asmcmdbase_rm_sql($dbh, $gname, $norm{'path'}->[0], 0);
      }
      else
      {
        #os File
        #Untaint
        $dst_name =~ m/(.*)/;
        $dst_name = $1;
 
        unlink("$dst_name");
      }
      return;
    }
  }
  asmcmdbase_disconnect($dbh) if defined ($dbh);

  #undef since we connect to local asm instance
  $dbh = asmcmdbase_connect(undef);

  #delete the source file
  asmcmdshare_trace(3, "NOTE: Deleting the source file ", 'n', 'n');
  if ($src_path =~ m'^\+')
  {
    # asm spfile
    %norm = asmcmdshare_normalize_path($dbh, $src_path, 0, \$ret);  
    $gname = asmcmdshare_get_gname_from_gnum ($dbh, $norm{'gnum'}->[0]);
    asmcmdbase_rm_sql($dbh, $gname, $norm{'path'}->[0], 0);
  }
  else
  {
    #os spfile
    unlink($src_path);
  }
}


########
# NAME
#   asmcmdsys_process_spbackup
#
# DESCRIPTION
#   This function processes the asmcmd command spbackup.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_spbackup
{
  my ($dbh) = shift;
  my (%args, $ret);
  my ($src_path, $dst_path,$src_name,$dst_name);
  my ($sth, $fileType, $fileSz, $blkSz);
  my ($spfile_type)    = 31;
  my ($db_spfile_type) = 13;
  my ($spbackup_type)  = 33;
  my ($client_mode)    = 1;
  my (@eargs);

  # Get option parameters, if any.
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
  return unless defined ($ret);

  # SPBACKUP operation for ASM SPFILE requires SYSASM privilege
  if($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg (9485, undef);
    return;
  }

  $src_path = shift(@{$args{'spbackup'}});
  $src_path =~ /(.*)/;
  $src_path = $1;

  $src_name = $src_path;
  #Match the last part in the src_path which is source file name
  #seperator is '/' for linux path and '\' for NT
  $src_name =~ s,(.*/|.*\\)(.*)$,$2,;

  $dst_path = shift(@{$args{'spbackup'}});
  
  # complete relative paths
  # paths begining with "/"(linux) or containing ":\" (NT) are OS paths
  if($src_path !~ m':\\' and $src_path !~ m'^/')
  {
    $src_path = asmcmdshare_make_absolute($src_path);
  }

  if($dst_path !~ m':\\' and $dst_path !~ m'^/')
  {
    asmcmdsys_get_target_name($dbh,$src_name,$dst_path,\$dst_name);
  }
  else
  {
      # target is OS
      # if path exists it must be a directory
      if ( -d $dst_path )
      {
        $dst_name = $dst_path . '/' . $src_name;
      }
      else
      {
        $dst_name = $dst_path;
      }
  }
 
  if (!defined $src_path || !defined $dst_name)
  {
    asmcmdshare_trace(3, "NOTE: Either src_path or dst_name is not defined",
                                                    'n', 'n');
    return;
  }

  $sth = $dbh->prepare(q{
     begin
       dbms_diskgroup.getfileattr(:src_path, :fileType, :fileSz, :blkSz);
     end;
     });

  # bind input params #
  $sth->bind_param( ":src_path", $src_path);

  # bind output params #
  $sth->bind_param_inout( ":fileType", \$fileType, $PLSQL_NUMBER);
  $sth->bind_param_inout( ":fileSz", \$fileSz, $PLSQL_NUMBER);
  $sth->bind_param_inout( ":blkSz", \$blkSz, $PLSQL_NUMBER);

  $ret = $sth->execute();

  if ((!defined ($ret))  && $asmcmdglobal_hash{'mode'} eq 'n')	
  {	
    $asmcmdglobal_hash{'e'} = -1;	
  }	

  if (!defined $fileType || !defined $fileSz || !defined $blkSz 
      || ($fileType != $spfile_type && $fileType != $db_spfile_type))
  {
    @eargs = ( $src_path );
    asmcmdshare_error_msg(8303, \@eargs);
    asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y') if(defined($DBI::errstr));
    return;
  }
  
  # reconnect
  asmcmdbase_disconnect($dbh) if defined ($dbh);

  #undef since we connect to local asm instance
  $dbh = asmcmdbase_connect(undef);

  $sth = $dbh->prepare(q{
     begin
       dbms_diskgroup.asmcopy(:src_path, :dst_name, :spfile_number, 
                              :fileType, :blkSz, :dst_fnum, :dst_ftype,
			      :client_mode);
     exception when others then
       raise;
     end;
     });

  $sth->bind_param(":src_path", $src_path);
  $sth->bind_param(":dst_name", $dst_name);
  $sth->bind_param(":spfile_number", 0);
  $sth->bind_param(":fileType", $fileType);
  $sth->bind_param(":blkSz", $blkSz);
  $sth->bind_param(":dst_fnum", 0);
  $sth->bind_param(":dst_ftype", $spbackup_type);
  $sth->bind_param(":client_mode", $client_mode);

  $ret = $sth->execute();

  if (!defined($ret))
  {
    if($asmcmdglobal_hash{'mode'} eq 'n')	
    {	
      $asmcmdglobal_hash{'e'} = -1;	
    }	
    asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
    return;
  }

  asmcmdbase_disconnect($dbh) if defined ($dbh);

  #undef since we connect to local asm instance
  $dbh = asmcmdbase_connect(undef);
}



########
# NAME
#   asmcmdsys_get_target_name
#
# DESCRIPTION
#   This function gets the complete target file name when the
# destination is a directory or diskgroup for spcopy/spmove/spbackup.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#   src_name (IN) - spfile name
#   dst_path (IN) - destination path
#   dst_name (IN/OUT) - destination pathname
#
# RETURNS
#   Null.
#
# NOTES
# 
########
sub asmcmdsys_get_target_name
{
  my ($dbh,$src_name,$dst_path,$dst_name) = @_;
  my (@paths, @ref_ids, @par_ids, @dg_nums, @entry_list, $name ,$ret);
  my (%norm);
  my (@eargs);
  
  # target is ASM
  # if target is a relative path, complete it to be a valid ASM path
  %norm = asmcmdshare_normalize_path($dbh, $dst_path, 1, \$ret);

  # path exists, must be a directory, and need to complete it with
  # the source name
  if ( $ret == 0 )
  {
    # complete the path
    $dst_path = $norm{'path'}->[0];
  
    @paths   = @{ $norm{'path'} };
    @ref_ids = @{ $norm{'ref_id'} };
    @par_ids = @{ $norm{'par_id'} };
    @dg_nums = @{ $norm{'gnum'} };
    $name = $paths[0];
    $name =~ s,.*/(.*)$,$1,;

    if($ref_ids[0] == -1)
    {
      @eargs = ($dst_path);
      asmcmdshare_error_msg(8014, \@eargs);
      return;
    }
    asmcmdshare_get_subdirs($dbh, \@entry_list, $dg_nums[0],
                            $ref_ids[0], $par_ids[0], $name, undef, 0, 1);

    # if the directory is a diskgroup or a directory
    if ( ($ref_ids[0] != -1) && 
         (($ref_ids[0] == $dg_nums[0] << 24 ) ||
          ($entry_list[0]->{'alias_directory'} eq 'Y')))
    {
      $$dst_name = $dst_path . '/' . $src_name;
    }
    elsif($entry_list[0]->{'alias_directory'} eq 'N')
    {
      $$dst_name = $dst_path;
    }
    else
    {
      @eargs = ($dst_path);
      asmcmdshare_error_msg(8014, \@eargs);
      return;
    }
   }
   else
   {
     $$dst_name = $dst_path;
   }
}


########
# NAME
#   asmcmdsys_process_spget
#
# DESCRIPTION
#   This function processes the asmcmd command spget.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_spget
{
  my ($dbh) = shift;
  my ($spfile);

  # SPGET operation for ASM SPFILE requires SYSASM privilege
  if($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg (9485, undef);
    return;
  }

  # If any options are added to the command, 
  # asmcmdsys_parse_int_args() should be called.
  # 
  # Get option parameters, if any.
  #$ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
  #return unless defined ($ret);

  $spfile = asmcmdsys_dualget($dbh, 'asm_spfile'); 

  if (defined($spfile))
  {
    asmcmdshare_print($spfile ."\n");
  }
}


########
# NAME
#   asmcmdsys_process_dsset
#
# DESCRIPTION
#   This function processes the asmcmd command dsset.
#
#  USAGE
#   dsset [--normal] [--parameter] [--profile [-f]] pathname
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   second arg to gpnpsetds is false so that user supplied diskstring
#   gets pushed to gpnp profile.
#########
sub asmcmdsys_process_dsset
{
  
    my ($dbh) = @_;
    my ($ret, %args, $sth); 
    my ($forced);
    my ($qry);
    my ($gpnptool);
    my ($gpnp_sign);
    my ($gpnp_edit);
    my ($gpnp_seq);
    my ($prof_path);
    my ($peer_path);
    my ($seq_num);
    my ($buf);
    my ($normal);
    my ($num);
    my ($test);
    my ($status);
    my ($crs_home);
    my ($crsctl);
    my ($srvctl);
    my ($update);
    my ($path) = 0;
    my (@buff_arr);
    my ($check_siha);
    my (@eargs);

    $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
    return unless defined ($ret);

    $forced = 0;
    $normal = 0;

    if(defined($args{'normal'}) || (!defined($args{'parameter'}) && !defined($args{'profile'})))
    {
      $normal = 1;
    }

    if(defined($args{'f'}))
    {
      $forced = 1;
    }
    $path = join(',', @{$args{'dsset'}});
    # asm_diskstring should be of the format 'path1','path2','path3',.....
    $path =~ s/,/','/g;

    #ASM instance is required for all the options other than '--profile -f'
    if(!defined($dbh))
    {
      if(!(defined($args{'profile'}) && $forced == 1))
      {
        asmcmdshare_error_msg(8102, undef);
        return;
      }
    }

    # Problem:  If dsset is used multiple times in a asmcmd session
    # pathname gets messed up. Reason being, the buffer cache used for
    # storing pathname in SQL is not cleared on every call.
    # This workaround could be removed if the PL/SQL buffer problem is 
    # fixed.
    if(defined($dbh))
    {
      if (!(defined($args{'profile'}) && $forced == 1 ))
      {
        # If connection to ASM exists, and "--profile -f" not specified, then
        # disconnect and connect.
        asmcmdbase_disconnect ($dbh);
        $dbh = asmcmdbase_connect (undef)
      }
    }

    if($normal == 1)
    {
      
      $qry = "alter system set asm_diskstring='" . $path . "' SCOPE=BOTH";
      
      $ret = asmcmdshare_do_stmt($dbh,$qry);

      return;
    }

    if(defined($args{'profile'}))
    {
      if($forced == 1)
      {
        $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
        #The path in WIN is ORACLE_HOME/bin/crsctl.exe
        $crsctl .= ".exe" if($^O =~ /win/i);

        # Make sure the crsctl binary exists and can be executed. 
        if (! -x $crsctl)
        {
          #If not, try at a second locaction.
          $crsctl = "$ENV{'ORACLE_HOME'}/rdbms/bin/crsctl";
          $crsctl .= ".exe" if($^O =~ /win/i);

          if (! -x $crsctl)
          {
            @eargs = ($crsctl);
            asmcmdshare_error_msg(8313, \@eargs);
            return;
          }
        }

        #untaint crsctl
        $crsctl =~ /([^\n^\r^\t]+)/;
        $crsctl = $1;
     
        my $css = "$crsctl check css";

        asmcmdshare_trace(3, "NOTE: Checking the status of cluster.. ",
                             'y', 'n');
        eval
        {
          $buf = `$css`;
        };

        if($@ ne '')
        {
          asmcmdshare_error_msg(8309, undef);
          return;
        }

        # Check for the number at CRS-xxxx in the output.
        if($buf =~ /([^\d]+)([^:]+)/)
        {
           $status = $2;
           if(defined($status))
           {
            if($status eq 4529)
             {
               #output is CRS-4529: Cluster Synchronization Services is online
               asmcmdshare_error_msg(8308, undef);
               return;
             }
           }
           else
           {
             asmcmdshare_error_msg(8309, undef);
             return;
           }
        }
        else
        {
          asmcmdshare_error_msg(8309, undef);
          return;
        }

        $check_siha = "$crsctl status resource ora.crsd -init -g";
        
        eval 
        {
          $buf = `$check_siha`;
        };

        if($@ ne '')
        {
          asmcmdshare_error_msg(8315, undef);
          return;
        }

        # Get the error code form the o/p
        if($buf =~ /([^\d]+)([^:]+)/)
        {
          $status = $2;
          if(!defined($status))
          {
            asmcmdshare_error_msg(8315, undef);
            return;
          }
        }
        # siha mode, crsd is not registered
        # CRS-212: Resource 'ora.crsd' is not registered.
        if($status eq 212)
        {
          $srvctl = "$ENV{'ORACLE_HOME'}/bin/srvctl";
          #path in Win is ORACLE_HOME/bin/srvctl.bat
          $srvctl .= ".bat" if ($^O =~ /win/i);

          # Make sure the srvctl binary exists and can be executed. 
          if (! -x $srvctl)
          {
            #If not, try at a second locaction.
            $srvctl = "$ENV{'ORACLE_HOME'}/srvm/bin/srvctl";
            #path in Win is ORACLE_HOME/bin/srvctl.bat
            $srvctl .= ".bat" if ($^O =~ /win/i);

            if (! -x $srvctl)
            {
              @eargs = ($srvctl);
              asmcmdshare_error_msg(8316, \@eargs);
              return;
            }
          }

          $update = " $srvctl modify asm -d " . $path;
          $update =~ /([^\n^\r^\t]+)/;
          $update = $1;

          eval 
          {
            $buf = `$update 2>&1`;
          };
          if($@ ne '')
          {
            asmcmdshare_error_msg(8314, undef); 
          }

          return;
        }
        # cluster mode
        # CRS-4003 :Resource 'ora.crsd' is registered. 
        elsif($status eq 4003)
        {
          #HOSTNAME should be defined
          $buf = asmcmdshare_get_host_name();
          if(!defined($buf))
          {
            $buf = "HOSTNAME";
            @eargs = ($buf);
            asmcmdshare_error_msg(8318, \@eargs);
            return;
          }

        $gpnptool = "$ENV{'ORACLE_HOME'}/bin/gpnptool"; 
        # Adjust path for win
        $gpnptool .= ".exe" if($^O =~ /win/i);

         # Make sure the gpnptool binary exists and can be executed. 
         if (! -x $gpnptool)
         {
           #If not, try at a second locaction.
           $gpnptool = "$ENV{'ORACLE_HOME'}/has/bin/gpnptool";
           # Adjust path for win
           $gpnptool .= ".exe" if($^O =~ /win/i);

           if (! -x $gpnptool)
           {
             @eargs = ($gpnptool);
             asmcmdshare_error_msg(8305, \@eargs);
             return;
           }
         }

        # The location of profile.xml is different for production and
        # dev environment now. The current environment is being determined by
        # checking whethe ADE_VIEW_ROOT is set or not. Bug 8579922 is filed
        # for this issue.
  
        $test = "$ENV{'ORACLE_HOME'}/gpnp/".
                asmcmdshare_get_host_name().
                "/profiles/peer/profile.xml";

        if( -f $test) #production environment
        {
          $crs_home = "$ENV{'ORACLE_HOME'}";
        }
        else   # dev env
        {
          $test = "$ENV{'ORACLE_HOME'}/has_work/gpnp/".
                  asmcmdshare_get_host_name().
                  "/profiles/peer/profile.xml";
          if(-f $test)
          {
            $crs_home = "$ENV{'ORACLE_HOME'}/has_work";
          }
          else
          {
            asmcmdshare_error_msg(8319,undef);
            return;
          }

        }

        #if(!defined($ENV{'ADE_VIEW_ROOT'}))
        #{
        #  $crs_home = "$ENV{'ORACLE_HOME'}";
        #}
        #else
        #{
        #  $crs_home = "$ENV{'ORACLE_HOME'}/has_work";
        #}
        
        $prof_path = "$crs_home/gpnp/".
                     asmcmdshare_get_host_name ().
                     "/profiles/peer/profile.xml";

        #untaint prof_path
        $prof_path =~ /([^\n^\r^\t]+)/;
        $prof_path = $1;

        $peer_path = "$crs_home/gpnp/".
                     asmcmdshare_get_host_name().
                     "/wallets/peer";
        
        #untaint peer_path
        $peer_path =~ /([^\n^\r^\t]+)/;
        $peer_path = $1;

        # get the sequence number of the profile.
        $gpnp_seq = "$gpnptool getpval -p=$prof_path -prf_sq -o-";
        
        #untaint gpnp_seq
        $gpnp_seq =~ /([^\n^\r^\t]+)/;
        $gpnp_seq = $1;

        asmcmdshare_trace(3, "NOTE: Setting the gpnp profile sequence "
                                 ."number.. ", 'n', 'n'); 
        eval
        {
          $seq_num = `$gpnp_seq`;
        };
        if($@ ne '')
        {
          asmcmdshare_error_msg(8310, undef);
        }

        $seq_num = $seq_num + 3;

        $gpnp_edit = "$gpnptool edit -p=$prof_path -o=$prof_path -ovr " .
                    "-asm_dis=$path -prf_sq=$seq_num";
        
        #untaint gpnp_edit
        $gpnp_edit =~ /([^\n^\r^\t]+)/;
        $gpnp_edit = $1;

        asmcmdshare_trace(3, "NOTE: Editing the gpnp profile.. ", 'n', 'n');
        eval
        {
          $buf = `$gpnp_edit 2>&1`;
        };

        #check whether gpnp_edit succeeded.
        if ($@ ne '')
        {
          asmcmdshare_error_msg(8306, undef);
          return;
        }

        $gpnp_sign = "$gpnptool sign -p=$prof_path -o=$prof_path -ovr " .
          "-w=file:$peer_path";

        #untaint gpnp_sign
        $gpnp_sign =~ /([^\n^\r^\t]+)/;
        $gpnp_sign = $1;

        asmcmdshare_trace(3, "NOTE: Signing the gpnp profile.. ", 'n', 'n');
        # sign the gpnp profile once its edited.
        eval
        {
           @buff_arr = `$gpnp_sign 2>&1`;
        };
        
        #check whether gpnp_sign succeeded.
        if ($@ ne '')
        {
          asmcmdshare_error_msg(8307, undef);
          return;
        }
        }
        # could not determine mode
        else
        {
          asmcmdshare_error_msg(8315, undef);
          return;
        }
      }
      else
      {
        $sth = $dbh->prepare(q{
           begin
             dbms_diskgroup.gpnpsetds(:ds_path,0);
           exception when others then
              raise;
           end;
         });

        $sth->bind_param(":ds_path", $path);
      
        $ret = $sth->execute();  

        if (!defined ($ret))
        {
           if($asmcmdglobal_hash{'mode'} eq 'n')
           {
             $asmcmdglobal_hash{'e'} = -1;
           }
          asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
         }
      }
      return;
    }

    #parameter option.
    if(defined($args{'parameter'}))
    {
      $qry = "alter system set asm_diskstring='" . $path . "' SCOPE=MEMORY";
      
      $ret = asmcmdshare_do_stmt($dbh,$qry);

      return;
    }
}

########
# NAME
#   asmcmdsys_process_dsget
#
# DESCRIPTION
#   This function processes the asmcmd command dsget.
#
# USAGE
#   dsget [[--normal] [--profile [-f]] [--parameter]]
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
#########
sub asmcmdsys_process_dsget
{
    my ($dbh) = shift;
    my ($diskstring, $sth, $ret, $row, $val);
    my (@what, @from, @where);
    my ($num);
    my ($buf);
    my ($test);
    my ($parameter);
    my ($profile);
    my ($forced);
    my ($status);
    my (%args);
    my ($gpnptool);
    my ($gpnp_exec);
    my ($prof_path);
    my ($crs_home);
    my ($crsctl);
    my ($srvctl);
    my ($get_dis);
    my ($check_siha);
    my (@eargs);

    $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args); 
    return unless defined ($ret);

    $num       = keys(%args);
    $forced    = 0;
    $parameter = 0;
    $profile   = 0;

    if(defined($args{'f'}))
    {
      $forced = 1;
    }

    # normal mode should return both profile and parameter settings.
    # normal is the default option
    if(defined($args{'normal'}) || (!defined($args{'profile'}) && !defined($args{'parameter'})))
    {
      $parameter = 1;
      $profile = 1;
    }

    elsif(defined($args{'profile'}))
    {
      $profile = 1;
    }

    elsif(defined($args{'parameter'}))
    {
      $parameter = 1;
    }

    #ASM instance is required for all the options other than '--profile -f'
    if(!defined($dbh))
    {
      if(!(defined($args{'profile'}) && $forced == 1))
      {
        asmcmdshare_error_msg(8102, undef);
        return;
      }
    }

    if($parameter == 1)
    {
      push(@what, 'value');
      push(@from, 'v$parameter');
      push(@where, 'name=\'asm_diskstring\'');
    
      $sth = asmcmdshare_do_construct_select($dbh, \@what, \@from, \@where);

      $row = asmcmdshare_fetch($sth);
      asmcmdshare_finish($sth);

      $val = $row->{VALUE};

      #A row is always returned because asm_diskstring always exists.
      #If the value of row is NULL, then DBI returns undefined.
      #If the value of row is "", then DBI returns "".
      #It looks like empty string("") is being stored as NULL and hence DBI 
      #returns undefined value.
      
      #Adding code below to display empty string in dsget.
      $val = "" if !defined($val);
      
      if(defined($val))
      {
        asmcmdshare_print("parameter:" . $val . "\n");
      }

    }

    if($profile == 1)
    { 
      # force with profile option.
      if($forced == 1)
      {
        $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
        #The path in WIN is ORACLE_HOME/bin/crsctl.exe
        $crsctl .= ".exe" if($^O =~ /win/i);

        # Make sure the crsctl binary exists and can be executed. 
        if (! -x $crsctl)
          {
            #If not, try at a second locaction.
            $crsctl = "$ENV{'ORACLE_HOME'}/rdbms/bin/crsctl";
            #The path in WIN is ORACLE_HOME/bin/crsctl.exe
            $crsctl .= ".exe" if($^O =~ /win/i);

            if (! -x $crsctl)
              {
                @eargs = ($crsctl);
                asmcmdshare_error_msg(8313, \@eargs);
                return;
              }
          }

        #untaint crsctl
        $crsctl =~ /([^\n^\r^\t]+)/;
        $crsctl = $1;

        my $css = "$crsctl check css";
        asmcmdshare_trace(3, "NOTE: Checking the status of cluster.. ",
                                         'y', 'n');
        eval
        {
            $buf = `$css`;
        };

        if($@ ne '')
        {
            asmcmdshare_error_msg(8309, undef);
            return;
        }

        # Check for the number at CRS-xxxx in the output.
        # Could not check cluster status if anything fails.
        if($buf =~ /([^\d]+)([^:]+)/)
        {
          $status = $2;
          if(defined($status))
          {
            if($status eq 4529)
            {
              # CRS-4529: Cluster Synchronization Services is online
              asmcmdshare_error_msg(8308, undef);
              return;
            }
          }
          else
          {
            asmcmdshare_error_msg(8309, undef);
            return;
          }
        }
        else
        {
          asmcmdshare_error_msg(8309, undef);
          return;
        }
        # gpnpd does not come up in SIHA mode
        $check_siha = "$crsctl status resource ora.crsd -init -g";
        
        eval 
        {
          $buf = `$check_siha`;
        };
        if($@ ne '')
        {
          asmcmdshare_error_msg(8315, undef);
          return;
        }

        #get the erro code
        if($buf =~ /([^\d]+)([^:]+)/)
        {
          $status = $2;
          if(!defined($status))
          {
             asmcmdshare_error_msg(8315, undef);
             return;
          }
        }

        # siha mode, crsd is not registered        
        if($status eq 212)
        {
          $srvctl = "$ENV{'ORACLE_HOME'}/bin/srvctl";
          #path in Win is ORACLE_HOME/bin/srvctl.bat
          $srvctl .= ".bat" if ($^O =~ /win/i);

          # Make sure the srvctl binary exists and can be executed. 
          if (! -x $srvctl)
          {
            #If not, try at a second locaction.
            $srvctl = "$ENV{'ORACLE_HOME'}/srvm/bin/srvctl";
            #path in Win is ORACLE_HOME/bin/srvctl.bat
            $srvctl .= ".bat" if ($^O =~ /win/i);

            if (! -x $srvctl)
            {
              @eargs = ($srvctl);
              asmcmdshare_error_msg(8316, \@eargs);
              return;
            }
          }

          #untaint srvctl
          $srvctl =~ /([^\n^\r^\t]+)/;
          $srvctl = $1; 
       
          $get_dis = "$srvctl config asm";
          eval 
          {
            $buf = `$get_dis 2>&1`;
          };

          if($@ ne '')
          {
            asmcmdshare_error_msg(8317, undef);
            return;
          }

          # Extract the diskstring from the output
          if($buf =~ /string:([^\n]+)/)
          {
            if(defined($1))
            {
              asmcmdshare_print("profile:" . $1 . "\n");
            }
          }
          else
          {
            asmcmdshare_error_msg(8317, undef);
          }
          return;
        }
        #cluster mode
        elsif($status eq 4003)
        {
          #HOSTNAME should be defined
          $buf = asmcmdshare_get_host_name ();
          if(!defined($buf))
          {
            $buf = "HOSTNAME";
            @eargs = ($buf);
            asmcmdshare_error_msg(8318, \@eargs);
            return;
          }

        $gpnptool = "$ENV{'ORACLE_HOME'}/bin/gpnptool";
        # Adjust path for win
        $gpnptool .= ".exe" if($^O =~ /win/i);

        # Make sure the gpnptool binary exists and can be executed. 
        if (! -x $gpnptool)
        {
          #If not, try at a second locaction.
          $gpnptool = "$ENV{'ORACLE_HOME'}/has/bin/gpnptool";
          # Adjust path for win
          $gpnptool .= ".exe" if($^O =~ /win/i);

          if (! -x $gpnptool)
          {
            @eargs = ($gpnptool);
            asmcmdshare_error_msg(8305, \@eargs);
            return;
          }
        } 
        
        # The location of profile.xml is different for production and
        # dev environment now. The current environment is being determined by
        # checking whethe ADE_VIEW_ROOT is set or not. Bug 8579922 is filed
        # for this issue.

        $test = "$ENV{'ORACLE_HOME'}/gpnp/".
                asmcmdshare_get_host_name ().
                "/profiles/peer/profile.xml";

        if( -f $test)  #production env
        {
          $crs_home = "$ENV{'ORACLE_HOME'}";
        }
        else    #dev env
        {
          $test = "$ENV{'ORACLE_HOME'}/has_work/gpnp/".
                  asmcmdshare_get_host_name().
                  "/profiles/peer/profile.xml";

          if(-f $test)
          {
            $crs_home = "$ENV{'ORACLE_HOME'}/has_work";
          }
          else
          {
            asmcmdshare_error_msg(8319, undef);
            return;
          }

        }     

        #if(!defined($ENV{'ADE_VIEW_ROOT'}))
        #{
        #    $crs_home = "$ENV{'ORACLE_HOME'}";
        #}
        #else
        #{
        #    $crs_home = "$ENV{'ORACLE_HOME'}/has_work";
        #}

        #untaint gpnptool
        $gpnptool =~ /([^\n^\r^\t]+)/;
        $gpnptool = $1;

        $prof_path = "$crs_home/gpnp/".asmcmdshare_get_host_name().
                     "/profiles/peer/profile.xml";
        
        #untaint prof_path
        $prof_path =~ /([^\n^\r^\t]+)/;
        $prof_path = $1;

        $gpnp_exec = "$gpnptool getpval -p=$prof_path -asm_dis -o-";
 
        $gpnp_exec =~ /([^\n^\r^\t]+)/;
        $gpnp_exec = $1;

        eval
        {
          $buf = `$gpnp_exec`;
        };

        if($@ ne '')
        {
          asmcmdshare_error_msg(8307, undef);
          return;
        }

        if(defined($buf))
        {
          asmcmdshare_print("profile:" . $buf . "\n");
        }
       }
      else
      {
          asmcmdshare_error_msg(8315, undef);
          return;
        }
      }
      else
      {
        $diskstring = asmcmdsys_dualget($dbh, 'asm_diskstring'); 
    
        #Adding code below to display empty string in dsget.
        $diskstring = "" if !defined($diskstring);
        
        if(defined($diskstring))
        {  
          asmcmdshare_print("profile:" . $diskstring . "\n");
        }
      }
      return;
    }
}

########
# NAME
#   asmcmdsys_dualget
#
# DESCRIPTION
#   This function returns the requested valure from sys_cluster_properties.
#
# USAGE
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null. 
#   $what (IN) - property/value requested
#   $val  (OUT) -
#
# RETURNS
#   Requested value querying from sys_context
#
#########

sub asmcmdsys_dualget
{
    my ($dbh, $what) = @_;
    my ($stmt, $ret, $val, $row);
=pod
    We use 4000 because asm_diskstring can be more than the default max(256)
    The default maximum size can be overriden by specifying the optional length 
    parameter, which must be a NUMBER or a value that can be implicitly 
    converted to NUMBER.The valid range of values is 1 to 4000 bytes. If you 
    specify an invalid value, then Oracle Database ignores it and uses the 
    default.For more details see SYS_CONTEXT in SQL Reference.
=cut
    $stmt = "select sys_context('sys_cluster_properties','" . $what . "',4000) ".
            "as val from dual";
    $ret = asmcmdshare_do_select($dbh, $stmt);

    $row = asmcmdshare_fetch($ret);
    asmcmdshare_finish($ret);
    $val = $row->{VAL};
    return $val;
}


########
# NAME
#   asmcmdsys_spset
#
# DESCRIPTION
#   This function sets the spfile location in the gPnP profile.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#   spfile(IN) - spfile path.
#
# RETURNS
#   Path of the spfile.
#
# NOTES
#   The caller is responsible to check that the file exists.
#
########
sub asmcmdsys_spset
{  
  my ($dbh, $path) = @_;
  my ($ret, $sth);

  $sth = $dbh->prepare(q{
    begin
      dbms_diskgroup.gpnpsetsp(:spfile_path);
    exception when others then
      raise;
    end;
  });

  $sth->bind_param( ":spfile_path", $path);

  $ret = $sth->execute();

  return $ret;
}


########
# NAME
#   asmcmdsys_process_spset
#
# DESCRIPTION
#   This function processes the asmcmd command spset.
#
# PARAMETERS
#   dbh   (IN) - initialized database handle, must be non-null.
#
# RETURNS
#   Null.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_spset
{
  my ($dbh) = shift;
  my ($attr, $val);
  my ($ret, %args, $sth, $row, $dst_path);
  my ($spfile);
  my (%result);
  my (@eargs);
  my (@what , @from, @where, @order);

  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  ($spfile) = @{$args{'spset'}};

  # SPSET operation for ASM SPFILE requires SYSASM privilege
  if($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg (9485, undef);
    return;
  }

  #Normalize the path - if it is an OS path (starting with '/') 
  #it has to be absolute, otherwise it is either an absolute ASM path 
  #or a relative one

  if ( (($spfile !~ /^[a-z]:/i) && ($spfile !~ m'^[/\\\\]')) || ($spfile !~ m'^/'))
  {
    #It must be an ASM path. Normalize the ASM path
    %result = asmcmdshare_normalize_path ($dbh, $spfile, 0, \$ret);
    if ($ret != 0) 
    { 
      #Check if file exists
      @eargs = ($spfile);
      asmcmdshare_error_msg(8014, \@eargs);
      return;
    }
    ($spfile) = @{$result{'path'}};
  }
  else
  { 
    #It should be an absolute OS path. Check if file exists
    if ( !(-e $spfile) )
    {
      @eargs = ($spfile);
      asmcmdshare_error_msg(8014, \@eargs);
      return;
    }
    #$spfile =~ s/\\/\//g;
  }

    $ret = asmcmdsys_spset($dbh, $spfile);

    if (!defined($ret))
    {
      asmcmdshare_trace(1, "$DBI::errstr", 'y', 'y');
      return;
    }

    return;
}

########
# NAME
#   asmcmdsys_process_afdconfigure
#
# DESCRIPTION
#   To configure AFD on the local node
#
# PARAMETER
#   -d      -  disable AFD filtering mode
#   -e      -  enable  AFD filtering mode
#   -f      -  force   AFD configuration
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdconfigure
{
  my ($dbh) = @_;
  my ($sth);
  my ($qry);
  my ($path);
  my ($ret);
  my (%args);
  my (@eargs);
  my ($buf);
  my ($asmlib);
  my ($asmlibexists) = 0;
  my ($nofilter) = 0;
  my ($force) = 0;

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  $nofilter = $args{'d'};
  $force  = $args{'f'};
  if ($force)
  {
    asmcmdshare_trace(3, "NOTE: afd_configure 'force' option used", 'y', 'n');
  }

  # 0. Check for ASMLIB presence on Linux
  if (($^O =~ /linux/i))
  {
    my $dir = "/opt/oracle/extapi";
    if (-e "$dir")
    {
      open (ASMLIB, "find /opt/oracle/extapi/ | grep libasm.so |");
      while ($asmlib = <ASMLIB>)
      {
        $asmlibexists = 1;
      }
      close(ASMLIB);
    }
    open (ASMLIB, "/sbin/lsmod | grep oracleasm |");
    while ($asmlib = <ASMLIB>)
    {
      $asmlibexists = 1;
    }
    close(ASMLIB);
    if ($asmlibexists)
    {
      my $asm_dis;
      $asm_dis = asmcmdsys_get_asmdiskstr_fromprofile();
      if ($asm_dis)
      {
        asmcmdshare_trace(3, "NOTE: ASMLib present; asm diskstring : $asm_dis",
                          'y', 'n');
        #9519-"ASMLib is present; command requires blank ASM disk string"
        @eargs = ($asm_dis);
        asmcmdshare_error_msg(9519, \@eargs);
        return;
      }
    }
  }

  # 1. Check if AFD is supported and not loaded.
  #    Skipping is_afd_supported on a system with asmlib exists.
  if ((!$asmlibexists) && (!asmcmdsys_is_afd("supported")))
  {
    #9520-"AFD is not '%s'"
    @eargs = "supported";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }
  if ((!$force) && (asmcmdsys_is_afd("loaded")))
  {
    # start OHASD
    if (!asmcmdsys_ohasd("start"))
    {
      #9524-"AFD configuration failed"
      @eargs = "ERROR: OHASD start failed";
      asmcmdshare_error_msg(9524, \@eargs);
      return;
    }
    # Even if AFD is loaded on the node, check if its resource is present.
    if (asmcmdsys_afd_resource("status"))
    {
      #9527-"AFD is loaded, but resource ora.driver.afd does not exist"
      asmcmdshare_error_msg(9527);
    }
    else
    {
      #9521-"AFD is already configured"
      asmcmdshare_error_msg(9521);
    }
    # stop OHASD
    if (!asmcmdsys_ohasd("stop"))
    {
      #9524-"AFD configuration failed"
      @eargs = "ERROR: OHASD stop failed";
      asmcmdshare_error_msg(9524, \@eargs);
      return;
    }
    return;
  }

  # 2. Verify that the command is run as 'root' and clusterware is down
  if (!asmcmdsys_am_root())
  {
    #9521-"command requires Root access"
    asmcmdshare_error_msg(9522);
    return;
  }
  if (!asmcmdsys_is_cluster_down())
  {
    #9523-"command cannot be used when Oracle Clusterware stack is up"
    asmcmdshare_error_msg(9523);
    return;
  }

  # 3. Handle ASMLib if configured.
  $asmlibexists = asmcmdsys_handle_asmlib();
  if ($asmlibexists == 2)
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: ASMLib deconfiguration failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }

  # 4. Install AFD
  if (!asmcmdsys_afdroot("install"))
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: afdroot install failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }

  # 5. - Update afd.conf using kfod op=GPNP
  if (!asmcmdsys_update_afd_conf())
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: update of afd.conf file failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }
  else
  {
    # Enable filtering as well.
    if (!$nofilter)
    {
      asmcmdsys_afdfilter("enable", "");
    }
  }

  # 6. If ASMLib was present in the system and we removed it before installing
  #   AFD, then perform a rescan of the system for any ASMLib disks to be
  #   be managed by AFD.
  if ($asmlibexists)
  {
    my ($dfltstr) = "/dev/sd*";
    asmcmdsys_rescan_afd("$dfltstr");
  }
  else
  {
    asmcmdsys_rescan_afd();
  }

  # 7. - create init scripts
  if(!($^O =~ /win/i))
  {
    if (!asmcmdsys_copy_afdinit())
    {
      #9524-"AFD configuration failed"
      @eargs = "ERROR: copying afd init scripts to init directory failed";
      asmcmdshare_error_msg(9524, \@eargs);
      return;
    }
  }

  asmcmdshare_print("Modifying resource dependencies".
                    " - this may take some time.\n");
  # 8. start OHASD with -noautostart option. This starts only the OHASD.
  if (!asmcmdsys_ohasd("start"))
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: OHASD start failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }
  # 9. check and create ora.driver.afd OHASD resource
  if (!asmcmdsys_afd_resource("add"))
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: AFD resource add failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }
  # 10. Add a START dependency. Modify ora.cssd resource attributes.
  if (!asmcmdsys_modify_resource("add"))
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: AFD resource modify failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }
  # 11. stop OHASD
  if (!asmcmdsys_ohasd("stop"))
  {
    #9524-"AFD configuration failed"
    @eargs = "ERROR: OHASD stop failed";
    asmcmdshare_error_msg(9524, \@eargs);
    return;
  }
}

########
# NAME
#   asmcmdsys_process_afddeconfigure
#
# DESCRIPTION
#   To deconfigure AFD from the local node
#
# PARAMETER
#   NONE
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afddeconfigure
{
  my ($dbh) = @_;
  my ($sth);
  my ($qry);
  my ($path);
  my ($ret);
  my (%args);
  my (@eargs);
  my $afd_conf = "/etc/afd.conf";
  if($^O =~ /win/i)
  {
    ($afd_conf) = "$ENV{SYSTEMROOT}\\system32\\drivers\\afd.conf";
  }

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  # 1. is supported check 
  if (!asmcmdsys_is_afd("supported"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "Supported";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  # 2. Verify that the command is run as 'root', clusterware is down and 
  # AFD is configured.
  if (!asmcmdsys_am_root())
  {
    #9521-"command requires Root access"
    asmcmdshare_error_msg(9522);
    return;
  }

  # 3. check if AFD is installed on the node
  if (!asmcmdsys_is_afd("installed"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "installed";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  # 4. Check if cluster stack is down and ACFS driver is not loaded
  if (!asmcmdsys_is_cluster_down())
  {
    #9523-"command cannot be used when Oracle Clusterware stack is up"
    asmcmdshare_error_msg(9523);
    return;
  }
  # if acfs driver is in loaded state we can't uninstall AFD
  if (asmcmdsys_is_acfs("loaded"))
  {
    #9525-"AFD deconfiguration failed"
    @eargs = "ERROR: acfs driver is loaded";
    asmcmdshare_error_msg(9525, \@eargs);
    return;
  }

  # 5. uninstall AFD driver
  if (!asmcmdsys_afdroot("uninstall"))
  {
    #9525-"AFD deconfiguration failed"
    @eargs = "ERROR: afdroot uninstall failed";
    asmcmdshare_error_msg(9525, \@eargs);
    return;
  }

  # 6. remove afd.conf file
  if (-e "$afd_conf")
  {
    system("rm $afd_conf");
  }

  # 7. remove init scripts
  if(!($^O =~ /win/i))
  {
    asmcmdsys_rm_afdinit_init();
    asmcmdsys_rm_afdinit_rclevel();
  }
  asmcmdshare_print("Modifying resource dependencies".
                    " - this may take some time.\n");
  # 8. start OHASD with -noautostart option. This starts only the OHASD.
  if (!asmcmdsys_ohasd("start"))
  {
    #9525-"AFD deconfiguration failed"
    @eargs = "ERROR: OHASD start failed";
    asmcmdshare_error_msg(9525, \@eargs);
    return;
  }
  # 9. delete ora.driver.afd dependency in ora.cssd resource
  if (!asmcmdsys_modify_resource("delete"))
  {
    #9525-"AFD deconfiguration failed"
    @eargs = "ERROR: AFD resource modify failed";
    asmcmdshare_error_msg(9525, \@eargs);
    return;
  }

  # 10. delete ora.driver.afd resource
  if (!asmcmdsys_afd_resource("delete"))
  {
    #9525-"AFD deconfiguration failed"
    @eargs = "ERROR: AFD resource delete failed";
    asmcmdshare_error_msg(9525, \@eargs);
    return;
  }
  # 11. stop OHASD
  if (!asmcmdsys_ohasd("stop"))
  {
    #9525-"AFD deconfiguration failed"
    @eargs = "ERROR: OHASD stop failed";
    asmcmdshare_error_msg(9525, \@eargs);
    return;
  }
}

########
# NAME
#   asmcmdsys_process_afddsset
#
# DESCRIPTION
#   To set the AFD Discovery Disksstring
#
# PARAMETER
#   $dbh   (IN)  - initiatized database handle, must be non-null.
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afddsset
{
  my ($dbh) = @_;
  my ($sth);
  my ($qry);
  my ($path);
  my ($ret);
  my (%args);
  my (@eargs);
  my ($buf);
  my ($afdtool);
  my ($afdtoolafdds);

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  # Get the AFD Discovery diskstring
  $path = join(',', @{$args{'afd_dsset'}});

  # is AFD supported check 
  if (!asmcmdsys_is_afd("supported"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "Supported";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
  #The path in WIN is ORACLE_HOME/bin/afdtool.exe
  $afdtool .= ".exe" if($^O =~ /win/i);
  # Make sure the afdtool binary exists and can be executed. 
  if (! -x $afdtool)
  {
    @eargs = ($afdtool);
    asmcmdshare_error_msg(9516, \@eargs);
    return 0;
  }

  #untaint afdtool
  $afdtool =~ /([^\n^\r^\t]+)/;
  $afdtool = $1;

  asmcmdshare_trace(3, "NOTE: afdtool -afdds update '$path'", 'y', 'n');
  $afdtoolafdds = "$afdtool -afdds update '$path'";

  eval
  {
    $buf = `$afdtoolafdds`;
  };

  if ($buf)
  {
    asmcmdshare_trace(3, "FAIL: $buf", 'y', 'n');
    asmcmdshare_error_msg (9512, undef);
  }
  return;
}

########
# NAME
#   asmcmdsys_process_afddsget
#
# DESCRIPTION
#   To obtain the current AFD Discovery diskstring
#
# PARAMETERS
#   $dbh   (IN)  - initialized database handle, must be non-null.
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afddsget
{
  my ($dbh) = shift;
  my ($sth);
  my ($ret, $qry, $val, $row);
  my (%args);
  my (@eargs);
  my ($buf);
  my ($afdtool);
  my ($afdtoolafdds);

  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  # ASM instance is required
  if(!defined($dbh))
  {
    $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
    #The path in WIN is ORACLE_HOME/bin/afdtool.exe
    $afdtool .= ".exe" if($^O =~ /win/i);
    # Make sure the afdtool binary exists and can be executed. 
    if (! -x $afdtool)
    {
      @eargs = ($afdtool);
      asmcmdshare_error_msg(9516, \@eargs);
      return 0;
    }

    #untaint afdtool
    $afdtool =~ /([^\n^\r^\t]+)/;
    $afdtool = $1;

    asmcmdshare_trace(3, "NOTE: afdtool -afdds query", 'y', 'n');
    $afdtoolafdds = "$afdtool -afdds query";

    eval
    {
      $buf = `$afdtoolafdds`;
    };
    asmcmdshare_trace(3, "NOTE: $buf", 'y', 'n');

    if (!($buf =~ /AFD discovery/i))
    {
      asmcmdshare_error_msg (9511, undef);
    }
    else
    {
      asmcmdshare_print ("$buf");
    }
    return;
  }

  $qry = "SELECT SYS_CONTEXT (".
         "'SYS_ASMFD_PROPERTIES', 'AFD_DISKSTRING') AS VAL FROM DUAL";

  eval
  {
    $ret = asmcmdshare_do_select ($dbh, $qry);
    $row = asmcmdshare_fetch ($ret);
    asmcmdshare_finish ($ret);
    $val = $row->{VAL};
    $val = "" if !defined ($val);
    if (defined($val))
    {
      asmcmdshare_print ("AFD discovery string: ". $val. "\n");
    }
  };
  if (asmcmdexceptions::catch())
  {
    asmcmdshare_error_msg (9511, undef);
    return;
  }
}

########
# NAME
#   asmcmdsys_process_afdfilter
#
# DESCRIPTION
#   To enable or disable AFD filtering mode.
#   If the command is executed without specifying a disk path then
#   filtering is set at node level.
#
# PARAMETERS
#   $dbh   (IN)  - initialized database handle, must be non-null.
#
#    -e          -  enable  AFD filtering mode
#    -d          -  disable AFD filtering mode
#    <disk-path> -  OS disk path to set the AFD filtering mode on.
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdfilter
{
  my ($dbh) = shift;
  my ($sth);
  my ($ret, $qry, $val, $row);
  my (%args);
  my (@eargs);
  my ($filter);
  my ($diskpath);

  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  if ($args{'e'})
  {
    $filter  = "enable";
  }
  if ($args{'d'})
  {
    $filter  = "disable";
  }

  $diskpath = shift(@{$args{'afd_filter'}});
  if ($diskpath)
  {
    # verify the OS disk path exists
    if (! -e $diskpath)
    {
      #9528-"disk '%s' does not exist"
      @eargs = $diskpath;
      asmcmdshare_error_msg(9528, \@eargs);
      return;
    }
  }
  else
  {
    $diskpath = "";
  }

  # is AFD loaded check 
  if (!asmcmdsys_is_afd("loaded"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "Loaded";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  # execute the command
  asmcmdsys_afdfilter($filter, $diskpath);
}

########
# NAME
#   asmcmdsys_process_afdsetlabel
#
# DESCRIPTION
#   To associate a AFD label to a disk
#
# PARAMETERS
#   $dbh   (IN)  - initialized database handle, must be non-null.
#   label        - label for the disk
#   disk         - disk path
#   --rename     - to relabel a disk that was labeled earlier
#   --migrate    - to label a disk that was provisioned for ASM
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdsetlabel
{
  my ($dbh) = @_;
  my ($sth);
  my ($qry);
  my ($label, $dskpath);
  my ($ret);
  my (%args);
  my (@eargs);
  my ($labeloption) = "";
  my ($afdtool); 
  my ($afdtooladd); 
  my ($buf); 
  my ($force) = 0; 

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  # is AFD loaded check 
  if (!asmcmdsys_is_afd("loaded"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "Loaded";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  ($label, $dskpath) = @{$args{'afd_label'}};

  if (defined($args{'rename'}))
  {
    $labeloption = "RENAME";
    $force = 1; 
  }

  if (defined($args{'migrate'}))
  {
    $labeloption = "MIGRATE";
    $force = 1; 
  }

  # If ASM instance is not running; use afdtool
  if(!defined($dbh))
  {
    $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
    #The path in WIN is ORACLE_HOME/bin/afdtool.exe
    $afdtool .= ".exe" if($^O =~ /win/i);
    # Make sure the afdtool binary exists and can be executed. 
    if (! -x $afdtool)
    {
      @eargs = ($afdtool);
      asmcmdshare_error_msg(9516, \@eargs);
      return 0;
    }

    #untaint afdtool
    $afdtool =~ /([^\n^\r^\t]+)/;
    $afdtool = $1;

    if ($force)
    {
      asmcmdshare_trace(3, "NOTE: afdtool -add -f '$dskpath' '$label'",
                        'y', 'n');
      $afdtooladd = "$afdtool -add -f '$dskpath' '$label'";
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: afdtool -add '$dskpath' '$label'", 'y', 'n');
      $afdtooladd = "$afdtool -add '$dskpath' '$label'";
    }

    eval
    {
      $buf = `$afdtooladd`;
    };
    asmcmdshare_trace(3, "NOTE: $buf", 'y', 'n');

    if (!($buf =~ /labeled/))
    {
      @eargs = "$buf";
      asmcmdshare_error_msg (9513, \@eargs);
    }
    return;
  }

  $qry = "ALTER SYSTEM LABEL SET \'". $label . "\' TO \'". $dskpath .
          "\' $labeloption";

  eval
  {
    $sth = asmcmdshare_do_stmt ($dbh, $qry);
  };
  if (asmcmdexceptions::catch())
  {
    @eargs = "";
    asmcmdshare_error_msg (9513, \@eargs);
    return;
  }
}

########
# NAME
#   asmcmdsys_process_afdlsdsk
#
# DESCRIPTION
#   To list AFD disks.
#
# PARAMETERS
#   $dbh   (IN)  - initialized database handle, must be non-null.
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdlsdsk
{
  my ($dbh) = @_;
  my ($sth);
  my ($ret);
  my (%args);
  my (@eargs);
  my ($afdtool);
  my ($afdlsdsk);
  my ($buf);

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
  #The path in WIN is ORACLE_HOME/bin/afdtool.exe
  $afdtool .= ".exe" if($^O =~ /win/i);
  # Make sure the afdtool binary exists and can be executed. 
  if (! -x $afdtool)
  {
    @eargs = ($afdtool);
    asmcmdshare_error_msg(9516, \@eargs);
    return 0;
  }

  #untaint afdtool
  $afdtool =~ /([^\n^\r^\t]+)/;
  $afdtool = $1;

  $afdlsdsk = "$afdtool -getdevlist '\*' -mode";

  eval
  {
    $buf = `$afdlsdsk`;
  };
  asmcmdshare_print($buf);

  return 0;
}

########
# NAME
#   asmcmdsys_process_afdscan
#
# DESCRIPTION
#   To scan for AFD disks.
#   If the command is executed without specifying a disk string then
#   afd_diskstring value in afd.conf file is used.
#
# PARAMETERS
#   $dbh   (IN)   - initialized database handle, must be non-null.
#   <disk-string> -  OS disk string to scan the AFD disks.
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdscan
{
  my ($dbh) = shift;
  my ($sth);
  my ($ret, $qry, $val, $row);
  my (%args);
  my (@eargs);
  my ($diskpath);

  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  $diskpath = shift @{$args{'afd_scan'}};
  if(!defined($diskpath))
  {
    $diskpath = "";
  }

  # is AFD loaded check 
  if (!asmcmdsys_is_afd("loaded"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "Loaded";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  # execute the command
  asmcmdshare_trace(3, "NOTE: AFD Scan on '$diskpath'", 'y', 'n');
  asmcmdsys_rescan_afd("$diskpath");
}

########
# NAME
#   asmcmdsys_process_afdclrlabel
#
# DESCRIPTION
#   To clear an existing label (which is associated with a disk).
#
# PARAMETERS
#   $dbh   (IN)  - initialized database handle, must be non-null.
#   label        - label to clear
#   -f           - force clear the label and drain all I/Os 
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdclrlabel
{
  my ($dbh) = @_;
  my ($sth);
  my ($qry);
  my ($label);
  my ($ret);
  my (%args);
  my (@eargs);
  my ($afdtool);
  my ($afdtooldel);
  my ($buf);
  my ($force);

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  $force  = $args{'f'};

  # is AFD loaded check 
  if (!asmcmdsys_is_afd("loaded"))
  {
    #9520-"AFD is not '%s'"
    @eargs = "Loaded";
    asmcmdshare_error_msg(9520, \@eargs);
    return;
  }

  ($label) = shift(@{$args{'afd_unlabel'}});

  # If ASM instance is not running; use afdtool
  if(!defined($dbh))
  {
    $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
    #The path in WIN is ORACLE_HOME/bin/afdtool.exe
    $afdtool .= ".exe" if($^O =~ /win/i);
    # Make sure the afdtool binary exists and can be executed. 
    if (! -x $afdtool)
    {
      @eargs = ($afdtool);
      asmcmdshare_error_msg(9516, \@eargs);
      return 0;
    }

    #untaint afdtool
    $afdtool =~ /([^\n^\r^\t]+)/;
    $afdtool = $1;

    if ($force)
    {
      asmcmdshare_trace(3, "NOTE: afdtool -delete -f '$label'", 'y', 'n');
      $afdtooldel = "$afdtool -delete -f '$label'";
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: afdtool -delete '$label'", 'y', 'n');
      $afdtooldel = "$afdtool -delete '$label'";
    }

    eval
    {
      $buf = `$afdtooldel`;
    };
    asmcmdshare_trace(3, "NOTE: $buf", 'y', 'n');

    if (!($buf =~ /Unlabeled/))
    {
      @eargs = "$buf";
      asmcmdshare_error_msg (9514, \@eargs);
    }

    return;
  }

  if ($force)
  {
    $qry = "ALTER SYSTEM LABEL CLEAR \'". $label . "\' FORCE";
  }
  else
  {
    $qry = "ALTER SYSTEM LABEL CLEAR \'". $label . "\'";
  }
  eval
  {
    $sth = asmcmdshare_do_stmt ($dbh, $qry);
  };
  if (asmcmdexceptions::catch())
  {
    @eargs = "";
    asmcmdshare_error_msg (9514, \@eargs);
    return;
  }
}

########
# NAME
#   asmcmdsys_process_afdstate
#
# DESCRIPTION
#   To query the state of AFD
#
# PARAMETER
#   NONE
#
# RETURNS
#   NULL.
#
# NOTES
#   Only asmcmdsys_process_cmd() calls this function.
########
sub asmcmdsys_process_afdstate
{
  my ($ret);
  my (%args);
  my (@eargs);
  my ($host) = hostname;
  my ($state) = "";
  my ($filter) = "DEFAULT";
  my ($afdtool);
  my ($afdfilter);
  my ($buf);

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  if (!asmcmdsys_is_afd("supported"))
  {
    $state = "NOT SUPPORTED";
  }
  elsif (asmcmdsys_is_afd("loaded"))
  {
    $state = "LOADED";
    $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
    #The path in WIN is ORACLE_HOME/bin/afdtool.exe
    $afdtool .= ".exe" if($^O =~ /win/i);
    # Make sure the afdtool binary exists and can be executed. 
    if (! -x $afdtool)
    {
      @eargs = ($afdtool);
      asmcmdshare_error_msg(9516, \@eargs);
      return 0;
    }

    #untaint afdtool
    $afdtool =~ /([^\n^\r^\t]+)/;
    $afdtool = $1;

    $afdfilter = "$afdtool -filter query";

    eval
    {
      $buf = `$afdfilter`;
    };
    if ($buf =~ /Filtering Status: (.*)/)
    {
      $filter = $1;
    }
  }
  elsif (asmcmdsys_is_afd("installed"))
  {
    $state = "INSTALLED";
  }
  else
  {
    $state = "NOT INSTALLED";
  }

  @eargs = ($state, $filter , $host);
  asmcmdshare_error_msg(9526, \@eargs);
  return;
}

########
# NAME
#   asmcmdsys_afdfilter
#
# DESCRIPTION
#   To enable or disable filtering mode in AFD
#
# PARAMETER
#   enable  - enable filtering
#   disable - disable filtering
#
# RETURNS
#   1 if successfully enabled or disabled AFD filtering ; 0 otherwise.
#
# NOTES
########
sub asmcmdsys_afdfilter
{
  my ($action, $diskpath) = @_;
  my ($ret);
  my (%args);
  my (@eargs);
  my ($afdtool);
  my ($afdfilter);
  my ($buf);

  $ret = asmcmdsys_parse_int_args ($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  asmcmdshare_trace(3, "NOTE: $action AFD Filtering on '$diskpath'", 'y', 'n');
  $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
  #The path in WIN is ORACLE_HOME/bin/afdtool.exe
  $afdtool .= ".exe" if($^O =~ /win/i);
  # Make sure the afdtool binary exists and can be executed. 
  if (! -x $afdtool)
  {
    @eargs = ($afdtool);
    asmcmdshare_error_msg(9516, \@eargs);
    return 0;
  }

  #untaint afdtool
  $afdtool =~ /([^\n^\r^\t]+)/;
  $afdtool = $1;

  if ($diskpath eq "")
  {
    $afdfilter = "$afdtool -filter $action";
  }
  else
  {
    $afdfilter = "$afdtool -filter $action '$diskpath'";
  }

  eval
  {
    $buf = `$afdfilter`;
  };
  if ($buf =~ /$action/)
  {
    if ($diskpath eq "")
    {
      asmcmdshare_trace(3, "NOTE: AFD Filtering $action"."d on 'Node Level'",
                        'y', 'n');
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: AFD Filtering $action"."d on '$diskpath'",
                        'y', 'n');
    }
    return 1;
  }

  return 0;
}

########
# NAME
#   asmcmdsys_ohasd
#
# DESCRIPTION
#   This function will start OHASD without starting the rest of the stack
#    or stop OHASD.
#
# PARAMETERS
#   start - start OHASD
#   stop  - stop OHASD
#
# RETURNS
#   1 if successfully started ohasd ; 0 otherwise.
########
sub asmcmdsys_ohasd
{
  my ($action) = @_;
  my (@eargs);
  my $crsctlcmd;
  my $crsctl;
  my ($buf);
  my ($line);
  my (@lines);
  my ($cmdout);
  my ($status);
  my ($issiha);
  my ($crsmode);

  $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
  #The path in WIN is ORACLE_HOME/bin/crsctl.exe
  $crsctl .= ".exe" if($^O =~ /win/i);

  # Make sure the crsctl binary exists and can be executed. 
  if (! -x $crsctl)
  {
    @eargs = ($crsctl);
    asmcmdshare_error_msg(8313, \@eargs);
    return 0;
  }

  #untaint crsctl
  $crsctl =~ /([^\n^\r^\t]+)/;
  $crsctl = $1;
     
  # Verify if the env is either GI or SIHA
  $issiha = asmcmdsys_is_siha();

  if ($issiha)
  {
    $crsmode = "has";
  }
  else
  {
    $crsmode = "crs";
  }

  if ($action eq "start")
  {
    # start OHASD 
    $crsctlcmd = "$crsctl start $crsmode -noautostart";
    asmcmdshare_trace(3, "NOTE: Starting OHASD... ", 'y', 'n');
    $cmdout = 4123;
  }
  if ($action eq "stop")
  {
    # stop OHASD 
    $crsctlcmd = "$crsctl stop $crsmode -f";
    asmcmdshare_trace(3, "NOTE: Stopping OHASD... ", 'y', 'n');
    $cmdout = 4133;
  }

  eval
  {
    @lines = `$crsctlcmd`;
  };
  
  foreach $line (@lines)
  {
    if($line =~ /([^\d]+)([^:]+)/)
    { 
      $status = $2;
      if(defined($status))
      {
        # CRS-4123: Oracle High Availability Services has been started.
        # CRS-4133: Oracle High Availability Services has been stopped.
        if($status eq $cmdout)
        {
          # Successfully started or stopped OHASD
          return 1;
        }
      }
    }
  }
  # Failed to start or stop OHASD
  asmcmdshare_trace(3, "FAIL: Failed to $action OHASD", 'y', 'n');
  asmcmdshare_trace(3, "$status", 'y', 'n');
  return 0;
}
########
# NAME
#   asmcmdsys_modify_resource
#
# DESCRIPTION
#   This function will modify the dependencies of CSSD resources
#   ora.cssd and ora.cssdmonitor
#   SIHA - ora.cssd(START and STOP)
#   GI   - ora.cssd(STOP) and ora.cssdmonitor(START)
#
# PARAMETERS
#   add    - add ora.driver.afd dependency in cssd resource
#   delete - delete ora.driver.afd dependency from cssd resource
#
# RETURNS
#   1 if successfully modified ; 0 otherwise.
########
sub asmcmdsys_modify_resource
{
  my ($action) = @_;
  my (@eargs);
  my $notExist = 0;
  my $status;
  my $crsctlcmd;
  my (@cssdlines);
  my (@cssdmonlines);
  my ($line);
  my ($buf);
  my ($attr) = "";
  my ($resName) = "ora.driver.afd";
  my $issiha;

  my $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
  #The path in WIN is ORACLE_HOME/bin/crsctl.exe
  $crsctl .= ".exe" if($^O =~ /win/i);

  # Make sure the crsctl binary exists and can be executed. 
  if (! -x $crsctl)
  {
    @eargs = ($crsctl);
    asmcmdshare_error_msg(8313, \@eargs);
    return 0;
  }

  #untaint crsctl
  $crsctl =~ /([^\n^\r^\t]+)/;
  $crsctl = $1;

  # Verify if the env is either GI or SIHA
  $issiha = asmcmdsys_is_siha();

  # First read the resource dependencies
  $crsctlcmd = "$crsctl stat res ora.cssd -init -f";
  eval
  {
    @cssdlines = `$crsctlcmd`;
  };
  if (!$issiha)
  {
    $crsctlcmd = "$crsctl stat res ora.cssdmonitor -init -f";
    eval
    {
      @cssdmonlines = `$crsctlcmd`;
    };
  }
  
  if ($issiha)
  {
    # incase of SIHA modify ora.cssd resource
    foreach $line (@cssdlines)
    {
      if (($line =~ /START_DEPENDENCIES/) || ($line =~ /STOP_DEPENDENCIES/))
      {
        my $hard = "";
        my $weak = "";
        my $pullup = "";
        if ($line =~ /(.*)(hard\(.*?\))(.*)/)
        {
          $hard = $2;
        }
        if ($line =~ /(.*)(weak?\(.*?\))(.*)/)
        {
          $weak = $2;
        }
        if ($line =~ /(.*)(pullup?\(.*?\))(.*)/)
        {
          $pullup = $2;
        }
  
        if ($action eq "add")
        {
          if ($line =~ /START_DEPENDENCIES/)
          {
            if ($hard)
            {
              $hard =~ s/\)/,ora.driver.afd\)/;
            }
            else
            {
              $hard = "hard(ora.driver.afd)";
            }
            $attr = ("\"START_DEPENDENCIES=\'".$weak.$hard.$pullup . "\'\"");
          }
          if ($line =~ /STOP_DEPENDENCIES/)
          {
            $hard =~ s/\)/,shutdown:ora.driver.afd\)/;
            $attr = ("\"STOP_DEPENDENCIES=\'".$weak.$hard.$pullup . "\'\"");
          }
          # Now, update the resource attribute
          if ($attr)
          {
            $crsctlcmd = "$crsctl modify res ora.cssd -attr ".$attr." -init";
            asmcmdshare_trace(3, "cssd res modify command : $crsctlcmd",
                              'y', 'n');
            eval
            {
              $buf = `$crsctlcmd`;
            };
            if ($buf)
            {
              asmcmdshare_trace(3, "FAIL: Failed to modify ora.cssd resource" .
                                " attribute: $buf", 'y', 'n');
              return 0;
            }
          }
        }
        elsif ($action eq "delete")
        {
          my $tmpattr;
          if ($line =~ /START_DEPENDENCIES/)
          {
            if ($hard)
            {
              $hard =~ s/\,?ora.driver.afd//g;
              if ($hard =~ /hard\(\)/)
              {
                $hard = "";
              }
            }
            $line =~ s/\,?ora.driver.afd//g;
            if ($line =~ /START_DEPENDENCIES=(.*)/)
            {
              $tmpattr = $1;
            }
            $attr = ("\"START_DEPENDENCIES=\'".$weak.$hard.$pullup . "\'\"");
          }
          if ($line =~ /STOP_DEPENDENCIES/)
          {
            $line =~ s/\,?shutdown:ora.driver.afd//g;
            if ($line =~ /STOP_DEPENDENCIES=(.*)/)
            {
              $tmpattr = $1;
            }
            $attr = ("\"STOP_DEPENDENCIES=\'".$tmpattr . "\'\"");
          }
          # Now, update the resource attribute
          if ($attr)
          {
            $crsctlcmd = "$crsctl modify res ora.cssd -attr ".$attr." -init";
            asmcmdshare_trace(3, "cssd res modify command : $crsctlcmd",
                              'y', 'n');
            eval
            {
              $buf = `$crsctlcmd`;
            };
            if ($buf)
            {
              asmcmdshare_trace(3, "FAIL: Failed to modify ora.cssd resource".
                                " attribute: $buf", 'y', 'n');
              return 0;
            }
          }
        }
      }
    }
    asmcmdshare_trace(3, "NOTE: Modified ora.cssd res attributes", 'y', 'n');
  }
  else
  {
    # incase of GI modify ora.cssd and ora.cssdmonitor resources
    foreach $line (@cssdlines)
    {
      if ($line =~ /STOP_DEPENDENCIES/)
      {
        my $hard = "";
        my $weak = "";
        my $pullup = "";
        if ($line =~ /(.*)(hard\(.*?\))(.*)/)
        {
          $hard = $2;
        }
        if ($line =~ /(.*)(weak?\(.*?\))(.*)/)
        {
          $weak = $2;
        }
        if ($line =~ /(.*)(pullup?\(.*?\))(.*)/)
        {
          $pullup = $2;
        }

        if ($action eq "add")
        {
          $hard =~ s/\)/,shutdown:ora.driver.afd\)/;
          $attr = ("\"STOP_DEPENDENCIES=\'".$weak.$hard.$pullup . "\'\"");
          # Now, update the resource attribute
          if ($attr)
          {
            $crsctlcmd = "$crsctl modify res ora.cssd -attr ".$attr." -init";
            asmcmdshare_trace(3, "cssd res modify command : $crsctlcmd",
                              'y', 'n');
            eval
            {
              $buf = `$crsctlcmd`;
            };
            if ($buf)
            {
              asmcmdshare_trace(3, "FAIL: Failed to modify ora.cssd resource" .
                                " attribute: $buf", 'y', 'n');
              return 0;
            }
          }
        }
        elsif ($action eq "delete")
        {
          my $tmpattr;
          if ($line =~ /STOP_DEPENDENCIES/)
          {
            $line =~ s/\,?shutdown:ora.driver.afd//g;
            if ($line =~ /STOP_DEPENDENCIES=(.*)/)
            {
              $tmpattr = $1;
            }
            $attr = ("\"STOP_DEPENDENCIES=\'".$tmpattr . "\'\"");
          }
          # Now, update the resource attribute
          if ($attr)
          {
            $crsctlcmd = "$crsctl modify res ora.cssd -attr ".$attr." -init";
            asmcmdshare_trace(3, "cssd res modify command : $crsctlcmd",
                              'y', 'n');
            eval
            {
              $buf = `$crsctlcmd`;
            };
            if ($buf)
            {
              asmcmdshare_trace(3, "FAIL: Failed to modify ora.cssd resource".
                                " attribute: $buf", 'y', 'n');
              return 0;
            }
          }
        }
        last;
      }
    }
    foreach $line (@cssdmonlines)
    {
      if ($line =~ /START_DEPENDENCIES/)
      {
        my $hard = "";
        my $weak = "";
        my $pullup = "";
        if ($line =~ /(.*)(hard\(.*?\))(.*)/)
        {
          $hard = $2;
        }
        if ($line =~ /(.*)(weak?\(.*?\))(.*)/)
        {
          $weak = $2;
        }
        if ($line =~ /(.*)(pullup?\(.*?\))(.*)/)
        {
          $pullup = $2;
        }

        if ($action eq "add")
        {
          $hard =~ s/\)/,ora.driver.afd\)/;
          if (!$hard)
          {
            $hard = "hard(ora.driver.afd)";
          }
          $attr = ("\"START_DEPENDENCIES=\'".$weak.$hard.$pullup . "\'\"");
          # Now, update the resource attribute
          if ($attr)
          {
            $crsctlcmd = "$crsctl modify res ora.cssdmonitor -attr ".$attr.
                          " -init";
            asmcmdshare_trace(3, "cssdmonitor res modify command : $crsctlcmd",
                              'y', 'n');
            eval
            {
              $buf = `$crsctlcmd`;
            };
            if ($buf)
            {
              asmcmdshare_trace(3, "FAIL: Failed to modify ora.cssdmonitor " .
                                "resource attribute: $buf", 'y', 'n');
              return 0;
            }
          }
        }
        elsif ($action eq "delete")
        {
          my $tmpattr;
          if ($line =~ /START_DEPENDENCIES/)
          {
            $line =~ s/\,?ora.driver.afd//g;
            if ($line =~ /START_DEPENDENCIES=.*\(\)/)
            {
              $attr = ("\"START_DEPENDENCIES=\"");
            }
            elsif ($line =~ /START_DEPENDENCIES=(.*)/)
            {
              $tmpattr = $1;
              $attr = ("\"START_DEPENDENCIES=\'".$tmpattr . "\'\"");
            }
          }
          # Now, update the resource attribute
          if ($attr)
          {
            $crsctlcmd = "$crsctl modify res ora.cssdmonitor -attr ".$attr.
                          " -init";
            asmcmdshare_trace(3, "cssdmonitor res modify command : $crsctlcmd",
                              'y', 'n');
            eval
            {
              $buf = `$crsctlcmd`;
            };
            if ($buf)
            {
              asmcmdshare_trace(3, "FAIL: Failed to modify ora.cssdmonitor ".
                                "resource attribute: $buf", 'y', 'n');
              return 0;
            }
          }
        }
        last;
      }
    }
    asmcmdshare_trace(3, "NOTE: Modified ora.cssd and ora.cssdmonitor".
                      " resource attributes", 'y', 'n');
  }
  return 1;
}

########
# NAME
#   asmcmdsys_afd_resource_type
#
# DESCRIPTION
#   This function will add or remove or status check AFD OHASD resource type
#   ora.driver.afd.type
#   Keep consistent with oraafd.pm:actionASMDriverResource().
#
# PARAMETERS
#   add    - add the resource type in ohasd
#   delete - remove the resource type from ohasd
#   status - find the status of resource type from ohasd
#
# RETURNS
#   1 if resouce type doesn't exist or is added/removed; 0 otherwise.
########
sub asmcmdsys_afd_resource_type
{
  my ($action) = @_;
  my (@eargs);
  my $ORACLE_HOME = $ENV{'ORACLE_HOME'};
  my $type = "ora.driver.afd.type";
  my $baseType = "ora.daemon.type";
  my $templateFile = "driver.afd.type"; 
  my $CRS_HOME_TEMPLATE = catdir($ORACLE_HOME, "crs", "template");
  my $infile  = catfile($CRS_HOME_TEMPLATE, $templateFile);
  my $restypecmd;
  my $buf;
  my $notExist = 0;
  my $status;

  my $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
  #The path in WIN is ORACLE_HOME/bin/crsctl.exe
  $crsctl .= ".exe" if($^O =~ /win/i);

  # Make sure the crsctl binary exists and can be executed. 
  if (! -x $crsctl)
  {
    @eargs = ($crsctl);
    asmcmdshare_error_msg(8313, \@eargs);
    return 0;
  }

  #untaint crsctl
  $crsctl =~ /([^\n^\r^\t]+)/;
  $crsctl = $1;

  # First check the status of the resource type
  $restypecmd = "$crsctl stat type $type -init"; 
  eval
  {
    $buf = `$restypecmd`;
  };

  if(!($buf =~ /TYPE_NAME=ora.driver.afd.type/))
  { 
    #output: CRS-2560: Resource type 'ora.driver.afd.type' does not exist
    asmcmdshare_trace(3, "NOTE: ora.driver.afd.type res type doesn't exist",
                      'y', 'n');
    $notExist = 1;
  }
  # if action is 'status' then just send the status value
  if ($action eq "status")
  {
    return $notExist; 
  }
  # if resource type does not exist and action is 'add'
  if (scalar($notExist) > 0 && ($action eq "add"))
  {
    asmcmdshare_trace(3, "NOTE: Registering resource type ora.driver.afd.type",
                      'y', 'n');

    $restypecmd = "$crsctl add type $type -basetype $baseType " .
                   "-file $infile -init";
    eval
    {
      $buf = `$restypecmd`;
    };

    if ($buf)
    {
      asmcmdshare_trace(3, "FAIL: Failed to add resource type".
                        " ora.driver.afd.type: $buf", 'y', 'n');
      return 0;
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: added resource type ora.driver.afd.type",
                        'y', 'n');
      return 1;
    }
  }

  # if resource type exist and action is 'delete'
  if ((scalar($notExist) == 0) && ($action eq "delete"))
  {
    asmcmdshare_trace(3, "NOTE: Deleting resource type ora.driver.afd.type",
                      'y', 'n');

    $restypecmd = "$crsctl delete type $type -init";
    eval
    {
      $buf = `$restypecmd`;
    };

    if ($buf)
    {
      asmcmdshare_trace(3, "FAIL: Failed to delete resource type".
                        " ora.driver.afd.type: $buf", 'y', 'n');
      return 0;
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: deleted resource type ora.driver.afd.type",
                        'y', 'n');
      return 1;
    }
  }
  return 1;
}

########
# NAME
#   asmcmdsys_afd_resource
#
# DESCRIPTION
#   This function will add or remove or status check AFD OHASD resource
#   ora.driver.afd
#   Keep consistent with oraafd.pm:actionASMDriverResource().
#
# PARAMETERS
#   add    - add the resource 
#   delete - delete the resource 
#   status - find the status of resource
#
# RETURNS
#   1 if resouce doesn't exist or is added or removed; 0 otherwise.
########
sub asmcmdsys_afd_resource
{
  my ($action) = @_;
  my (@eargs);
  my (@lines);
  my ($buf);
  my ($crsctl);
  my ($crsctlcmd);
  my $notExist = 0;
  my $status;
  my $afd_attr;
  my $resName = "ora.driver.afd";
  my $resType = "ora.driver.afd.type";
  my $restypecmd;
  my ($issiha);
  my $ousr;
  my $ogrp;
  my $i;

  # Verify if the env is either GI or SIHA
  $issiha = asmcmdsys_is_siha();

  if (-e "$ENV{'ORACLE_HOME'}/crs/install/crsconfig_params")
  {
    unless (open(FD,"<$ENV{'ORACLE_HOME'}/crs/install/crsconfig_params"))
    {
       return 0;
    }
    @lines = <FD>;
    unless (close(FD))
    {
       return 0;
    }
    for($i = 0; $i<=$#lines; $i++)
    {
      if($lines[$i] =~ "ORACLE_OWNER=")
      {
        $ousr = $lines[$i];
        $ousr =~ /(.*\=)(.*)/i;
        $ousr = $2;
      }
      if($lines[$i] =~ "ORA_ASM_GROUP=")
      {
        $ogrp = $lines[$i];
        $ogrp =~ /(.*\=)(.*)/i;
        $ogrp = $2;
      }
    }
  }
  # if we can't retrieve oracle user and group then we cannot add/remove res.
  if (!$ousr && !$ogrp)
  {
    asmcmdshare_trace(3, "FAIL: Failed to retrieve Oracle owner & group",
                      'y', 'n');
    return 0;
  }

  $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
  #The path in WIN is ORACLE_HOME/bin/crsctl.exe
  $crsctl .= ".exe" if($^O =~ /win/i);

  # Make sure the crsctl binary exists and can be executed. 
  if (! -x $crsctl)
  {
    @eargs = ($crsctl);
    asmcmdshare_error_msg(8313, \@eargs);
    return 0;
  }

  #untaint crsctl
  $crsctl =~ /([^\n^\r^\t]+)/;
  $crsctl = $1;
     
  # Check the existence of the AFD resource
  $crsctlcmd = "$crsctl stat res ora.driver.afd -init";

  asmcmdshare_trace(3, "NOTE: Checking existence of AFD resource",
                    'y', 'n');
  eval
  {
    $buf = `$crsctlcmd`;
  };

  #if($buf =~ /([^\d]+)([^:]+)/)
  if(!($buf =~ /NAME=ora.driver.afd/))
  { 
    #output: CRS-2613: Could not find resource 'ora.driver.afd'.
    asmcmdshare_trace(3, "NOTE: ora.driver.afd resource doesn't exist",
                      'y', 'n');
    $notExist = 1;
  }

  # if resource doesn't exist and action is 'status'
  if ($action eq "status")
  {
    return $notExist;
  }
  # if resource doesn't exist and action is 'add'
  if (($notExist == 1) && ($action eq "add"))
  {
    # add AFD resource type if it does not exist.
    if (!asmcmdsys_afd_resource_type("add"))
    {
      asmcmdshare_trace(3, "FAIL: Failed to add AFD resource type", 'y', 'n');
      return 0;
    }

    if ($issiha)
    {
      $afd_attr = ("ACL=\'owner:$ousr:rwx,pgrp:$ogrp:r-x,other::r--," .
                   "user:$ousr:r-x\'");
    }
    else
    {
      $afd_attr = ("ACL=\'owner:root:rwx,pgrp:$ogrp:r-x,other::r--," .
                   "user:$ousr:r-x\'");
    }

    $crsctlcmd = ("$crsctl add resource $resName -attr \"". $afd_attr .
                  "\" -type $resType -init");
    eval
    {
      $buf = `$crsctlcmd`;
    };
    if ($buf)
    {
      # resource add failed
      asmcmdshare_trace(3, "FAIL: Failed to add AFD resource: $buf", 'y', 'n');
      return 0;
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: Added AFD resource", 'y', 'n');
      return 1;
    }
  }
  # if resource exists and action is 'delete'
  if (($notExist == 0) && ($action eq "delete"))
  {
    my (@lines);
    my ($line);
    # stop AFD resource
    $crsctlcmd = ("$crsctl stop resource $resName -init");
    eval
    {
      @lines = `$crsctlcmd`;
    };
    foreach $line (@lines)
    {
      if($line =~ /([^\d]+)([^:]+)/)
      { 
        $status = $2;
        if(defined($status))
        {
          #CRS-2677: Stop of 'ora.driver.afd' on 'slc05gkm' succeeded
          #CRS-2500: Cannot stop resource 'ora.driver.afd' as it is not running
          if (($status eq 2677) || ($status eq 2500))
          {
            # Successfully stopped AFD resource or it is not running.
            asmcmdshare_trace(3, "NOTE: AFD resource stopped or not running",
                              'y', 'n');
            $status = 1;
            last;
          }
        }
      }
    }
    if ((defined($status)) && ($status != 1))
    {
      # Failed to stop AFD resource.
      asmcmdshare_trace(3, "FAIL: Failed to stop AFD resource", 'y', 'n');
      return 0;
    }

    $crsctlcmd = ("$crsctl delete resource $resName -init");
    eval
    {
      $buf = `$crsctlcmd`;
    };
    if ($buf)
    {
      # resource delete failed
      asmcmdshare_trace(3, "FAIL: Failed to delete AFD resource : $buf",
                        'y', 'n');
      return 0;
    }
    else
    {
      asmcmdshare_trace(3, "NOTE: Deleted AFD resource", 'y', 'n');
      return 1;
    }
    # delete AFD resource type
    if (!asmcmdsys_afd_resource_type("delete"))
    {
      asmcmdshare_trace(3, "FAIL: Failed to delete AFD resource type",
                        'y', 'n');
      return 0;
    }
  }
  return 1;
}

########
# NAME
#   asmcmdsys_is_cluster_down
#
# DESCRIPTION
#   This function checks if clusterware is shutdown on the local system
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   1 if clusterware is down ; 0 otherwise.
########
sub asmcmdsys_is_cluster_down
{
  my ($crsctl);
  my ($has);
  my ($buf);
  my ($status);
  my (@eargs);

  $crsctl = "$ENV{'ORACLE_HOME'}/bin/crsctl";
  #The path in WIN is ORACLE_HOME/bin/crsctl.exe
  $crsctl .= ".exe" if($^O =~ /win/i);

  # Make sure the crsctl binary exists and can be executed. 
  if (! -x $crsctl)
  {
    @eargs = ($crsctl);
    asmcmdshare_error_msg(8313, \@eargs);
    return 0;
  }

  #untaint crsctl
  $crsctl =~ /([^\n^\r^\t]+)/;
  $crsctl = $1;
     
  $has = "$crsctl check has";

  eval
  {
    $buf = `$has`;
  };

  # Check for the number at CRS-xxxx in the output.
  if($buf =~ /([^\d]+)([^:]+)/)
  {
    $status = $2;
    if(defined($status))
    {
      if(($status eq 4639) || ($status eq 4047))
      {
        #output: CRS-4639: Could not contact Oracle High Availability Services
        #output: CRS-4047: No Oracle Clusterware components configured.
        asmcmdshare_trace(3, "NOTE: Status of clusterware stack : Not online",
                          'y', 'n');
        return 1;
      }
    }
    else
    {
      asmcmdshare_error_msg(8309, undef);
      return 0;
    }
  }
  return 0;
} # end asmcmdsys_is_cluster_down

########
# NAME
#   asmcmdsys_get_asmdiskstr_fromprofile
#
# DESCRIPTION
#   This function returns asm_diskstring value from gpnp profile.
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   asm_diskstring value if available ; "" otherwise.
########
sub asmcmdsys_get_asmdiskstr_fromprofile
{
  my ($kfodgpnp);
  my ($kfod);
  my (@buf);
  my (@eargs);

  # if unable to query, return empty string
  my $asmdiskstr = "";

  my ($asm_discstr) = "";
 
  $kfod = catfile($ENV{'ORACLE_HOME'}, 'bin', 'kfod');
  $kfod .= ".exe" if($^O =~ /win/i);
  # Make sure the kfod binary exists and can be executed. 
  if (! -x $kfod)
  {
    @eargs = ($kfod);
    asmcmdshare_error_msg(9515, \@eargs);
    return;
  }

  $kfodgpnp = "$kfod op=GPNPDSTR nohdr=true";
  eval
  {
    @buf = `$kfodgpnp`;
  };
    
  foreach my $line (@buf)
  {
    $asmdiskstr = $line;
  }

  # kfod returns one line o/p for asm_diskstring.
  # Last line contains the asm_diskstring.
  #
  # kfod may return 0 but asm_diskstring may
  # be 'Not Set' or 'Not Available'.
  #
  # If asm_diskstring was never setup at profile creation
  # time or later, the default value in profile.xml is
  # "++no-value-at-profile-creation--never-updated-through-ASM++"
  # This special string also needs to be handled well.
  # For those, return empty string.
  #
  # Empty string is interpreted as default discovery string
  # by afdboot/afdtool.
  #
  chomp($asmdiskstr);
  if( ($asmdiskstr eq "Not Set") ||
      ($asmdiskstr eq "Not Available") ||
      ($asmdiskstr eq "++no-value-at-profile-creation--never-updated-through-ASM++") )
  {
    $asmdiskstr = "";
  }

  asmcmdshare_trace(3, "Retrieved asm disk string from gpnp : \'$asmdiskstr\'",
                    'y', 'n');
  return $asmdiskstr;
} # end asmcmdsys_get_asmdiskstr_fromprofile

########
# NAME
#   asmcmdsys_isSUSELinux
#
# DESCRIPTION
#   This function checks if the node is running SUSE Linux
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   1 if the system is SUSE Linux ; 0 otherwise.
########
sub asmcmdsys_isSUSELinux
{
  my $buf;

  if($^O =~ /linux/i)
  {
    my @cmd = (catfile('/bin', 'rpm'), '-q', 'sles-release');

    eval
    {
      $buf = `@cmd`;
    };
    if (!($buf =~ /not installed/))
    {
      return 1;
    }
  }
  else
  {
    return 0;
  }
} # end asmcmdsys_isSUSELinux

########
# NAME
#   asmcmdsys_clean_rcdirs
#
# DESCRIPTION
#   This function removed AFD init start or kill scripts from rc directories.
#
# PARAMETERS
#   $file - name of the init script file ("afd" in this case)
#
# RETURNS
#   1 if no error; 0 otherwise.
########
sub asmcmdsys_clean_rcdirs
{
  my $file = $_[0];
  my @cmd;
  my @buf;

  if (!$file)
  {
    return 0;
  }

  #remove old ones
  if ($RCALLDIR)
  {
    my ($rc, $rcStartFile, $rcKillFile, $rcKillOldFile, $rcKillOld2File);
    my @RCALLDIRLIST = split (/ /, $RCALLDIR);

    foreach $rc (@RCALLDIRLIST)
    {
      if ($RC_START)
      {
        $rcStartFile = catfile ($rc, "$RC_START" . "$file");
        @cmd = "rm $rcStartFile 2>&1";
        eval
        {
          @buf = `@cmd`;
        };
      }
      if ($RC_KILL)
      {
        $rcKillFile = catfile ($rc, $RC_KILL . $file);
        @cmd = "rm $rcKillFile 2>&1";
        eval
        {
          @buf = `@cmd`;
        };
      }

      if ($RC_KILL_OLD)
      {
        $rcKillOldFile = catfile ($rc, $RC_KILL_OLD . $file);
        @cmd = "rm $rcKillOldFile 2>&1";
        eval
        {
          @buf = `@cmd`;
        };
      }
    }
  }
  return 1;
} # end asmcmdsys_clean_rcdirs

########
# NAME
#   asmcmdsys_copy_to_rcdirs
#
# DESCRIPTION
#   This function copies AFD init script to system init directory and also 
#   copies AFD init start or kill scripts from rc directories.
#
# PARAMETERS
#   $sourcefile - init script file to copy (say "GI_home/crs/init/afd")
#   $destfile   - name of the init file to copy as (say "/etc/init.d/afd")
#
# RETURNS
#   1 if no error; 0 otherwise.
########
sub asmcmdsys_copy_to_rcdirs
{
  my $sourcefile = $_[0];
  my $destfile   = $_[1];
  my @buf;
  my @cmd;

  if (!($sourcefile))
  {
    asmcmdshare_trace(3, "FAIL: Failed to copy AFD init scripts; no srcfile",
                      'y', 'n');
    return 0;
  }

  if (! -e $sourcefile)
  {
    asmcmdshare_trace(3, "FAIL: Failed to copy AFD init scripts to rcdirs",
                      'y', 'n');
    return 0;
  }

  # Copy to init dir
  copy ($sourcefile, catfile ($INITD, $destfile)) || return 0;
  @cmd = "chmod 0755 " . catfile($INITD, $destfile);
  eval
  {
    @buf = `@cmd`;
  };

  if (asmcmdsys_isSUSELinux())
  {
    # for SUSE Linux, do not create link to the file in the init dir
    return 1;
  }

  # Create a link to the file in the init dir
  my @RCSDIRLIST = split (/ /, $RCSDIR);
  foreach my $rc (@RCSDIRLIST)
  {
    @cmd = "rm $rc/$RC_START$destfile 2>&1";
    eval
    {
      @buf = `@cmd`;
    };
    symlink (catfile($INITD, $destfile),
             catfile($rc, "$RC_START$destfile")) || return 0;
  }
  my @RCKDIRLIST = split (/ /, $RCKDIR);
  foreach my $rc (@RCKDIRLIST)
  {
    @cmd = "rm $rc/$RC_KILL$destfile 2>&1";
    eval
    {
      @buf = `@cmd`;
    };
    symlink(catfile($INITD, $destfile),
            catfile($rc, "$RC_KILL$destfile")) || return 0;
  }

  asmcmdshare_trace(3, "Copied AFD init scripts to rcdirs", 'y', 'n');
  return 1;
} # end asmcmdsys_copy_to_rcdirs

########
# NAME
#   asmcmdsys_rm_afdinit_init
#
# DESCRIPTION
#   This function removes AFD init file (say "/etc/init.d/afd") from the node.
#
# PARAMETERS
#   NONE
#
# RETURNS
#   NONE
########
sub asmcmdsys_rm_afdinit_init
{
  my $afdfile = "$INITD"."afd";
  if(-e $afdfile)
  {
    unlink($afdfile);
  }
  return;
} # end asmcmdsys_rm_afdinit_init

########
# NAME
#   asmcmdsys_rm_afdinit_rclevel
#
# DESCRIPTION
#   This function is used to clean AFD init files or scripts from the node.
#
# PARAMETERS
#   NONE
#
# RETURNS
#   NONE
########
sub asmcmdsys_rm_afdinit_rclevel
{
  asmcmdsys_clean_rcdirs ("afd");
  return;
} # end asmcmdsys_rm_afdinit_rclevel

########
# NAME
#   asmcmdsys_copy_afdinit
#
# DESCRIPTION
#   This function is used to copy AFD init files or scripts to system dirs.
#
# PARAMETERS
#   NONE
#
# RETURNS
#   1 if no errors; 0 otherwise.
########
sub asmcmdsys_copy_afdinit
{
  my $INITDIR        = catfile ($ENV{'ORACLE_HOME'}, "crs", "init");
  my $srv            = "afd";
  my $INITDIR_SRV    = catfile ($INITDIR, $srv);

  asmcmdshare_trace(3, "Creating AFD init scripts", 'y', 'n');
  #if SUSE linux, copy the afd.sles to the rcdirs
  if (asmcmdsys_isSUSELinux())
  {
    $INITDIR_SRV = catfile ($INITDIR, "$srv.sles");
  }

  asmcmdsys_copy_to_rcdirs ($INITDIR_SRV, "afd") || return 0;
  return 1;
} # end asmcmdsys_copy_afdinit

########
# NAME
#   asmcmdsys_update_afd_conf
#
# DESCRIPTION
#   This function creates afd.conf file in the system directory and adds 
#   afd_diskstring parameter and with its value.
#
# PARAMETERS
#   NONE
#
# RETURNS
#   1 if no errors; 0 otherwise.
########
sub asmcmdsys_update_afd_conf
{
  my (@plines);
  my (@lines);
  my ($i);
  my ($line);
  my ($ousr);
  my ($ogrp);

  asmcmdshare_trace(3, "Updating afd.conf", 'y', 'n');

  if (-e "$ENV{'ORACLE_HOME'}/crs/install/crsconfig_params")
  {
    unless (open(FD,"<$ENV{'ORACLE_HOME'}/crs/install/crsconfig_params"))
    {
      asmcmdshare_trace(3, "FAIL: crsconfig_params file does not exist",
                        'y', 'n');
      return 0;
    }
    @plines = <FD>;
    unless (close(FD))
    {
      return 0;
    }
    for($i = 0; $i<=$#plines; $i++)
    {
      if($plines[$i] =~ "ORACLE_OWNER=")
      {
        $ousr = $plines[$i];
        $ousr =~ /(.*\=)(.*)/i;
        $ousr = $2;
      }
      if($plines[$i] =~ "ORA_ASM_GROUP=")
      {
        $ogrp = $plines[$i];
        $ogrp =~ /(.*\=)(.*)/i;
        $ogrp = $2;
      }
    }
  }

  # Update afd.conf with the default discovery string which is blank ''.
  # "afd_diskstring" is the key in afd.conf .
  my $afd_conf = "/etc/afd.conf";
  if($^O =~ /win/i)
  {
    ($afd_conf) = "$ENV{SYSTEMROOT}\\system32\\drivers\\afd.conf";
  }
  
  if(-e $afd_conf)
  {
    unless (open(FD,"<$afd_conf"))
    {
      return 0;
    }
    @lines = <FD>;
    unless (close(FD))
    {
      return 0;
    }
    for($i = 0; $i<=$#lines; $i++)
    {
      if($lines[$i] =~ /afd_diskstring/)
      {
        $lines[$i] =
          "afd_diskstring='".asmcmdsys_get_asmdiskstr_fromprofile()."'\n";
        last;
      }
    }
  }
  else
  {
    $lines[0] =
      "afd_diskstring='".asmcmdsys_get_asmdiskstr_fromprofile()."'\n";
  }

  # Write to afd.conf
  unless (open(FD,">$afd_conf"))
  {
    return 0;
  }
  foreach $line (@lines)
  {
    print FD $line;
  }
  unless (close(FD))
  {
    return 0;
  }

  # Set appropriate permissions on /etc/afd.conf file
  if ($ousr && $ogrp)
  {
    system("chown $ousr:$ogrp $afd_conf");
  }
  system ("chmod 0664 $afd_conf");
  asmcmdshare_trace(3, "Created $afd_conf", 'y', 'n');
  return 1;
} # end asmcmdsys_update_afd_conf

########
# NAME
#   asmcmdsys_handle_asmlib
#
# DESCRIPTION
#   This function verifies and removes ASMLib if exists in the system.
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   1 if ASMLib is removed, 2 in case of an error ; 0 otherwise.
########
sub asmcmdsys_handle_asmlib
{
  my ($asmlib);
  my ($asmlibexists) = 0;
  my ($afdtool);
  my ($buf);

  if (!($^O =~ /linux/i))
  {
    return $asmlibexists;
  }

  if (-e "/opt/oracle/extapi")
  {
    open (ASMLIB, "find /opt/oracle/extapi/ | grep libasm.so |");
    while ($asmlib = <ASMLIB>)
    {
      $asmlibexists = 1;
      chomp($asmlib);
      system("rm $asmlib 2>&1");
    } 
    close(ASMLIB);
  }
  open (ASMLIB, "/sbin/lsmod | grep oracleasm |");
  while ($asmlib = <ASMLIB>)
  {
    $asmlibexists = 1;
    my $cmd = "/sbin/rmmod oracleasm";
    eval
    {
      $buf = `$cmd 2>&1`;
    };
    if ($buf)
    {
      asmcmdshare_trace(3, "NOTE: unload ASMLIB failed: $buf; try second way",
                        'y', 'n');
      if (-e "/etc/init.d/oracleasm")
      {
        my $cmd = "/etc/init.d/oracleasm disable";
        eval
        {
          $buf = `$cmd 2>&1`;
        };
      }
      if (-e "/usr/sbin/oracleasm")
      {
        my $cmd = "/usr/sbin/oracleasm exit";
        eval
        {
          $buf = `$cmd 2>&1`;
        };
      }
      if ($buf)
      {
        asmcmdshare_trace(3, "FAIL: Failed to unload ASMLib driver:  $buf",
                          'y', 'n');
        return 2;
      }
    }
    else
    {
      return 1;
    }
  } 
  close(ASMLIB);

  return $asmlibexists;
}

########
# NAME
#   asmcmdsys_rescan_afd
#
# DESCRIPTION
#   This function rescans AFD disks on the local system
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   1 if AFD disks are rescanned; 0 otherwise.
########
sub asmcmdsys_rescan_afd
{
  my ($rescanstr) = @_;
  my (@eargs);
  my ($buf);
  my ($afdtool);
  my ($afdtoolrescan);

  $afdtool = "$ENV{'ORACLE_HOME'}/bin/afdtool";
  #The path in WIN is ORACLE_HOME/bin/afdtool.exe
  $afdtool .= ".exe" if($^O =~ /win/i);
  # Make sure the afdtool binary exists and can be executed. 
  if (! -x $afdtool)
  {
    @eargs = ($afdtool);
    asmcmdshare_error_msg(9516, \@eargs);
    return 0;
  }

  #untaint afdtool
  $afdtool =~ /([^\n^\r^\t]+)/;
  $afdtool = $1;

  if ($rescanstr)
  {
    asmcmdshare_trace(3, "NOTE: Rescanning AFD disks; diskstring:'$rescanstr'",
                    'y', 'n');
    $afdtoolrescan = "$afdtool -rescan '$rescanstr'";
  }
  else
  {
    asmcmdshare_trace(3, "NOTE: Rescanning AFD disks; diskstring : ''",
                      'y', 'n');
    $afdtoolrescan = "$afdtool -rescan";
  }
  eval
  {
    $buf = `$afdtoolrescan`;
  };
  if ($buf =~ /Rescanned/i)
  {
    return 1;
  }
  else
  {
    return 0;
  }
} #end asmcmdsys_rescan_afd

########
# NAME
#   asmcmdsys_afdroot
#
# DESCRIPTION
#   This function installs and loads AFD driver on the local system OR
#                 uninstalls AFD from the local system
#
# PARAMETERS
#   $action 
#
# RETURNS
#   1 if AFD is installed and loaded ; 0 otherwise.
########
sub asmcmdsys_afdroot
{
  my ($action) = @_;
  my (@eargs);
  my ($afdroot);
  my ($afdinstall);
  my (@lines);
  my ($line);
  my ($status);
  my ($cmdout);

  $afdroot = "$ENV{'ORACLE_HOME'}/bin/afdroot";
  #The path in WIN is ORACLE_HOME/bin/afdroot.exe
  $afdroot .= ".exe" if($^O =~ /win/i);
  # Make sure the afdroot binary exists and can be executed. 
  if (! -x $afdroot)
  {
    @eargs = ($afdroot);
    asmcmdshare_error_msg(9517, \@eargs);
    return 0;
  }

  #untaint afdroot
  $afdroot =~ /([^\n^\r^\t]+)/;
  $afdroot = $1;
     
  if ($action eq "install")
  {
    # Install AFD 
    asmcmdshare_trace(3, "NOTE: Installing AFD... ", 'y', 'n');
    $cmdout = 638;
  }
  if ($action eq "uninstall")
  {
    # uninstall AFD
    asmcmdshare_trace(3, "NOTE: Uninstalling AFD... ", 'y', 'n');
    $cmdout = 635;
  }

  $afdinstall = "$afdroot $action";
  eval
  {
    @lines = `$afdinstall`;
  };
  foreach $line (@lines)
  {
    print $line;
    if($line =~ /([^\d]+)([^:]+)/)
    { 
      $status = $2;
      if(defined($status))
      {
        # AFD-638: AFD installation correctness verified.
        if($status eq $cmdout)
        {
          # Successfully installed AFD.
          asmcmdshare_trace(3, "NOTE: Successfully $action". "ed AFD",
                            'y', 'n');
          return 1;
        }
      }
    }
  }
  asmcmdshare_trace(3, "FAIL: Failed to $action AFD", 'y', 'n');
  return 0;
} #end asmcmdsys_afdroot

########
# NAME
#   asmcmdsys_is_acfs
#
# DESCRIPTION
#   This function checks if AFD is loaded on the local system
#
# PARAMETERS
#   $state - installed/loaded/supported 
#
# RETURNS
#   1 if ACFS is loaded ; 0 otherwise.
########
sub asmcmdsys_is_acfs
{
  my ($state) = @_;
  my (@eargs);
  my ($buf);
  my ($acfsdriverstate);
  my ($acfsstate);

  # return not supproted if not any of these platforms.
  if (!($^O =~ /win/i) && !($^O =~ /linux/i) && !($^O =~ /solaris/i) &&
      (!($^O =~ /aix/i)))
  {
    # not supported
    return 0;
  }

  $acfsdriverstate = "$ENV{'ORACLE_HOME'}/bin/acfsdriverstate";
  #The path in WIN is ORACLE_HOME/bin/acfsdriverstate.exe
  $acfsdriverstate .= ".exe" if($^O =~ /win/i);
  # Make sure the acfsdriverstate binary exists and can be executed. 
  if (! -x $acfsdriverstate)
  {
    @eargs = ($acfsdriverstate);
    asmcmdshare_error_msg(9518, \@eargs);
    return;
  }

  #untaint acfsdriverstate
  $acfsdriverstate =~ /([^\n^\r^\t]+)/;
  $acfsdriverstate = $1;
     
  $acfsstate = "$acfsdriverstate $state";
  eval
  {
    $buf = `$acfsstate`;
  };
  if ((($state =~ /loaded/i) && ($buf =~ /true/i)) ||
      (($state =~ /supported/i) && ($buf =~ /Supported/i)) ||
      (($state =~ /installed/i) && ($buf =~ /true/i)))
  {
    asmcmdshare_trace(3, "NOTE: Verifying ACFS driver state : $state",
                      'y', 'n');
    return 1;
  }
  else
  {
    asmcmdshare_trace(3, "NOTE: Verifying ACFS driver state : Not $state",
                      'y', 'n');
    return 0;
  }
} # end asmcmdsys_is_acfs

########
# NAME
#   asmcmdsys_is_afd
#
# DESCRIPTION
#   This function checks if AFD is loaded on the local system
#
# PARAMETERS
#   $state - installed/loaded/supported 
#
# RETURNS
#   1 if AFD is loaded ; 0 otherwise.
########
sub asmcmdsys_is_afd
{
  my ($state) = @_;
  my (@eargs);
  my ($buf);
  my ($afddriverstate);
  my ($afdstate);

  # return not supproted if not any of these platforms.
  if (!($^O =~ /win/i) && !($^O =~ /linux/i) && !($^O =~ /solaris/i) &&
      (!($^O =~ /aix/i)))
  {
    # not supported
    return 0;
  }

  $afddriverstate = "$ENV{'ORACLE_HOME'}/bin/afddriverstate";
  #The path in WIN is ORACLE_HOME/bin/afddriverstate.exe
  $afddriverstate .= ".exe" if($^O =~ /win/i);
  # Make sure the afddriverstate binary exists and can be executed. 
  if (! -x $afddriverstate)
  {
    @eargs = ($afddriverstate);
    asmcmdshare_error_msg(9518, \@eargs);
    return;
  }

  #untaint afddriverstate
  $afddriverstate =~ /([^\n^\r^\t]+)/;
  $afddriverstate = $1;
     
  $afdstate = "$afddriverstate $state";
  eval
  {
    $buf = `$afdstate`;
  };
  if ((($state =~ /loaded/i) && ($buf =~ /true/i)) ||
      (($state =~ /supported/i) && ($buf =~ /Supported/i)) ||
      (($state =~ /installed/i) && ($buf =~ /true/i)))
  {
    asmcmdshare_trace(3, "NOTE: Verifying AFD driver state : $state",
                      'y', 'n');
    return 1;
  }
  else
  {
    asmcmdshare_trace(3, "NOTE: Verifying AFD driver state : Not $state",
                      'y', 'n');
    return 0;
  }
} # end asmcmdsys_is_afd

########
# NAME
#   asmcmdsys_am_root
#
# DESCRIPTION
#   This function verifies that the command is run as root.
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   1 if root ; 0 otherwise.
########
sub asmcmdsys_am_root
{
  # Windows Oracle always runs in admin mode
  if($^O =~ /win/i)
  {
    return 1;
  }

  if ($>) # get euid
  {
    # not zero (root)
    # If this is AIX, let the grid user in.
    if ($^O =~ /aix/i)
    {
      my $tusr;
      if (-e "$ENV{'ORACLE_HOME'}/crs/install/crsconfig_params")
      {
        $tusr=`grep ORACLE_OWNER $ENV{'ORACLE_HOME'}/crs/install/crsconfig_params|/usr/bin/cut -f2 -d '='`;
      }
      my $me=`/bin/id -un`;
      $tusr =~ s/\s+$//;
      $me =~ s/\s+$//;
      if ($me eq $tusr)
      {
        return 1;
      }
      else
      {
        return 0;
      }
    }

    return 0;
  }

  return 1;
} # end asmcmdsys_am_root

########
# NAME
#   asmcmdsys_is_siha
#
# DESCRIPTION
#   This function verifies that the oracle sw is SIHA.
#
# PARAMETERS
#   NONE 
#
# RETURNS
#   1 if SIHA ; 0 otherwise.
########
sub asmcmdsys_is_siha
{
  my $val = "";
  my $cfgfile = "/etc/oracle/ocr.loc";
  my $key = "local_only";

  # open OCRCONFIG file
  asmcmdshare_trace(3, "NOTE: asmcmdsys_is_siha Opening $cfgfile", 'y', 'n');
  if (-e $cfgfile)
  {
    open (CFGFL, "<$cfgfile") or return $val;
    while (<CFGFL>) {
       if (/^$key=(\S+)/) {
          $val = $1;
          last;
       }
    }
    close (CFGFL);
    asmcmdshare_trace(3, "NOTE: asmcmdsys_is_siha Value ($val) set for $key",
                      'y', 'n');
  }

  if ($val =~ m/true/i)
  {
    return 1;
  }

  return 0;
}

########
# NAME
#   asmcmdsys_is_help
#
# DESCRIPTION
#   This function is the help function for the ASMCMDSYS module.
#
# PARAMETERS
#   command     (IN) - display the help message for this command.
#
# RETURNS
#   1 if command found; 0 otherwise.
########
sub asmcmdsys_process_help 
{
  my ($command) = shift;       # User-specified argument; show help on $cmd. #
  my ($desc);                                # Command description for $cmd. #
  my ($succ) = 0;                         # 1 if command found, 0 otherwise. #

  if (asmcmdsys_is_cmd ($command)) 
  {                              # User specified a command name to look up. #
    $desc = asmcmdshare_get_help_desc($command);
    asmcmdshare_print "$desc\n";
    $succ = 1;
  }

  return $succ;
}



########
# NAME
#   asmcmdsys_is_cmd
#
# DESCRIPTION
#   This routine checks if a user-entered command is one of the known
#   ASMCMD internal commands that belong to the ASMCMDSYS module.
#
# PARAMETERS
#   arg   (IN) - user-entered command name string.
#
# RETURNS
#   True if $arg is one of the known commands, false otherwise.
########
sub asmcmdsys_is_cmd 
{
  my ($arg) = shift;

  return defined ( $asmcmdsys_cmds{ $arg } );
}


########
# NAME
#   asmcmdsys_is_wildcard_cmd
#
# DESCRIPTION
#   This routine determines if an ASMCMDSYS command allows the use 
#   of wild cards.
#
# PARAMETERS
#   arg   (IN) - user-entered command name string.
#
# RETURNS
#   True if $arg is a command that can take wildcards as part of its argument, 
#   false otherwise.
########
sub asmcmdsys_is_wildcard_cmd 
{
  my ($arg) = shift;
  my (%cmdhash); # Empty hash; no ASMCMDSYS command supports wildcards. # 

  return (asmcmdshare_get_cmd_wildcard($arg) eq "True");
}

########
# NAME
#   asmcmdsys_is_no_instance_cmd
#
# DESCRIPTION
#   This routine determines if a command can run without an ASM instance.
#
# PARAMETERS
#   arg   (IN) - user-entered command name string.
#
# RETURNS
#   True if $arg is a command that can run without an ASM instance 
#   or does not exist, false otherwise.
#
# NOTES
#   The asmcmdsys module currently supports no command that can run 
#   without an ASM instance.
########
sub asmcmdsys_is_no_instance_cmd 
{
  my ($arg) = shift;

  return !defined ($asmcmdsys_cmds{ $arg }) ||
         (asmcmdshare_get_cmd_noinst($arg) ne "True" ) ;
}

########
# NAME
#   asmcmdsys_parse_int_args
#
# DESCRIPTION
#   This routine parses the arguments for flag options for ASMCMDSYS
#   internal commands.
#
# PARAMETERS
#   cmd      (IN)  - user-entered command name string.
#   args_ref (OUT) - hash of user-specified flag options for a command,
#                    populated by getopts().
#
# RETURNS
#   Zero on success; undefined on error.
#
# NOTES
#   $cmd must already be verified as a valid ASMCMDSYS internal command.
########
sub asmcmdsys_parse_int_args 
{
  my ($cmd, $args_ref) = @_;
  my ($key);
  my (@string);

  # Use Gsmcmdparser_parse_issued_command() from the asmcmdparser package to parse arguments for
  # internal commands.  These arguments are stored in @ARGV.
  if(!asmcmdparser_parse_issued_command($cmd, $args_ref, \@string))
  {
    # Print correct command format if syntax error. #
    asmcmdsys_syntax_error($cmd);
    return undef;
  }
  return 0;
}

########
# NAME
#   asmcmdsys_syntax_error
#
# DESCRIPTION
#   This function prints the correct syntax for a command to STDERR, used 
#   when there is a syntax error.  This function is responsible for 
#   only ASMCMDSYS commands.
#
# PARAMETERS
#   cmd   (IN) - user-entered command name string.
#
# RETURNS
#   1 if the command belongs to this module; 0 if command not found.
#
# NOTES
#   These errors are user-errors and not internal errors.  They are of type
#   record, not signal.  
# 
#   N.B. Functions in this module can call this function directly, without
#   calling the asmcmdshare::asmcmdshare_syntax_error equivalent.  The
#   latter is used only by the asmcmdcore module.
########
sub asmcmdsys_syntax_error 
{
  my ($cmd) = shift;
  my ($cmd_syntax);                               # Correct syntax for $cmd. #
  my ($succ) = 0;
  #display syntax only if the command belongs to this module
  if (asmcmdsys_is_cmd($cmd))
  {
    $cmd_syntax = asmcmdshare_get_help_syntax($cmd);  # Get syntax for $cmd. #
    $cmd_syntax = asmcmdshare_trim_str ($cmd_syntax);   # Trim blank spaces #
    if (defined ($cmd_syntax))
    {
      asmcmdshare_printstderr 'usage: ' . $cmd_syntax . "\n";
      asmcmdshare_printstderr 'help:  help ' . $cmd . "\n";
      $succ = 1;
    }
  }

  return $succ;
}

########
# NAME
#   asmcmdsys_get_asmcmd_cmds
#
# DESCRIPTION
#   This routine constructs a string that contains a list of the names of all 
#   ASMCMD internal commands and returns this string.
#
# PARAMETERS
#   None.
#
# RETURNS
#   A string contain a list of the names of all ASMCMD internal commands.
#
# NOTES
#   Used by the help command and by the error command when the user enters
#   an invalid internal command.
#
#   IMPORTANT: the commands names must be preceded by eight (8) spaces of
#              indention!  This formatting is mandatory.
########
sub asmcmdsys_get_asmcmd_cmds 
{
  return asmcmdshare_filter_invisible_cmds(%asmcmdsys_cmds);
}

########
# NAME
#   asmcmdsys_process_mkcc
#
# DESCRIPTION
#   To create a client cluster
#
# PARAMETERS
#   $dbh   (IN)  - initialized database handle, must be non-null.
#
# RETURNS
#   NULL
#
# NOTES
#   Requires SYSASM privilage to execute this operation 
########
sub asmcmdsys_process_mkcc
{
  my ($dbh) = shift;                                         # get db handle #
  my ($clustername);                                   # client cluster name #
  my ($wrap);                                         # credential file name #
  my ($directacc);                            # direct access allowed or not #
  my ($version) = '';                               # client cluster version #
  my (%args);                            # Arguments passed with the command # 
  my ($ret);                      # asmcmdbase_parse_int_args() return value #
  my ($kfodop);                                          # arguments to kfod #
  my ($sth);

  $directacc  = 0;                                  # assume indirect access #

  # check if SYSASM privilages exist
  if($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg(9488, undef);
    return;
  }

  # get option parameters 
  $ret = asmcmdbase_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  # get the cluster name and direct access or not.
  ($clustername, $wrap) = @{$args{'mkcc'}};

  # optional parameter direct (or indirect)
  if (defined ($args{'direct'}))
  {
    $directacc = 1 ;                 # if specified direct access or indirect #
  }

  # optional parameter client cluster version
  if (defined ($args{'version'}))
  {
    $version = ($args{'version'});    # user specified client cluster version #
  }

  if (defined ($args{'version'}))
  {
    $sth = $dbh->prepare(q{
      begin
        dbms_diskgroup.createclientcluster (:clname, :direct_access, :clver);
      end;
    });

    #bind input parameters
    $sth->bind_param(":clname", $clustername);
    $sth->bind_param(":direct_access", $directacc);
    $sth->bind_param(":clver", $version);
  }
  else
  {
    $sth = $dbh->prepare(q{
      begin
        dbms_diskgroup.createclientcluster (:clname, :direct_access);
      end;
    });

    #bind input parameters
    $sth->bind_param(":clname", $clustername);
    $sth->bind_param(":direct_access", $directacc);
  }

  $ret = $sth->execute();
  if (!defined($ret))
  {
    my @eargs = ($clustername);
    asmcmdshare_error_msg (9476, \@eargs);
    asmcmdshare_trace(1, $DBI::errstr, 'y', 'y');
    $asmcmdglobal_hash{'e'} = -1 ;
    return ;
  }

  $kfodop = "op=credexport client_cluster=$clustername wrap=$wrap";
  # Environment variable 'ORACLE_HOME' will be set, otherwise
  # ASMCMD init code will bail out.

  # directories in which kfod can be found.
  my (@patharr) =("$ENV{'ORACLE_HOME'}/bin/",
                  "$ENV{'ORACLE_HOME'}/rdbms/bin/");
  my @result = asmcmdshare_execute_tool ("kfod",
                                         ".exe",
                                         $kfodop,
                                         \@patharr);
  # check if kfod succeeded.
  if ($asmcmdglobal_hash{'utilsucc'} ne 'true')
  {
    my @eargs = ($clustername);
    asmcmdshare_error_msg(9476, \@eargs);
    asmcmdshare_trace(1, (join("", @result)), 'y', 'y');
    $asmcmdglobal_hash{'e'} = -1 ;
    return;
  }
}

########
# NAME
#   asmcmdsys_process_rmcc
#
# DESCRIPTION
#   To delete a client cluster
#
# PARAMETERS
#   NONE
#
# RETURNS
#   NULL
#
# NOTES
#   Requires SYSASM privilage to execute this operation 
########
sub asmcmdsys_process_rmcc
{
  my ($clustername);                                   # client cluster name #
  my (%args);                            # Arguments passed with the command #
  my ($ret);                      # asmcmdbase_parse_int_args() return value # 
  my ($kfodop);                                          # arguments to kfod #
 
  # check if SYSASM privilages exist #
  if($asmcmdglobal_hash{'contyp'} ne "sysasm")
  {
    asmcmdshare_error_msg(9488, undef);
    return;
  }
  
  # get command parameters
  $ret = asmcmdsys_parse_int_args($asmcmdglobal_hash{'cmd'}, \%args);
  return unless defined ($ret);

  # get cluster name
  $clustername = shift @{$args{'rmcc'}};

  # construct argument to kfod
  $kfodop = "op=creddelclus client_cluster=$clustername";

  # adding optional parameters
  if(defined($args{'f'}))
  {
    $kfodop.=" force=TRUE";
  }

  # directories in which kfod can be found
  my (@patharr) =("$ENV{'ORACLE_HOME'}/bin/",
                  "$ENV{'ORACLE_HOME'}/rdbms/bin/");

  my (@result) = asmcmdshare_execute_tool("kfod",
                                          ".exe",
                                          $kfodop,
                                          \@patharr);

  # check if kfod succeeded.
  if ($asmcmdglobal_hash{'utilsucc'} ne 'true')
  {
    my @eargs = ($clustername);
    asmcmdshare_error_msg(9477, \@eargs);
    asmcmdshare_trace(1, (join("", @result)), 'y', 'y');
    $asmcmdglobal_hash{'e'} = -1 ;
    return;
  }
}

1;
