Rem
Rem $Header: rdbms/admin/bug19532017_upgrade.sql /st_rdbms_12.1.0.2.0dbpsu/1 2014/10/22 15:05:53 apfwkr Exp $
Rem
Rem bug19532017_upgrade.sql
Rem
Rem Copyright (c) 2014, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      bug19532017_upgrade.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/bug19532017_upgrade.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/bug19532017_upgrade.sql 
Rem    SQL_PHASE: CATLMNR
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: ORA-00955
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    abrown      09/23/14 - For abrown_ci_backport_19532017_12.1.0.2.2dbbp,
Rem                           just do create index.
Rem    abrown      09/23/14 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

@@?/rdbms/admin/sqlsessstart.sql
CREATE INDEX SYSTEM.LOGMNR_I3CDEF$
    ON SYSTEM.LOGMNR_CDEF$ (LOGMNR_UID, OBJ#) 
    TABLESPACE SYSAUX LOCAL LOGGING
/
@?/rdbms/admin/sqlsessend.sql
