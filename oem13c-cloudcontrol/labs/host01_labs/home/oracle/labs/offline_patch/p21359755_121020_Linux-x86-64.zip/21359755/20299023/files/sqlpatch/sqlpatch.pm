#!/usr/local/bin/perl
# 
# $Header: rdbms/admin/sqlpatch/sqlpatch.pm /st_rdbms_12.1.0.2.0dbpsu/10 2015/04/02 00:30:26 surman Exp $
#
# sqlpatch.pm
# 
# Copyright (c) 2012, 2015, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      sqlpatch.pm - <one-line expansion of the name>
#
#    DESCRIPTION
#      This package is a utility package which is used by the sqlpatch.pl
#      installation utility and SQL backport tests.  This package does all the
#      work for patching.  It contains the following public exported functions:
#
#      initialize(%sqlpatch_parameters)
#        Initializes the sqlpatch package based on the input parameters
#
#      patch()
#        Complete patching based on the initialized parameters.
#
#      finalize()
#        Cleans up and closes the database connection
#
#      usage()
#        Prints the usage (via sqlpatch.pl) to the screen and invocation log
#
#      sqlpatch_log()
#        Logs to the screen and/or invocation log
#
#    NOTES
#      Primarily used by sqlpatch.pl
#
#    MODIFIED   (MM/DD/YY)
#    surman      04/01/15 - Backport surman_bug-20440930 from main
#    surman      02/28/15 - 20440930: Locale-independent directory names
#    surman      01/30/15 - 20348653: Partially installed patches
#    apfwkr      01/05/15 - Backport surman_ci_backport_19547370_12.1.0.2.5dbbp
#                           from st_rdbms_12.1.0.2.0dbbp
#    apfwkr      01/05/15 - Backport surman_ci_backport_19547370_12.1.0.2.5dbbp
#                           from st_rdbms_12.1.0.2.0dbbp
#    surman      12/10/14 - Backport surman_bug-20099675 from main
#    surman      12/05/14 - 20099675: Rollback of bundle patches
#    surman      10/27/14 - Backport surman_bug-19520602 from main
#    surman      10/04/14 - Backport surman_ojvm_fixes_12.1.0.2dbpsu from
#                           st_rdbms_12.1.0.2.0dbpsu
#    surman      12/16/14 - Backport surman_bug-19547370 from main
#    surman      09/11/14 - 19547370: Much better logging
#    surman      10/02/14 - 19723336: Proper check of upgrade mode
#    surman      10/02/14 - 19708632: Install OJVM patches first
#    apfwkr      08/26/14 - Backport surman_bug-14643995 from main
#    surman      08/29/14 - 19520602: Bundle patch rollback
#    surman      08/25/14 - 19501299: Check catcon return codes
#    surman      08/18/14 - Always reload dbms_sqlpatch
#    surman      08/07/14 - 14643995: Only one invocation at a time
#    surman      08/04/14 - 19044962: Handle more errors
#    surman      07/29/14 - Backport surman_bug-19189317 from main
#    surman      07/21/14 - 19189525: Bootstrapping
#    surman      07/10/14 - 19189317: Handle quotes for -pdb
#    surman      06/24/14 - 19051526: Add QI prereq
#    surman      06/05/14 - Backport surman_bug-17277459 from main
#    apfwkr      05/20/14 - Backport mpradeep_bug-17665122_1 from main
#    surman      05/20/14 - 18537739: Handle -rollback all
#    surman      04/21/14 - 17277459: datapatch replaces catbundle
#    surman      04/17/14 - Backport surman_bug-17665117 from main
#    surman      04/04/14 - Backport surman_bug-17898119 from main
#    apfwkr      03/21/14 - Backport mpradeep_bug_17992382_1 from main
#    surman      03/21/14 - Backport surman_bug-18355572 from main
#    mpradeep    05/13/14 - 17665122: Check if patches require upgrade mode
#    surman      03/19/14 - 17665117: Patch UID
#    surman      03/14/14 - 17898119: Fix -oh
#    surman      03/13/14 - 18396989: Suppress warning on seed open
#    mpradeep    03/12/14 - 17992382 - Add check for orabase command
#    surman      03/11/14 - 18355572: Exit if prereqs fail and bundle fixes
#    surman      02/21/14 - Add -bundle_series
#    jerrede     01/22/14 - 17898118: Set PDB$SEED read write.
#    surman      12/20/13 - 17974971: Validate correct log file in multitenant
#    surman      12/20/13 - 17981677: Add ignorable_errors
#    surman      12/10/13 - 17922172: Handle multiple bundles
#    jerrede     10/30/13 - Add new catcon.pm parameter
#    surman      10/24/13 - 14563594: Add version to registry$sqlpatch
#    surman      10/22/13 - Use orabase
#    surman      10/16/13 - 17354355: Log directory under cfgtoologs
#    surman      10/11/13 - 17596344: Handle large number of patch files
#    jerrede     05/20/13 - Bug 17550069: Add new catcon.pm parameter
#    surman      09/17/13 - 17442449: Handle RAC better
#    surman      08/30/13 - 17354111: Validate catbundle logfiles
#    surman      08/06/13 - 17005047: datapatch calls catbundle
#    akruglik    07/24/13 - Bug 16603368: catconExec expects 3 more parameters
#    jerrede     05/20/13 - Add new catcon.pm parameter
#    surman      11/27/12 - 15911401: Trap ORA-20012 on rac
#    surman      11/09/12 - 15857388: Fix bind
#    surman      10/19/12 - 14787047: CDB support
#    surman      09/21/12 - 14372248: Handle sqlplus errors
#    surman      09/13/12 - 14624172: Add status column
#    surman      09/07/12 - 14563601: DB name and timestamp for logfile
#    surman      08/28/12 - 14503324: New QI interface
#    surman      07/14/12 - Windows changes
#    surman      07/13/12 - 14165102: Creation
# 

use strict;
package sqlpatch;

use File::Spec;
use File::Path qw(make_path);
use DBI;
use DBI qw(:sql_types);
use DBD::Oracle qw(:ora_session_modes);
use Data::Dumper;
use catcon qw(catconInit catconExec catconWrapUp);
use POSIX qw(strftime);

####################################################################
#                       PUBLIC FUNCTIONS                           #
####################################################################

# -------------------------------- initialize --------------------------------
# NAME
#   initialize
#
# DESCRIPTION
#   Initializes the sqlpatch package with the user specified parameters,
#   passed via a hash.  All parameters are passed as a string, and are
#   optional.
#
# ARGUMENTS
#   $dbh: database handle, already connected as SYS
#   $params_ref: Reference to a hash of parameters.  The valid parameters are:
#     apply: Comma separated list of either patch ids or patchid/uid pairs
#            which represents the list of patches to apply
#     rollback: Comma separated list of either patch ids or patchid/uid pairs
#            which represents the list of patches to rollback
#     force: If true the patches will be applied or rolled back regardless of
#            the current state
#     prereq_only: If true, run the prereq checks only and do not install
#     pdbs: Comma separated list of PDBs to consider
#     oh: User specified oracle_home to locate install scripts
#     verbose: If true, output additional information
#     debug: If true, output even more debugging information
#     bundle_series: Bundle series for patch (or NONE), used with -force
#     ignorable_errors: Comma separated list of ignorable errors
#
# RETURNS
#   0 for success, 1 for prereq failure with the arguments
sub initialize($);

# ----------------------------- patch ---------------------------------------
# NAME
#   patch
#
# DESCRIPTION
#   Performs the entire patching process, consisting of:
#     * Determine current state if needed (-force not specified)
#     * Add patches to installation queue
#     * Install patches (using catcon)
#     * Validate the resulting logfiles for non-ignorable errors
#
# ARGUMENTS
#   None.  All parameters should have been set by initialize().
#
# RETURNS
#   0 for success, 1 for prereq failure, 2 for non-ignorable error during
#   patch installation.
sub patch();

# ---------------------------- finalize --------------------------------------
# NAME
#   finalize
#
# DESCRIPTION
#
#   Cleans up from patching, including closing the database connection.
#
# ARGUMENTS
#   None
#
# RETURNS
#   None
sub finalize();

# 19547370: Logging levels
use constant LOG_DEBUG => 1;
use constant LOG_INVOCATION => 2;
use constant LOG_VERBOSE => 3;
use constant LOG_ALWAYS => 4;

# --------------------------- log --------------------------------------------
# NAME
#   log
#
# DESCRIPTION
#
#   Prints to either the screen or invocation log, or both
#
# ARGUMENTS
#   $level: One of the LOG_* constants:
#     LOG_DEBUG:      Print to stdout and invocation log only if $debug
#                     is true
#     LOG_INVOCATION: Print to invocation log always, also to stdout if
#                     $debug is true
#     LOG_VERBOSE:    Print to invocation log always, also to stdout if
#                     $verbose is true
#     LOG_ALWAYS:     Print to invocation log and stdout always
#   $message: String to print
#
# RETURNS
#   None
sub sqlpatch_log($$);


# ----------------------------- usage ---------------------------------------
# NAME
#   usage
#
# DESCRIPTION
#
#   Prints the usage (via sqlpatch.pl) to the screen and invocation log
#
# ARGUMENTS
#   None
#
# RETURNS
#   None
sub usage();

####################################################################
#                       PRIVATE DECLARATIONS                       #
####################################################################

# Configuration variables (as passed by user)
my @apply_list = ();       # User specified list of patches to apply
my @rollback_list = ();    # User specified list of patches to roll back
my $force = 0;             # Apply or rollback even if already installed
my $prereq_only = 0;       # Run prereq checks only, do not install
my $verbose;               # Output extra information
my $debug;                 # Even more debugging information
my $bundle_series;         # 18092561: Bundle series for patch
my $dbh;                   # Main database connection handle
my @user_ignorable_errors; # 17981677: User specified ignorable errors
my $database_name;         # Database name, used to generate unique log files
my $user_oh = undef;       # 17898119: User specified oracle_home
my $upgrade_mode_only;     # patches that require upgrade mode
my $container_db=1;        # global variable for checking container database
my $full_bootstrap;        # 17277459: Call bootstrap before patching
my @pdb_list = ();         # Array of PDBs to be processed
my $version_only = 0;      # Output version info and exit
 
# Other useful package global variables
my $work_to_do = 0;        # True if there are any patches to install
my $oracle_home;           # Value of ORACLE_HOME
my $oracle_base;           # Value of ORACLE_BASE
my $lockhandle;            # 14643995: User lock handle
my $catcon_ok = 1;         # 19501299: True if last caton call was successful
my $connected_ok;          # 19520602: True if we successfully connected to DB
my $catcon_init = 0;       # 19547370: True if catconInit was successful
my $global_failure = 0;    # True if initialize() or patch() was unsuccessful

# 19547370: invocation log variables
my $invocation_logdir;     # Unique directory for this invocation
my $invocation_handle;     # File handle
my $invocation_timestamp;  # Timestamp of invocation
my $invocation_log;        # Full path to log file
my $invocation_log_ok = 0; # True when invocation log is ready
my @invocation_log_stored; # Array of printed messages before log is ready

# Build version and copyright string
my $build_version = "12.1.0.2.0";
my $copyright = "Copyright (c) 2015, Oracle.  All rights reserved.";

# 17981677: PSU and EXA bundle patches have a known set of ignorable errors
# for which we need to check.  In addition, the user may specify a set of
# ignorable errors on the command line.
# If the user specifies an ignorable error list (stored in
# @user_ignorable_errors) then this list will be used for all patches to be
# installed.  If the user does not specify an ignorable error list, then
# any PSU or EXA bundles will use the list specified by @psu_ignorable_errors.
# Both of these are in addition to any ignorable errors in the SQL files
# themselves, which are checked for all patches.
my @psu_ignorable_errors = ("ORA-29809", "ORA-29931", "ORA-29830", "ORA-00942",
                            "ORA-00955", "ORA-01430", "ORA-01432", "ORA-01434",
                            "ORA-01435", "ORA-01917", "ORA-01920", "ORA-01921",
                            "ORA-01952", "ORA-02303", "ORA-02443", "ORA-04043",
                            "ORA-29832", "ORA-29844", "ORA-14452", "ORA-06512",
                            "ORA-01927");

# Hash of patch descriptions, indexed by (patchid/uid).  Each description is
# itself a hash reference containing the following fields:
#   $patchid: Patch id
#   $patchuid: Patch UID
#   $description: Patch description
#   $mode: "apply" or "rollback"
#   $startup_mode: "normal" or "upgrade"
#   $bundle_series: Series (i.e. PSU, WINBUNDLE) if this is a bundle patch,
#     undef if not a bundle patch
#   $bundle_id: ID for this bundle, if we can determine it
#   $jvm_patch: true if this patch updates OJVM and hence should be run first
#   $flags: patch flags (as seen in dba_registry_sqlpatch)
#   $apply_script: Full path to the apply script
#   $rollback_script: Full path to the rollback script
#   $logdir: Full path to the directory for the log file created when the 
#     install script is run
#   $prereq_ok: 1 if the patch is OK to install (i.e. the script exists)
#   $prereq_failed_reason: Reason why $prereq_ok = 0
#   $prereq_patch: 1 if this is a prereq for another bundle patch
#   @fixed_bugs: Array of bugs fixed by this patch
#   $missing_nodes: Comma separated list of nodes which do not have the
#     binary portion of the patch installed
#   $installed_binary: True if the binary portion of the patch is installed
#     (on all nodes in RAC)
#   %pdb_sql_state: Hash of the action and status for each pdb.  The key is the
#     pdb name.  If we are not in multitenant, the key will be 'undef'.
#     The value is "<action>/<status>", i.e. "APPLY/SUCCESS" or 
#     "ROLLBACK/WITH ERRORS".  If the patch is not present in the SQL registry
#     for this PDB the value will be undef.  If the patch is not present in
#     any SQL registries then the entire hash will be undef.
my %patch_descriptions;

# Array of hash refs which represent the patch queue.  Each element of the
# array represents a set of patches to be installed for a set of PDBs.  If
# the DB is not a container database, then there will be only 1 element in the
# array.  Each hash reference contains the following fields:
#   $pdbs: space separated list of PDBs.  If the DB is not a container
#      database, $pdbs will be undefined
#   $num_pdbs: Number of pdbs to be patched
#   $patch_string: Encodes the apply and rollback list using the format
#     'R: <list of rolback patches> A: <list of apply patches>
#     with each list being comma separated
#   @applys: Array of patches to be applied
#   @rollbacks: Array of patches to be rolled back
#   $<series>_candidate: Current bundle candidate patch
#   $<series>_mode: Mode of the current candidate
#   $apply_jvm: JVM patch to be applied (if any)
#   $rollback_jvm: JVM patch to be rolled back (if any)
my @patch_queue;

# Array of hash refs which represent the results of patch application.  Each
# element represents one patch application, and contains the following fields:
#  $pdb: PDB in which this patch was installed, or undefined if the DB is
#    not a container database
#  $patch: Patch which was installed
#  $mode: "apply" or "rollback"
#  $logfile: Full path to the logfile
#  @error_lines: Line numbers in the log file of errors
#  @errors: Actual error strings.  $errors[$i] occurred at
#    line $error_lines[$i].  If there are no errors, @error_lines and @errors
#    will be undefined.
#  $generate_logfile: Full path to the catbundle generate logfile,
#    undef if not a bundle patch
#  @generate_error_lines, @generate_errors: Same as error_lines and errors
#    for the generate logfile
#  $catbundle_logfile: Full patch to the catbundle apply or rollback logfile,
#    undef if not a bundle patch
#  @catbundle_error_lines, @catbundle_errors: Same as error_lines and errors
#    for the apply or rollback logfile
#  $status: "SUCCESS", "WITH ERRORS", "BEGIN"
my @patch_results;

# Hash of hash refs with information about the pluggable databases to be
# patched.  The key is the PDB name, with a hash ref containing the following
# fields.  If the DB is not a container database, there will be one entry
# with an undefined key.
#  $startup_mode: "NORMAL", "UPGRADE", "MIGRATE"
#  $bootstrap_log: Full path to log of the bootstrap operation
#  $bundle_<series>: ID installed for this series
my %pdb_info;

# 17277459 & 20099675:
# Hash of hash refs with information about all bundle series in play.  The key
# is the bundle series name, with a hash ref containing the following fields.
#   $binary_id: ID installed in binary
#   $binary_key: patch key for the binary patch
#   $missing_nodes: Nodes which are missing either the binary or SQL key
my %all_series;

# 19189525: Version to be compared with dbms_sqlpatch version
my $DBMS_SQLPATCH_VERSION = 1;

# -------------------------------- initialize --------------------------------
# NAME
#   initialize
#
# DESCRIPTION
#   Initializes the sqlpatch package with the user specified parameters,
#   passed via a hash.  All parameters are passed as a string, and are
#   optional.
#
# ARGUMENTS
#   $dbh: database handle, already connected as SYS
#   $params_ref: Reference to a hash of parameters.  The valid parameters are:
#     apply: Comma separated list of either patch ids or patchid/uid pairs
#            which represents the list of patches to apply
#     rollback: Comma separated list of either patch ids or patchid/uid pairs
#            which represents the list of patches to rollback
#     force: If true the patches will be applied or rolled back regardless of
#            the current state
#     prereq: If true, run the prereq checks only and do not install
#     pdbs: Comma separated list of PDBs to consider
#     oh: User specified oracle_home to locate install scripts
#     verbose: If true, output additional information
#     debug: If true, output even more debugging information
#     bundle_series: Bundle series for patch (or NONE), used with -force
#     ignorable_errors: Comma separated list of ignorable errors
#
# RETURNS
#   0 for success, 1 for prereq failure with the arguments
sub initialize($) {
  my $params_ref = @_[0];
  my $ret = 0;

  # We need $debug and $verbose first
  $verbose = defined($params_ref->{"verbose"}) ? 1 : 0;
  $debug = $params_ref->{"debug"};

  # If -debug is specified, turn on verbose too
  if ($debug) {
    $verbose = 1;
  }

  $version_only = defined($params_ref->{"version"}) ? 1 : 0;

  sqlpatch_log(LOG_ALWAYS, 
    "SQL Patching tool version $build_version on " . (localtime) . "\n");
  sqlpatch_log(LOG_ALWAYS, "$copyright\n\n");

  if ($version_only) {
    goto initialize_complete;
  }

  sqlpatch_log(LOG_DEBUG, "initialize entry\n");
  sqlpatch_log(LOG_DEBUG,
               "params_ref: " . Data::Dumper->Dumper(\$params_ref) . "\n");

  # 19547370: Establish the value of $oracle_home and $oracle_base first
  # so we can start the invocation log.
  if (defined($ENV{ORACLE_HOME})) {
    $oracle_home = $ENV{ORACLE_HOME};
  }
  else {
    $oracle_home = $ENV{SQLPATCH_ORACLE_HOME};
  }

  # 17354355: Log directory should be under $ORACLE_BASE rather than
  # $ORACLE_HOME if it is defined.  We can use the orabase executable to
  # determine the value of $ORACLE_BASE.  If $ORACLE_BASE is not defined
  # then orabase will return the value of $ORACLE_HOME instead.
  my $orabase = File::Spec->catfile($oracle_home, "bin", "orabase");
  $oracle_base = `$orabase`;
  chomp($oracle_base);  # Need to remove the newline from running orabase

  if ((! -d $oracle_base) || ($oracle_base eq ' ')){
    $oracle_base = $oracle_home;
  }

  $invocation_timestamp = strftime("%Y_%m_%d_%H_%M_%S", localtime);

  $invocation_logdir =
    File::Spec->catdir($oracle_base, "cfgtoollogs", "sqlpatch",
                      "sqlpatch_" . $$ . "_" . $invocation_timestamp);

  # Create directory if needed
  unless (-e $invocation_logdir) {
    sqlpatch_log(LOG_DEBUG, "Creating invocation log dir $invocation_logdir\n");

    if (!make_path($invocation_logdir)) {
      # Could not create directory
      print "Could not create invocation log directory $invocation_logdir\n";
      $ret = 1;
      goto initialize_complete;
    }
  }

  $invocation_log =
    File::Spec->catfile($invocation_logdir, "sqlpatch_invocation.log");

  # Log invocation to history log
  my $history_file =
    File::Spec->catfile($oracle_base, "cfgtoollogs", "sqlpatch",
                        "sqlpatch_history.txt");
  my $history_handle;
  open($history_handle, ">>", $history_file);
  print $history_handle
        "sqlpatch invocation with log directory $invocation_logdir\n\n";
  close($history_handle);

  # 19547370: We want to redirect STDERR to the invocation log also (two
  # handles to the same file).  So we first open a dummy handle, close it,
  # then we can open two handles with append mode.
  my $dummy_handle;
  open($dummy_handle, ">", $invocation_log);
  close($dummy_handle);
  open($invocation_handle, ">>", $invocation_log);
  select $invocation_handle;
  $| = 1;

  # Save original stderr first
  open(SAVED_STDERR, ">&STDERR");

  open(STDERR, ">>", $invocation_log);
  select STDERR;
  $| = 1;

  select STDOUT;

  $invocation_log_ok = 1;

  sqlpatch_log(LOG_VERBOSE,
               "Log file for this invocation: $invocation_log\n\n");

  # Copy parameters from hash to our storage and print to invocation log
  sqlpatch_log(LOG_INVOCATION, "SQL Patching arguments:\n");
  sqlpatch_log(LOG_DEBUG, "  debug: $debug\n");
  sqlpatch_log(LOG_INVOCATION, "  verbose: $verbose\n");

  if (defined($params_ref->{"apply"})) {
    @apply_list = split(/,/, $params_ref->{"apply"});
    sqlpatch_log(LOG_INVOCATION, "  apply: " . $params_ref->{"apply"} . "\n");
  }

  if (defined($params_ref->{"rollback"})) {
    @rollback_list = split(/,/, $params_ref->{"rollback"});
    sqlpatch_log(LOG_INVOCATION, "  rollback: " .
                 $params_ref->{"rollback"} . "\n");
  }

  $force = defined($params_ref->{"force"}) ? 1 : 0;
  sqlpatch_log(LOG_INVOCATION, "  force: $force\n");

  $prereq_only = defined($params_ref->{"prereq"}) ? 1 : 0;
  sqlpatch_log(LOG_INVOCATION, "  prereq: $prereq_only\n");

  $upgrade_mode_only = $params_ref->{"upgrade_mode_only"};
  sqlpatch_log(LOG_INVOCATION, "  upgrade_mode_only: $upgrade_mode_only\n");

  $user_oh = $params_ref->{"oh"};
  sqlpatch_log(LOG_INVOCATION, "  oh: $user_oh\n");

  $bundle_series = $params_ref->{"bundle_series"};
  sqlpatch_log(LOG_INVOCATION, "  bundle_series: $bundle_series\n");

  @user_ignorable_errors = split(',', $params_ref->{"ignorable_errors"});
  sqlpatch_log(LOG_INVOCATION, "  ignorable_errors: " . 
               $params_ref->{"ignorable_errors"} . "\n");

  $full_bootstrap = $params_ref->{"bootstrap"};
  sqlpatch_log(LOG_INVOCATION, "  bootstrap: $full_bootstrap\n");

  # 19189317: Strip single and double quotes from -pdbs
  my $stripped_pdbs = $params_ref->{"pdbs"};
  sqlpatch_log(LOG_INVOCATION, "  pdbs: $stripped_pdbs\n");

  $stripped_pdbs =~ s/\'//g;
  $stripped_pdbs =~ s/\"//g;
  my @user_pdbs = split(',', $stripped_pdbs);

  sqlpatch_log(LOG_INVOCATION, "\n");

  sqlpatch_log(LOG_DEBUG, "user_pdbs: @user_pdbs\n");

  # 17277459: Connect to database within initialize so the database handle
  # does not need to be passed.
  sqlpatch_log(LOG_ALWAYS, "Connecting to database...");
  $dbh = DBI->connect("dbi:Oracle:", "", "",
                      { RaiseError => 0,
                        PrintError => 0,
                        AutoCommit => 1,
                        ora_session_mode => DBD::Oracle::ORA_SYSDBA });
  if (!$dbh) {
    sqlpatch_log(LOG_ALWAYS, "Database connect failed with:\n");
    sqlpatch_log(LOG_ALWAYS, "$DBI::errstr\n");
    $connected_ok = 0;
    $ret = 1;
    goto initialize_complete;
  }
  else {
    $dbh->{RaiseError} = 1;
    $connected_ok = 1;
    sqlpatch_log(LOG_ALWAYS, "OK\n");
  }

  # Set up for oracle scripts
  my $script_handle = 
    $dbh->prepare("ALTER SESSION SET \"_oracle_script\" = TRUE");
  $script_handle->execute;

  # 18092561: If -bundle_series is specified, then -force must also be
  # specified and we can be installing (applying or rolling back) exactly one
  # patch specified with -apply or -rollback.
  if (defined($bundle_series)) {
    if (!$force) {
      sqlpatch_log(LOG_ALWAYS,
        "-force must be specified when -bundle_series is specified\n");
      $ret = 1;
      goto initialize_complete;
    }

    # $#<array> is the index of the next element, so a value of -1 indicates an
    # empty array and a value of 0 indicates an array of 1 element.  Hence the
    # total should be -1 to check that there is exactly 1 element total in
    # both.
    if (($#apply_list + $#rollback_list) != -1) {
      sqlpatch_log(LOG_ALWAYS,
        "Exactly one patch must be specified to be installed (via -apply\n");
      sqlpatch_log(LOG_ALWAYS,
        "or -rollback) when -bundle_series is specified\n");
      $ret = 1;
      goto initialize_complete;
    }
  }

  # 14643995: Get lock to ensure that only one datapatch session is active
  # at a time.  First request the lock with a timeout of 1 second.
  my $lock_request_sql =
    "DECLARE
       lockhandle VARCHAR2(128);
     BEGIN
       dbms_lock.allocate_unique(\'sqlpatch_lock\', lockhandle);
       ? := lockhandle;
       ? := dbms_lock.request(lockhandle, dbms_lock.x_mode, 1, false);
     END;";
  my $request_ret;
  my $lock_request_stmt = $dbh->prepare($lock_request_sql);
  $lock_request_stmt->bind_param_inout(1, \$lockhandle, 128);
  $lock_request_stmt->bind_param_inout(2, \$request_ret, 128);
  $lock_request_stmt->execute;

  # If the return value is 1 then we timed out.  In that case, print a
  # message and wait until it's released.
  if ($request_ret eq 1) {
    sqlpatch_log(LOG_ALWAYS,
      "Another datapatch session is currently running.\n");
    sqlpatch_log(LOG_ALWAYS,
      "Waiting for that session to complete before continuing...\n");
    
    $lock_request_sql =
      "BEGIN
         ? := dbms_lock.request(?, dbms_lock.x_mode, dbms_lock.maxwait, false);
       END;";
    $lock_request_stmt = $dbh->prepare($lock_request_sql);
    $lock_request_stmt->bind_param(1, $request_ret);
    $lock_request_stmt->bind_param(2, $lockhandle);
    $lock_request_stmt->execute;
  }


  # 14563601: Determine database name for the log file.
  # 17777061: Also determine if we are in a container database.
  my $c_db;
  my $namequery = "SELECT cdb, name FROM v\$database";
  my $nameh = $dbh->prepare($namequery);
  $nameh->execute;
  $nameh->bind_columns(\$c_db, \$database_name);
  $nameh->fetch;

  if ($c_db eq "NO") {
    $container_db = 0;
  }

  if ((!$container_db ) && @user_pdbs) {
    sqlpatch_log(LOG_ALWAYS,
    "\nError: -pdbs specified but $database_name is not a container database\n");
    $ret = 1;
    goto initialize_complete;

  }

  if ($container_db) {
    sqlpatch_log(LOG_DEBUG, "container database!\n");

    sqlpatch_log(LOG_ALWAYS,
      "Note:  Datapatch will only apply or rollback SQL fixes for PDBs
       that are in an open state, no patches will be applied to closed PDBs.
       Please refer to Note: Datapatch: Database 12c Post Patch SQL Automation
       (Doc ID 1585822.1)");
    sqlpatch_log(LOG_ALWAYS, "\n");

    # Determine the pluggable databases that we are going to process
    # 15873839: Restrict to PDBs which are open read write and the seed
    # 17777061: Subject to the passed in list
    # 17277459: Switch to root first
    my $alter_handle =
      $dbh->prepare("ALTER SESSION SET CONTAINER = CDB\$ROOT");
    $alter_handle->execute();

    my $container_query;
    if (@user_pdbs) {
      $container_query =
        "SELECT name,open_mode
           FROM v\$containers
           WHERE (name = 'PDB\$SEED' OR open_mode IN ('READ WRITE', 'MIGRATE' ) )
             AND name IN ('" . join("','" , @user_pdbs) . "')
           ORDER BY con_id";
    }
    else {
      $container_query =
        "SELECT name,open_mode
           FROM v\$containers
           WHERE (name = 'PDB\$SEED' OR open_mode IN ( 'READ WRITE','MIGRATE' ) )
           ORDER BY con_id";
    }

    sqlpatch_log(LOG_DEBUG, "container query: $container_query\n");

    my $container_stmt = $dbh->prepare($container_query);
    $container_stmt->execute();

    my $rows_found=0;

    while (my ($name, $open_mode) =
           $container_stmt->fetchrow_array()) {
      $rows_found=1;
      sqlpatch_log(LOG_DEBUG, "sql row: $name $open_mode \n");

      my $info = {};
      $info->{"pdb_name"} = $name;
      $info->{"startup_mode"} = $open_mode;
      $info->{"bootstrap_log"} = undef;
      $pdb_info{$name} = $info;
      push(@pdb_list, $name);
    }

    sqlpatch_log(LOG_DEBUG, " container database ! \n");

    if (!$rows_found) {
      sqlpatch_log(LOG_ALWAYS, "\nNo PDBs (subject to -pdbs parameter) are open, exiting\n");
      $ret = 1;
      goto initialize_complete;
    }
  }
  else
  {
    sqlpatch_log(LOG_DEBUG, "not container database!\n");

    my $sid=$ENV{ORACLE_SID};
    my $startup_mode;

    my $statusquery = "SELECT status FROM v\$instance where INSTANCE_NAME='$sid'";
    my $statush = $dbh->prepare($statusquery);
    $statush->execute;
    $statush->bind_columns(\$startup_mode);
    $statush->fetch;

    my $info = {};
    $info->{"pdb_name"} = undef;
    $info->{"startup_mode"} = $startup_mode;
    $info->{"bootstrap_log"} = undef;

    $pdb_info{undef} = $info;
    push(@pdb_list, undef);
  }

  sqlpatch_log(LOG_DEBUG, "printing pdbs data\n");
  sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\%pdb_info));
  sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\@pdb_list));

  # 19189525: Setup catcon once here
  # catcon init parameters
  my $catcon_user = 0;            # connect string to run scripts (/ as sysdba)
  my $catcon_internal_user = 0;        # connect string for internal statements
  my $catcon_srcdir = 0;                    # directory for source scripts
  my $catcon_logdir = $invocation_logdir;   # directory for logs
  my $catcon_logbase = "sqlpatch_catcon_";  # logfile base string
  my $catcon_pdbs_to_include;               # PDBs to use
  my $catcon_pdbs_to_exclude = "";          # PDBs to skip
  my $catcon_num_processes = 4;             # number of processes to use
  my $catcon_parallel_degree = undef;       # parallel degree
  my $catcon_echo = 0;                      # set echo on?
  my $catcon_spool = 0;                     # spool?
  my $catcon_argdelim = 0;                  # argument delimeter
  my $catcon_secret_argdelim = 0;           # ssshhhh
  my $catcon_error_logging = 0;             # turn on errorlogging?
  my $catcon_error_logging_id = 0;          # errorlogging ID
  my @catcon_init_statements = ();          # per-process init statements
  my @catcon_end_statements = ();           # per-process final statements
  my $catcon_readwrite_mode = 1;            # Set seed to READ WRITE
  my $catcon_debug = $debug;                # catcon debugging
  my $catcon_gui = 0;                       # Called from cdb_sqlexec
  my $catcon_userscript = 0;                # Running user supplied scripts?

  $catcon_pdbs_to_include = join(' ', @pdb_list);

  # 19501299: Check return codes from catcon
  my $catcon_ret =
    catcon::catconInit($catcon_user, $catcon_internal_user, $catcon_srcdir,
                       $catcon_logdir, $catcon_logbase,
                       $catcon_pdbs_to_include, $catcon_pdbs_to_exclude,
                       $catcon_num_processes, $catcon_parallel_degree,
                       $catcon_echo, $catcon_spool, $catcon_argdelim,
                       $catcon_secret_argdelim, $catcon_error_logging,
                       $catcon_error_logging_id, @catcon_init_statements,
                       @catcon_end_statements, $catcon_readwrite_mode,
                       $catcon_debug, $catcon_gui,0);

  if ($catcon_ret) {
    sqlpatch_log(LOG_ALWAYS, "\ncatconInit failed, exiting\n");
    $catcon_ok = 0;
    $ret = 1;
    goto initialize_complete;
  }

  $catcon_init = 1;

 initialize_complete:
  sqlpatch_log(LOG_DEBUG, "initialize complete, final configuration:\n");
  sqlpatch_log(LOG_DEBUG, "  pdb_list: @pdb_list\n");
  sqlpatch_log(LOG_DEBUG, "  apply_list: @apply_list\n");
  sqlpatch_log(LOG_DEBUG, "  rollback_list: @rollback_list\n");
  sqlpatch_log(LOG_DEBUG, "  upgrade_mode_only: $upgrade_mode_only\n");
  sqlpatch_log(LOG_DEBUG, "  force: $force\n");
  sqlpatch_log(LOG_DEBUG, "  prereq_only: $prereq_only\n");
  sqlpatch_log(LOG_DEBUG, "  user_oh: $user_oh\n");
  sqlpatch_log(LOG_DEBUG, "  bundle_series: $bundle_series\n");
  sqlpatch_log(LOG_DEBUG, "  verbose: $verbose\n");
  sqlpatch_log(LOG_DEBUG, "  debug: $debug\n");
  sqlpatch_log(LOG_DEBUG, "  database name: $database_name\n");

  if ($ret) {
    $global_failure = 1;
  }

  return $ret;
}


# ----------------------------- patch ---------------------------------------
# NAME
#   patch
#
# DESCRIPTION
#   Performs the entire patching process, consisting of:
#     * Determine current state if needed (-force not specified)
#     * Add patches to installation queue
#     * Install patches (using catcon)
#     * Validate the resulting logfiles for non-ignorable errors
#
# ARGUMENTS
#   None.  All parameters should have been set by initialize().
#
# RETURNS
#   0 for success, 1 for prereq failure, 2 for non-ignorable error during
#   patch installation.
sub patch() {
  my $ret = 0;
  my $prereq_failed = 0;
  my $total_patches = 0;

  if ($version_only) {
    goto patch_complete;  # Nothing to do
  }

  # 19051526: Verify that general prereqs are met
  if ($prereq_failed = check_global_prereqs()) {
    goto patch_complete;
  }


  # 18537739: If -rollback all is specified we need to determine the rollback
  # list based on the current state
  if (@rollback_list[0] eq "all") {
    @rollback_list = applied_patches();
  }

  # First we need to get the current state into the patch descriptions
  if ($prereq_failed = get_current_patches()) {
    goto patch_complete;
  }

  # Now determine the patch queue
  if ($prereq_failed = add_to_queue()) {
    goto patch_complete;
  }

  if ($prereq_only) {
    goto patch_complete;
  }

  # $work_to_do was set by add_to_queue()
  if ($work_to_do) {
    # Go for it!
    $total_patches = install_patches();

    if (!$catcon_ok) {
      # 19501299: catcon failed at some point during patch installation,
      # exit immediately without validating logfiles.
      $ret = 1;
      goto patch_complete;
    }

    $ret = validate_logfiles();
  }

  patch_complete:
  if ($prereq_failed) {
    report_prereq_errors();
    sqlpatch_log(LOG_ALWAYS,
      "Prereq check failed, exiting without installing any patches.\n");
    $ret = 1;
  }

  if ($ret) {
    $global_failure = 1;
  }

  return $ret;

}

# ---------------------------- finalize --------------------------------------
# NAME
#   finalize
#
# DESCRIPTION
#
#   Cleans up from patching, including closing the database connection.
#
# ARGUMENTS
#   None
#
# RETURNS
#   None
sub finalize() {

  sqlpatch_log(LOG_DEBUG, "finalize entry\n");

  # 14643995: Release lock.  If for some reason this fails, it will be released
  # when the session ends.
  # 19520602: Only if we successfully connected in the first place
  if ($connected_ok) {
    my $lock_release_sql =
      "DECLARE
         ret NUMBER;
       BEGIN
         ret := dbms_lock.release(?);
       END;";
    my $lock_release_stmt = $dbh->prepare($lock_release_sql);
    $lock_release_stmt->bind_param(1, $lockhandle);
    $lock_release_stmt->execute;

    $dbh->disconnect();

    # 19189525: Close catcon
    # 19501299: Only if the last catcon operation was successful.
    if ($catcon_init && $catcon_ok) {
      catcon::catconWrapUp();
    }
  }

  if ($global_failure) {
    # 17974971: Print a message pointing the user to the support note explaing
    # what to do
    sqlpatch_log(LOG_ALWAYS,
      "\nPlease refer to MOS Note 1609718.1 and/or the invocation log\n");
    sqlpatch_log(LOG_ALWAYS, $invocation_log);
    sqlpatch_log(LOG_ALWAYS,
                 "\nfor information on how to resolve the above errors.\n\n");
  }

  sqlpatch_log(LOG_ALWAYS,
               "SQL Patching tool complete on " . (localtime) . "\n");

  if (!$version_only && defined($invocation_handle)) {
    # 19547370: Close invocation log
    close($invocation_handle);

    # 19547370: Restore original stderr
    close(STDERR);
    open(STDERR, ">&SAVED_STDERR");
  }
}


# --------------------------- log --------------------------------------------
# NAME
#   log
#
# DESCRIPTION
#
#   Prints to either the screen or invocation log, or both
#
# ARGUMENTS
#   $level: One of the LOG_* constants:
#     LOG_DEBUG:      Print to stdout and invocation log only if $debug
#                     is true
#     LOG_INVOCATION: Print to invocation log always, also to stdout if
#                     $debug is true
#     LOG_VERBOSE:    Print to invocation log always, also to stdout if
#                     $verbose is true
#     LOG_ALWAYS:     Print to invocation log and stdout always
#   $message: String to print
#
# RETURNS
#   None
sub sqlpatch_log($$) {
  my ($level, $message) = @_;

  # Print to stdout if needed
  if (($level == LOG_ALWAYS) ||
      ($level == LOG_VERBOSE && $verbose) ||
      ($level == LOG_INVOCATION && $debug) ||
      ($level == LOG_DEBUG && $debug)) {
    print $message;
  }

  # Print to invocation log (or @invocation_log_stored)
  if (($level == LOG_ALWAYS) ||
      ($level == LOG_VERBOSE) ||
      ($level == LOG_INVOCATION) ||
      ($level == LOG_DEBUG && $debug)) {

    if ($invocation_log_ok) {
      # Check if this is the first call with the log set up
      if ($#invocation_log_stored != -1) {
        foreach my $msg (@invocation_log_stored) {
          print $invocation_handle $msg;
        }
        @invocation_log_stored = ();
      }
      print $invocation_handle $message;
    }
    else {
      push(@invocation_log_stored, $message);
    }
  }
}


# -------------------------- get_current_patches ----------------------------
# NAME
#   get_current_patches
#
# DESCRIPTION
#   Loads the %patch_descriptions hash with all the information about the
#   currently installed patches, both SQL and binary state.  The SQL state is
#   determined by querying the SQL registry table dba_registry_sqlpatch.
#   The binary state is determined (if $force is not set) by queryable
#   inventory.
#
# ARGUMENTS
#   None
#
# RETURNS
#   0 for success, 1 for prereq failure
sub get_current_patches() {
  my $ret = 0;

  sqlpatch_log(LOG_ALWAYS, "Determining current state...");
  sqlpatch_log(LOG_DEBUG, "\n");

  # If -force is specified, we need to get the state based on the supplied
  # apply and rollback lists only, without consulting queryable inventory.
  if ($force) {
    foreach my $apply_patch (@apply_list) {
      my $description = {};
      $description->{"prereq_ok"} = 1;
      $description->{"flags"} = "N";  # Assume normal patch

      if ($apply_patch =~ /(\d+)\/(\d+)/) {
        # User specified both patch id and UID, so we're good
        $description->{"patchid"} = $1;
        $description->{"patchuid"} = $2;
      }
      else {
        $description->{"patchid"} = $apply_patch;
        # We need to determine the uid by looking for the install directory
        # 17898119: Use the user specified -oh if needed.  Note that we only
        # use -oh for the location of the install script, not the log
        # directory.
        my $patchdir;
        if ($user_oh ne "") {
          $patchdir = File::Spec->catdir($user_oh, "sqlpatch",
                                         $description->{"patchid"});
        }
        else {
          $patchdir = File::Spec->catdir($oracle_home, "sqlpatch",
                                         $description->{"patchid"});
        }

        # If there is not exactly 1 subdirectory here then we can't determine
        # the UID and need to return an error
        opendir (PATCHDIR, $patchdir);
        my @subdirs;
        foreach my $dir (readdir(PATCHDIR)) {

          if (($dir !~ /^\./) && (-d File::Spec->catfile($patchdir, $dir))) {
            push(@subdirs, $dir);
          }
        }
        close (PATCHDIR);

        sqlpatch_log(LOG_DEBUG, 
          "found subdirs @subdirs for patch id $apply_patch\n");

        if ($#subdirs != 0) {
          # More than 1 subdirectory, so we can't determine the UID.
          # Mark as prereq failed so we will fail.
          $description->{"prereq_ok"} = 0;
          $description->{"prereq_failed_reason"} =
            "Could not determine unique patch ID for patch " .
            $description->{"patchid"} . " due to more than one subdirectory " .
            "under $patchdir";
          $ret = 1;
        }
        else {
          $description->{"patchuid"} = @subdirs[0];
        }
      }

      # We've now determined the patch ID and patch UID, determine the
      # rest of the patch properties
      if (defined($bundle_series)) {
        if ($bundle_series eq "NONE") {
          $description->{"bundle_series"} = undef;
        }
        else {
          $description->{"bundle_series"} = $bundle_series;
          $all_series{$bundle_series} = {};
          $description->{"flags"} .= "B";
        }
      }
      else {
        $description->{"bundle_series"} = undef;
      }

      $description->{"mode"} = "apply";
      $patch_descriptions{$description->{"patchid"} . "/" . $description->{"patchuid"}} = $description;

    }

    foreach my $rollback_patch (@rollback_list) {
      sqlpatch_log(LOG_DEBUG, "Checking rollback patch $rollback_patch\n");

      my $description = {};
      my $patch_ref;
      $description->{"prereq_ok"} = 1;
      $description->{"flags"} = "N";  # Assume normal patch

      if ($rollback_patch =~ /(\d+)\/(\d+)/) {
        # User specified both patch id and UID, so we're good
        $description->{"patchid"} = $1;
        $description->{"patchuid"} = $2;

        # Query the SQL registry for the rest of the patch properties.
        # This is the same query that we use to get the list of SQL patches
        # except we know the patch id and UID so we just want the properties.
        my $patches_query =
          "SELECT *
             FROM (SELECT patch_id, patch_uid, flags, action, status,
                          description, bundle_series,
                          RANK() OVER (PARTITION BY patch_id, patch_uid
                                       ORDER BY action_time DESC) r
                     FROM dba_registry_sqlpatch
                     WHERE version =
                       (SELECT substr(version, 1, instr(version, '.', 1, 4) - 1)
                          FROM v\$instance)
                       AND patch_id = " . $description->{"patchid"} . "
                       AND patch_uid = " . $description->{"patchuid"} . ")
         WHERE r = 1
         ORDER BY patch_id";
        my $patches_stmt = $dbh->prepare($patches_query);
        $patches_stmt->execute;
        $patch_ref = $patches_stmt->fetchrow_hashref;
      }
      else {
        $description->{"patchid"} = $rollback_patch;

        # Determine the patch UID by querying the SQL registry.
        # This is the same query that we use to get the list of SQL patches
        # except that just rank() over patch_id so that we will get the UID
        # for the most recent patch ID.
        # In a multitenant environment, this query will be executed against
        # the root.
        my $patches_uid_query =
          "SELECT *
             FROM (SELECT patch_id, patch_uid, flags, action, status,
                      description, bundle_series,
                   RANK() OVER (PARTITION BY patch_id
                                ORDER BY action_time DESC) r
                     FROM dba_registry_sqlpatch
                     WHERE version =
                      (SELECT substr(version, 1, instr(version, '.', 1, 4) - 1)
                       FROM v\$instance))
             WHERE r = 1
             AND ((action = 'APPLY' AND status = 'SUCCESS') OR
                  (action = 'ROLLBACK' AND status != 'SUCCESS'))
             AND patch_id = $rollback_patch";

        my $patches_uid_stmt = $dbh->prepare($patches_uid_query);
        $patches_uid_stmt->execute;
        $patch_ref = $patches_uid_stmt->fetchrow_hashref;

        sqlpatch_log(LOG_DEBUG, "sql row: ");
        sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\$patch_ref));

        $description->{"patchuid"} = 
          $patch_ref->{"PATCH_UID"};

        sqlpatch_log(LOG_DEBUG, $patches_uid_query);
        sqlpatch_log(LOG_DEBUG,
          "patch uid is " . $description->{'patchuid'} . "\n");
      }

      if (!defined($description->{"patchuid"})) {
        sqlpatch_log(LOG_DEBUG, "patchuid not defined\n");

        # The patch was not found in the SQL registry, so we can't determine
        # the UID.
        # 19520602: Before we fail with a prereq error check the install
        # directory like we do for the apply -force case.
        # 17898119: Use the user specified -oh if needed.  Note that we only
        # use -oh for the location of the install script, not the log
        # directory.
        my $patchdir;
        if ($user_oh ne "") {
          $patchdir = File::Spec->catdir($user_oh, "sqlpatch",
                                         $description->{"patchid"});
        }
        else {
          $patchdir = File::Spec->catdir($oracle_home, "sqlpatch",
                                         $description->{"patchid"});
        }

        # If there is not exactly 1 subdirectory here then we can't determine
        # the UID and need to return an error
        opendir (PATCHDIR, $patchdir);
        my @subdirs;
        foreach my $dir (readdir(PATCHDIR)) {

          if (($dir !~ /^\./) && (-d File::Spec->catfile($patchdir, $dir))) {
            push(@subdirs, $dir);
          }
        }
        close (PATCHDIR);

        sqlpatch_log(LOG_DEBUG, "found subdirs @subdirs for patch id " .
                     $description->{"patchid"} . "\n");

        if ($#subdirs != 0) {
          # More than 1 subdirectory, so we can't determine the UID.
          # Mark as prereq failed so we will fail.
          $description->{"prereq_ok"} = 0;
          $description->{"prereq_failed_reason"} =
            "Could not determine unique patch ID for patch " .
            $description->{"patchid"} . " because it is not present in the " .
              "SQL registry and there is more than one subdirectory " .
            "under $patchdir";
          $ret = 1;
        }
        else {
          $description->{"patchuid"} = @subdirs[0];
        }
      }

      # We've now determined the patch ID and patch UID, determine the
      # rest of the patch properties
      if (defined($bundle_series)) {
        if ($bundle_series eq "NONE") {
          $description->{"bundle_series"} = undef;
        }
        else {
          $description->{"bundle_series"} = $bundle_series;
          $all_series{$bundle_series} = {};
          $description->{"flags"} .= "B";
        }
      }
      else {
        # 19520602: Use SQL registry to determine the bundle series
        if (defined($patch_ref->{"BUNDLE_SERIES"})) {
          $description->{"bundle_series"} =
            $patch_ref->{"BUNDLE_SERIES"};
           $all_series{$patch_ref->{"BUNDLE_SERIES"}} = {};
          $description->{"flags"} .= "B";
        }
        else {
          $description->{"bundle_series"} = undef;
        }
      }

      $description->{"mode"} = "rollback";
      $description->{"description"} = $patch_ref->{"DESCRIPTION"};

      $patch_descriptions{$description->{"patchid"} . "/" . $description->{"patchuid"}} = $description;
    }
  }
  else {
    # -force not specified, get binary and SQL state

    sqlpatch_log(LOG_DEBUG, "get_current_patches: getting binary state\n");

    my $pending_activity;
    # Returns a list of all currently installed SQL patches for single
    # instance, and partially installed patches for RAC.  The XMLSerialize
    # ensures that each tag is on a different line.
    my $activity_sql =
      "BEGIN
         SELECT XMLSerialize(CONTENT dbms_sqlpatch.opatch_registry_state INDENT)
           INTO ?
           FROM dual;
       END;";

    my $activity_h = $dbh->prepare($activity_sql);
    $activity_h->bind_param_inout(1, \$pending_activity, 4000);

    # 19051526: Errors returned by get_pending_activity were checked for
    # already in check_global_prereqs
    $activity_h->execute;

    sqlpatch_log(LOG_DEBUG,
      "pending activity XML: " . $pending_activity . "\n");

    # 17665117: Handle uid
    my $patchid = undef;
    my $patchuid = undef;
    my $missing_nodes = undef;

    foreach my $line (split("\n", $pending_activity)) {
      sqlpatch_log(LOG_DEBUG, "l: '$line'\n");

      if ($line =~ /activityRoot/) {
        next;
      }
      elsif ($line =~ /^ *<p(\d+)>$/) {
        # Found new patch, reset UID and missing_nodes
        $patchid = $1;
        $patchuid = undef;
        $missing_nodes = undef;
      }
      elsif ($line =~ /^ *<patchUId>(\d+)<\/patchUId>$/) {
        $patchuid = $1;
      }
      elsif ($line =~ /^ *<nodeName>(.*)<\/nodeName>$/) {
        $missing_nodes = $1;
      }
      elsif ($line =~ /^ *<\/p(\d+)>$/) {
        sqlpatch_log(LOG_DEBUG,
          "Found binary patch $patchid/$patchuid, missing nodes $missing_nodes\n");

        # Found a new binary patch.  Add to the hash descriptions.
        # Since we start with the binary query we know it's not there.
        my $description = {};

        # 20348653: If the patch is missing on more than one node, then
        # there will be multiple tags in the return from get_pending_activity.
        # Check to see if it's already present in the patch descriptions, and 
        # if so just add to missing_nodes.
        if (exists($patch_descriptions{"$patchid/$patchuid"})) {
          $description = $patch_descriptions{"$patchid/$patchuid"};
          $description->{"missing_nodes"} .= "," . $missing_nodes;
        }
        else {
          $description->{"patchid"} = $patchid;
          $description->{"patchuid"} = $patchuid;
          $description->{"missing_nodes"} = $missing_nodes;
          $description->{"installed_binary"} = 1;
          $description->{"prereq_ok"} = 1;
          $description->{"flags"} = "N";  # Assume normal patch
          $description->{"pdb_sql_state"} = undef;

          # Determine description and startup mode
          my $description_mode_query =
            "SELECT description, startup_mode
               FROM XMLTable('/InventoryInstance/patches/patch[patchID=" .
                 $patchid . "]'
                    PASSING dbms_qopatch.get_opatch_lsinventory
                    COLUMNS description VARCHAR2(100) PATH 'patchDescription',
                            startup_mode VARCHAR2(7) PATH 'sqlPatchDatabaseStartupMode')";
          my $description_mode_stmt = $dbh->prepare($description_mode_query);
          $description_mode_stmt->execute();
          ($description->{"description"}, $description->{"startup_mode"}) =
            $description_mode_stmt->fetchrow_array();

          if ($description->{"startup_mode"} eq "upgrade") {
            $description->{"flags"} = "U";
          }

          # Determine bundle_series and jvm_patch status
          my $files_query =
            "SELECT filename 
               FROM XMLTable('/InventoryInstance/patches/patch[patchID=" . 
                 $patchid . "]//file'
                    PASSING dbms_qopatch.get_opatch_lsinventory
                    COLUMNS filename VARCHAR2(50) PATH '.')";

          my @patch_files = @{$dbh->selectcol_arrayref($files_query)};

          $description->{"bundle_series"} = undef;
          $description->{"jvm_patch"} = 0;

          # Loop through the file list to see if we have bundledata.xml
          for my $patch_file (@patch_files) {
            sqlpatch_log(LOG_DEBUG, 
              "Checking patch file $patch_file for bundledata.xml\n");

            if ($patch_file =~ /^bundledata_(.*)\.xml$/) {
              $description->{"bundle_series"} = $1;
              $description->{"flags"} .= "B";
              # 17277459: Add to all_series
              if (!grep(/$description->{"bundle_series"}/, keys %all_series)) {
                $all_series{$description->{"bundle_series"}} = {};
              }
              sqlpatch_log(LOG_DEBUG, "Set bundle_series to $1\n");
            }
            elsif ($patch_file eq "jvmpsu.sql") {
              # 19708632: This is a JVM patch, mark it as such
              $description->{"jvm_patch"} = 1;
              $description->{"flags"} .= "J";
              sqlpatch_log(LOG_DEBUG, "Set jvm_patch to true\n");
            }
          }

          # Add the description to the hash
          $patch_descriptions{"$patchid/$patchuid"} = $description;
        }
      }
    }

    sqlpatch_log(LOG_DEBUG,
      "Patch descriptions after getting binary patches:\n");
    sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\%patch_descriptions));


    # Second get the SQL state
    # 14623172: This nifty little query returns the most recent action and
    # status in the SQL registry for each patch.
    # 14563594: Restrict to current version
    # 17665117: Handle uid and get patch description.  If the same patch ID is
    # present in the registry but with 2 different UIDs (both applied), we will
    # return both rows, even though this situation should not occur.
    # 17277459: Get bundle series as well as all statuses
    my $patches_query = 
      "SELECT *
         FROM (SELECT patch_id, patch_uid, flags, action, status, description,
                      bundle_series,
                      RANK() OVER (PARTITION BY patch_id, patch_uid
                                   ORDER BY action_time DESC) r
                 FROM dba_registry_sqlpatch
                 WHERE version =
                   (SELECT substr(version, 1, instr(version, '.', 1, 4) - 1)
                      FROM v\$instance))
         WHERE r = 1
         ORDER BY patch_id, patch_uid";

    my $patches_stmt = $dbh->prepare($patches_query);

    # For each PDB we need to alter session to that PDB, then get the list
    # of patches
    foreach my $pdb (@pdb_list) {
 
      if ($container_db) {
        sqlpatch_log(LOG_DEBUG, "get SQL patches switching to pdb $pdb\n");

        my $alter_handle = 
          $dbh->prepare("ALTER SESSION SET CONTAINER = " . $pdb);
        $alter_handle->execute;
      }

      $patches_stmt->execute();
      while (my $patch_ref = $patches_stmt->fetchrow_hashref) {
        sqlpatch_log(LOG_DEBUG,
                     "sql row: " . Data::Dumper->Dumper(\$patch_ref));

        my $patchkey =
          $patch_ref->{"PATCH_ID"} . "/" . $patch_ref->{"PATCH_UID"};

        # 20348653: Merge properties found in the SQL registry with 
        # any existing properties found in the binary registry.
        my $description;

        # Found a new SQL patch.  Add to the hash descriptions if needed
        if (!exists($patch_descriptions{$patchkey})) {
          # Patch does not yet exist, create it first
          sqlpatch_log(LOG_DEBUG, "Found new SQL patch $patchkey\n");
          $description = {};
          $description->{"patchid"} = $patch_ref->{"PATCH_ID"};
          $description->{"patchuid"} = $patch_ref->{"PATCH_UID"};
          $description->{"installed_binary"} = 0;
          $patch_descriptions{$patchkey} = $description;
        }

        # Now set the rest of the patch properties.  This will override
        # existing properties if the patch was previously found in binary.
        # (maybe raise an error in this case?)
        $description = $patch_descriptions{$patchkey};
        $description->{"description"} = $patch_ref->{"DESCRIPTION"};
        $description->{"flags"} = $patch_ref->{"FLAGS"};
        $description->{"flags"} =~ s/F//g;  # 19521006: Strip existing F
        $description->{"prereq_ok"} = 1;

        $description->{"pdb_sql_state"}{$pdb} =
          $patch_ref->{"ACTION"} . "/" . $patch_ref->{"STATUS"};

        if ($patch_ref->{"FLAGS"} =~ /B/) {
          $description->{"bundle_series"} = $patch_ref->{"BUNDLE_SERIES"};
          # 17277459: Add to all_series
          if (!grep(/$description->{"bundle_series"}/, keys %all_series)) {
            $all_series{$description->{"bundle_series"}} = {};
          }
        }
        else {
          $description->{"bundle_series"} = undef;
        }

        if ($patch_ref->{"FLAGS"} =~ /U/) {
          $description->{"startup_mode"} = "upgrade";
        }
        else {
          $description->{"startup_mode"} = "normal";
        }

        # 19708632: Check JVM status
        if ($patch_ref->{"FLAGS"} =~ /J/) {
          $description->{"jvm_patch"} = 1;
        }
        else {
          $description->{"jvm_patch"} = 0;
        }
      }
    }

    if ($container_db) {
      # Set container back to root when we're done
      my $alter_handle =
        $dbh->prepare("ALTER SESSION SET CONTAINER = CDB\$ROOT");
      $alter_handle->execute;
    }

    sqlpatch_log(LOG_DEBUG, "Patch descriptions after getting SQL state:\n");
    sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\%patch_descriptions));
  }

  # Set additional properties in the patch descriptions now that we have loaded
  # the binary and SQL patches from either the apply and rollback lists or
  # registries.
  while ((my $key, my $description) = each(%patch_descriptions)){
    # 17898119: Use the user specified -oh if needed.  Note that we only
    # use -oh for the location of the install script, not the log
    # directory.
    my $patchdir;
    if ($user_oh ne "") {
      $patchdir = File::Spec->catdir($user_oh, "sqlpatch",
                                     $description->{"patchid"},
                                     $description->{"patchuid"});
      if ($description->{"bundle_series"}) {
        $description->{"bundledata"} =
          File::Spec->catfile($user_oh, "rdbms", "admin", 
            "bundledata_" . $description->{"bundle_series"} . ".xml");
      }
      else {
        $description->{"bundledata"} = undef;
      }
    }
    else {
      $patchdir = File::Spec->catdir($oracle_home, "sqlpatch",
                                     $description->{"patchid"},
                                     $description->{"patchuid"});
      if ($description->{"bundle_series"}) {
        $description->{"bundledata"} =
          File::Spec->catfile($oracle_home, "rdbms", "admin", 
            "bundledata_" . $description->{"bundle_series"} . ".xml");
      }
      else {
        $description->{"bundledata"} = undef;
      }
    }

    $description->{"apply_script"} =
      File::Spec->catfile($patchdir,
                          $description->{"patchid"} . "_apply.sql");
    $description->{"rollback_script"} =
      File::Spec->catfile($patchdir,
                          $description->{"patchid"} . "_rollback.sql");

    # 17354355: Log directory should be under $ORACLE_BASE rather than
    # $ORACLE_HOME if it is defined.
    $description->{"logdir"} =
      File::Spec->catdir($oracle_base, "cfgtoollogs", "sqlpatch",
                         $description->{"patchid"},
                         $description->{"patchuid"}) . "/";
  }

  sqlpatch_log(LOG_DEBUG, "Patch descriptions after additional pass:\n");
  sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\%patch_descriptions));

  # 20099675: Determine bundle ID for any bundle patches, if possible.
  # We don't have this information in the opatch metadata (yet) nor directly
  # in bundledata.xml (yet).  So we have two sources for this:
  # Previous successfull applies of bundle patches will record the ID in
  # the SQL registry.  And the highest bundle patch in the binary registry
  # will match the highest bundle ID in bundledata.xml.

  # First query the SQL registry.  This will be executed against the root
  # in a multitenant environment.
  my $bundle_id_sql =
    "SELECT UNIQUE patch_id || '/' || patch_uid, bundle_id, bundle_series
       FROM dba_registry_sqlpatch
       WHERE action = 'APPLY' AND status = 'SUCCESS'
         AND flags LIKE '%B%'";
  my $bundle_id_stmt = $dbh->prepare($bundle_id_sql);
  $bundle_id_stmt->execute;
  my $patch_key;
  my $bundle_id;
  my $bundle_series;
  $bundle_id_stmt->bind_col(1, \$patch_key);
  $bundle_id_stmt->bind_col(2, \$bundle_id, SQL_INTEGER);
  $bundle_id_stmt->bind_col(3, \$bundle_series);

  while ($bundle_id_stmt->fetch()) {
    sqlpatch_log(LOG_DEBUG,
      "Setting key_" . $bundle_id . " for $bundle_series to $patch_key\n");
    sqlpatch_log(LOG_DEBUG,
      "Setting bundle_id for $patch_key to $bundle_id\n");

    $patch_descriptions{$patch_key}->{"bundle_id"} = $bundle_id;
    $all_series{$bundle_series}->{"key_" . $bundle_id} = $patch_key;
  }

  # Now query the binary registry for each bundle series in play.  We want
  # the highest (by patch key) value so we loop in reverse order.
  foreach my $series (keys %all_series) {
    sqlpatch_log(LOG_DEBUG, 
     "Looking for binary status for series $series and setting id = 0\n");

    $all_series{$series}->{"binary_id"} = 0;
    foreach my $key (reverse sort keys %patch_descriptions) {
      my $description = $patch_descriptions{$key};
      sqlpatch_log(LOG_DEBUG, "binary_id checking key $key\n");

      if ($description->{"installed_binary"} &&
          (exists($description->{"bundle_series"}) &&
           $description->{"bundle_series"} eq $series)) {
        # 20348653: Record missing_nodes
        if (defined($description->{"missing_nodes"})) {
          sqlpatch_log(LOG_DEBUG,
                       "Setting (binary) missing_nodes for $series to " .
                       $description->{"missing_nodes"} . "\n");
          $all_series{$series}->{"missing_nodes"} =
            $description->{"missing_nodes"};
        }
        else {
          # Only look for bundledata.xml if the patch is installed on all
          # nodes
          if (exists($description->{"bundledata"}) &&
              (-e $description->{"bundledata"})) {

            sqlpatch_log(LOG_DEBUG,
                         "bundledata.xml exists for this key, parsing\n");

            # bundledata_<series>.xml exists, parse it to find the highest ID
            open (BUNDLEDATA, $patch_descriptions{$key}->{"bundledata"});

            while (my $line = <BUNDLEDATA>) {
              if ($line =~ /bundle id=\"(\d*)\"/) {
                sqlpatch_log(LOG_DEBUG,
                             "Setting (binary) bundle_id for $key to $1\n");

                $patch_descriptions{$key}->{"bundle_id"} = $1;
                $all_series{$series}->{"binary_id"} = $1;
                $all_series{$series}->{"binary_key"} = $key;
              }
            }

            close (BUNDLEDATA);

            last;
          }
        }
      }
    }
  }

  # 20099675: Query the SQL registry in each PDB for the bundle ID installed
  # This nifty little query returns the bundle series and ID installed for the
  # last successful operation.
  my $bundle_id_query =
    "SELECT patch_id || '/' || patch_uid patch_key,
            action, bundle_series, bundle_id
        FROM (SELECT patch_id, patch_uid, description, action, status,
                     bundle_series, bundle_id,
                     RANK() OVER (PARTITION BY bundle_series
                                  ORDER BY action_time DESC) r
              FROM dba_registry_sqlpatch
              WHERE version =
                (SELECT substr(version, 1, instr(version, '.', 1, 4) - 1)
                   FROM v\$instance)
              AND flags LIKE '%B%'
              AND status = 'SUCCESS')
        WHERE r = 1";
  my $bundle_id_stmt = $dbh->prepare($bundle_id_query);

  foreach my $pdb (@pdb_list) {
    sqlpatch_log(LOG_DEBUG, "Checking bundles installed in PDB $pdb\n");

    my $entry;

    if ($container_db) {
      $entry = $pdb_info{$pdb};
      sqlpatch_log(LOG_DEBUG, "get SQL patches switching to pdb $pdb\n");

      my $alter_handle = 
        $dbh->prepare("ALTER SESSION SET CONTAINER = " . $pdb);
      $alter_handle->execute;
    }
    else {
      $entry = $pdb_info{undef};
    }

    # Initialize to 0 for all series
    foreach my $series (keys %all_series) {
      $entry->{"bundle_" . $series . "_id"} = 0;
    }

    $bundle_id_stmt->execute();
    while (my ($b_key, $b_action, $b_series, $b_id) =
           $bundle_id_stmt->fetchrow_array()) {
      sqlpatch_log(LOG_DEBUG, "b_key: $b_key b_action: $b_action b_series: $b_series b_id: $b_id\n");
      $entry->{"bundle_" . $b_series . "_id"} = $b_id;
      # If the action is APPLY, then the key we've fetched is the correct
      # one for this ID.  If the action is ROLLBACK, we need to query the SQL
      # registry for the last successful apply.
      if ($b_action eq "APPLY") {
        $entry->{"bundle_" . $b_series . "_key"} = $b_key;
        $patch_descriptions{$b_key}->{"bundle_id"} = $b_id;

        # 20348653: Record missing nodes
        if (defined($patch_descriptions{$b_key}->{"missing_nodes"})) {
          sqlpatch_log(LOG_DEBUG,
                       "Setting (SQL) missing_nodes for $b_series to " .
                       $patch_descriptions{$b_key}->{"missing_nodes"} . "\n");
          $all_series{$b_series}->{"missing_nodes"} =
            $patch_descriptions{$b_key}->{"missing_nodes"};
        }
      }
      else {
        my $bundle_id_sql =
          "SELECT UNIQUE patch_id || '/' || patch_uid patch_key
             FROM dba_registry_sqlpatch
             WHERE action = 'APPLY' AND status = 'SUCCESS'
               AND bundle_id = $b_id
               AND bundle_series = '$b_series'";
        sqlpatch_log(LOG_DEBUG,
          "Looking for apply/success key for id $b_id series $b_series\n");
        my ($key) = $dbh->selectrow_array($bundle_id_sql);
        $entry->{"bundle_" . $b_series . "_key"} = $key;
        if (defined($key)) {
          $patch_descriptions{$key}->{"bundle_id"} = $b_id;

          # 20348653: Record missing nodes
          if (defined($patch_descriptions{$key}->{"missing_nodes"})) {
            sqlpatch_log(LOG_DEBUG,
                         "Setting (SQL) missing_nodes for $b_series to " .
                         $patch_descriptions{$key}->{"missing_nodes"} . "\n");
            $all_series{$b_series}->{"missing_nodes"} =
              $patch_descriptions{$key}->{"missing_nodes"};
          }
        }
      }
    }
  }
  
  if ($container_db) {
    # Set container back to root when we're done
    my $alter_handle =
      $dbh->prepare("ALTER SESSION SET CONTAINER = CDB\$ROOT");
    $alter_handle->execute;
  }

  sqlpatch_log(LOG_DEBUG, "After add_to_queue get bundle state:\n");
  sqlpatch_log(LOG_DEBUG,
               "Patch queue: " . Data::Dumper->Dumper(\@patch_queue));
  sqlpatch_log(LOG_DEBUG,
    "Patch descriptions: " . Data::Dumper->Dumper(\%patch_descriptions));
  sqlpatch_log(LOG_DEBUG, "all_series: " . Data::Dumper->Dumper(\%all_series));
  sqlpatch_log(LOG_DEBUG,
    "pdb_info: " . Data::Dumper->Dumper(\%pdb_info) . "\n");

  sqlpatch_log(LOG_ALWAYS, "done\n");

  # Print out the current state if needed
  print_current_state();

  return $ret;
}

# ------------------------- print_current_state -----------------------------
# NAME
#   print_current_state
#
# DESCRIPTION
#   Prints the current state (install status) for all patches based on the
#   patch descriptions
#
# ARGUMENTS
#   None
#
# RETURNS
#   None
sub print_current_state() {

  sqlpatch_log(LOG_VERBOSE, "\nCurrent state of SQL patches:\n");
  foreach my $key (sort keys %patch_descriptions) {
    my $description = $patch_descriptions{$key};
    sqlpatch_log(LOG_DEBUG, "Checking description $key\n");

    # 20099675: Use all_series and pdb_info to print the bundle state, so
    # we only need to print out information here for non bundle patches.
    if (!$description->{"bundle_series"}) {
      sqlpatch_log(LOG_VERBOSE, "Patch " . $description->{"patchid"} . " (" . 
        $description->{"description"} . "):\n");

      my $database_string = undef;
      my $first = 1;
      foreach my $pdb (sort keys %{$description->{"pdb_sql_state"}}) {
        if ($description->{"pdb_sql_state"}{$pdb} eq "APPLY/SUCCESS") {
          if ($pdb ne '') {
            if ($first) {
              $database_string .= $pdb;
              $first = 0;
            }
            else {
              $database_string .= " " . $pdb;
            }
          }
          else {
            $database_string .= "the SQL registry";
          }
        }
      }

      # 20348653: Display information about missing nodes
      if (defined($description->{"missing_nodes"})) {
        sqlpatch_log(LOG_VERBOSE,
          "  Not installed on nodes " . $description->{"missing_nodes"});
        if (!defined($database_string)) {
          sqlpatch_log(LOG_VERBOSE, "\n");
        }
        else {
          sqlpatch_log(LOG_VERBOSE, " and $database_string\n");
        }
      }
      else { 
        if ($description->{"installed_binary"}) {
          if (!defined($database_string)) {
            sqlpatch_log(LOG_VERBOSE,
                         "  Installed in the binary registry only\n");
          }
          else {
            sqlpatch_log(LOG_VERBOSE,
                         "  Installed in binary and $database_string\n");
          }
        }
        else {
          if (defined($database_string)) {
            sqlpatch_log(LOG_VERBOSE,
                         "  Installed in $database_string" . " only\n");
          }
          else {
            sqlpatch_log(LOG_VERBOSE,
                         "  Not installed in binary or the SQL registry\n");
          }
        }
      }
    }
  }

  # Now we can loop through all_series and print the information there
  foreach my $series (sort keys %all_series) {
    sqlpatch_log(LOG_VERBOSE, "Bundle series $series:\n");
    # 20348653: Display information about missing nodes
    if (defined($all_series{$series}->{"missing_nodes"})) {
      sqlpatch_log(LOG_VERBOSE, "  Not installed on nodes " .
                   $all_series{$series}->{"missing_nodes"} . " and ");
    }
    elsif ($all_series{$series}->{"binary_id"} eq 0) {
      sqlpatch_log(LOG_VERBOSE, "  Not installed in the binary registry and ");
    }
    else {
      sqlpatch_log(LOG_VERBOSE, "  ID " . $all_series{$series}->{"binary_id"} .
        " in the binary registry and ");
    }

    if ($container_db) {
      my $first = 1;
      my $found = 0;
      my $database_string = "";

      foreach my $pdb (@pdb_list) {
        my $sql_id = $pdb_info{$pdb}->{"bundle_" . $series . "_id"};
        if ($sql_id) {
          if ($first) {
            $first = 0;
          }
          else {
            $database_string .= ", ";
          }
          $found = 1;
          $database_string .= "ID $sql_id in PDB $pdb";
        }
      }

      if (!$found) {
        sqlpatch_log(LOG_VERBOSE, "not installed in any PDB\n");
      }
      else {
        sqlpatch_log(LOG_VERBOSE, "$database_string\n");
      }
    }
    else {
      my $sql_id = $pdb_info{undef}->{"bundle_" . $series . "_id"};
      if ($sql_id eq 0) {
        sqlpatch_log(LOG_VERBOSE, "not installed in the SQL registry\n");
      }
      else {
        sqlpatch_log(LOG_VERBOSE, "ID $sql_id in the SQL registry\n");
      }
    }
  }

  sqlpatch_log(LOG_VERBOSE, "\n");

}

# ---------------------------- add_to_queue ---------------------------------
# NAME
#   add_to_queue
#
# DESCRIPTION
#   Creates the patch queue based on the patch descriptions.
#   Also checks the final patch queue for prereqs, namly that the install 
#   script exists and the log file directory can be created.
#
# ARGUMENTS
#   None
#
# RETURNS
#   0 for success, 1 for prereq check failed
sub add_to_queue {
  my $prereq_failed = 0;

  sqlpatch_log(LOG_ALWAYS, 
    "Adding patches to installation queue and performing prereq checks...");

  sqlpatch_log(LOG_VERBOSE, "\n");

  # There are 3 steps involved in creating the queue:
  # 1) Create initial entries based on $installed_sql and $installed_binary
  # 2) Combine entries that have the same apply and rollback lists
  # 3) Check prereqs for final queue

  # Step One: Create initial queue entries
  if ($force) {
    # If -force is specified, then our job is simple.  We just need to
    # loop over the patch descriptions and add them to the apply and rollback
    # set, for all PDBs.
    my $queue_rec = {};
    if ($container_db) {
      $queue_rec->{"pdbs"} = join(' ', @pdb_list);
    }
    else {
      $queue_rec->{"pdbs"} = undef;
    }
    $queue_rec->{"applys"} = [];
    $queue_rec->{"rollbacks"} = [];
    $queue_rec->{"num_pdbs"} = 1;

    foreach my $key (sort keys %patch_descriptions) {
      if (defined($patch_descriptions{$key}->{"mode"})) {
        if ($patch_descriptions{$key}->{"mode"} eq "apply") {
          $work_to_do = 1;
          push(@{$queue_rec->{"applys"}}, $key);
        }
        else {
          $work_to_do = 1;
          push(@{$queue_rec->{"rollbacks"}}, $key);
        }
      }
    }

    push(@patch_queue, $queue_rec);

    sqlpatch_log(LOG_DEBUG, "Patch queue after force add:\n");
    sqlpatch_log(LOG_DEBUG, Data::Dumper->Dumper(\@patch_queue));

    # We don't need to do step 2 skip straight to the prereq check
    goto queue_complete;
  }

  # -force not specified.  Our job is not quite as simple.  We need to
  # loop over the patch descriptions and check $installed_binary,
  # $installed_sql, and/or @installed_pdbs to determine if the patch should
  # be applied or rolled back.

  # First setup the patch queue with 1 entry per PDB.
  foreach my $pdb (@pdb_list) {

    my $queue_rec = {};
    $queue_rec->{"pdbs"} = $pdb;
    $queue_rec->{"num_pdbs"} = 1;
    $queue_rec->{"applys"} = [];
    $queue_rec->{"rollbacks"} = [];

    push(@patch_queue, $queue_rec);
  }

  # Now loop over the patch descriptions and add if needed to the queue
  foreach my $key (sort keys %patch_descriptions) {
     sqlpatch_log(LOG_DEBUG, "add_to_queue checking key $key\n");

    my $description = $patch_descriptions{$key};

    # For each patch description, we need to determine if it should be added
    # to the apply or rollback list for each entry in the queue.

    # 17277459 & 20099675:
    # We need separate handling for bundle patches vs. non-bundled patches.
    # So we only consider non bundle patches here.
    # 20348653: Skip any patches which are partially installed (missing nodes)
    if (!$description->{"bundle_series"} &&
        !defined($description->{"missing_nodes"})) {
      # This is not a bundle patch.

      # If the following conditions are met then this patch may need to
      # be applied:
      # * The binary portion of the patch is installed
      # * 17665117: Subject to the passed in apply list if present
      # * 17665122: Subject to upgrade_mode_only
      if ($description->{"installed_binary"} &&
          (!@apply_list || grep(/$key/, @apply_list) ||
           grep(/$description->{"patchid"}/, @apply_list)) &&
          (!$upgrade_mode_only ||
           ($description->{"startup_mode"} eq "upgrade"))) {

        # This patch is an apply candidate.  We now loop over all the queue
        # entries (each of which is for a single PDB), and check:
        # * If the patch is not installed in SQL at all, or
        # * The patch is not installed in the current queue entry
        # If either of these are true, then we add the patch to the apply
        # list.
        foreach my $entry (@patch_queue) {
          my $pdb = $entry->{"pdbs"};
          if (!defined($description->{"pdb_sql_state"}) ||
              !defined($description->{"pdb_sql_state"}{$pdb}) ||
              $description->{"pdb_sql_state"}{$pdb} ne "APPLY/SUCCESS") {
            # Patch is installed in binary but not in this PDB, add to the
            # apply queue
            sqlpatch_log(LOG_DEBUG, 
              "Adding $key to patch queue apply for PDB $pdb\n");

            $description->{"mode"} = "apply";
            $work_to_do = 1;

            # 19708632: Check JVM status
            if ($description->{"jvm_patch"}) {
              $entry->{"apply_jvm"} = $key;
            }
            else {
              push($entry->{"applys"}, $key);
            }
          }
        }
      }

      # Second check for potential rollback.
      # If the following conditions are met then this patch may need to be
      # rolled back:
      # * The binary portion of the patch is not installed
      # * The SQL portion is installed (in at least one PDB)
      # * 17665117: Subject to the passed in rollback list if present
      # * 17665122: Subject to upgrade_mode_only
      if (!$description->{"installed_binary"} &&
          defined($description->{"pdb_sql_state"}) &&
          (!@rollback_list || grep(/$key/, @rollback_list) ||
           grep(/$description->{"patchid"}/, @rollback_list)) &&
          (!$upgrade_mode_only ||
           ($description->{"startup_mode"} eq "upgrade"))) {

        # This patch is a rollback candidate.  We now loop over all the queue
        # entries (each of which is a single PDB) and check if patch is
        # installed successfully for this PDB.
        foreach my $entry (@patch_queue) {
          my $pdb = $entry->{"pdbs"};
          if (defined($description->{"pdb_sql_state"}{$pdb}) &&
              $description->{"pdb_sql_state"}{$pdb} ne "ROLLBACK/SUCCESS") {
            # Patch is not installed in binary but is successfully applied
            # in this PDB.  Add to the rollback queue.
            sqlpatch_log(LOG_DEBUG, 
              "Adding $key to patch queue rollback for PDB $pdb\n");

            $description->{"mode"} = "rollback";
            $work_to_do = 1;

            # 19708632: Check JVM status
            if ($description->{"jvm_patch"}) {
              $entry->{"rollback_jvm"} = $key;
            }
            else {
              push($entry->{"rollbacks"}, $key);
            }
          }
        }
      }
    }
  }

  # 20099675: Now we need to determine the bundle candidates.  We do this
  # by comparing the bundle IDs installed in binary and in each PDB.
  foreach my $series (keys %all_series) {
    sqlpatch_log(LOG_DEBUG, "Checking candidates for series $series\n");

    # For this series, loop over the queue entries (each of which is for
    # a single PDB)
    foreach my $entry (@patch_queue) {
      my $pdb = $entry->{"pdbs"};

      my $binary_id = $all_series{$series}->{"binary_id"};
      my $binary_key = $all_series{$series}->{"binary_key"};
      my $sql_id;
      my $sql_key;
      if ($container_db) {
        $sql_id = $pdb_info{$pdb}->{"bundle_" . $series . "_id"};
        $sql_key = $pdb_info{$pdb}->{"bundle_" . $series . "_key"}
      }
      else {
        $sql_id = $pdb_info{undef}->{"bundle_" . $series . "_id"};
        $sql_key = $pdb_info{undef}->{"bundle_" . $series . "_key"}
      }

      sqlpatch_log(LOG_DEBUG,
        "Testing bundle series $series binary id $binary_id sql id $sql_id\n");
      sqlpatch_log(LOG_DEBUG,
                   "SQL id/key $sql_id $sql_key\n");

      # 20348653: Skip any patches which are partially installed
      # (missing nodes)
      if ($patch_descriptions{$binary_key}->{"missing_nodes"} ||
          $patch_descriptions{$sql_key}->{"missing_nodes"}) {
        sqlpatch_log(LOG_DEBUG, "Skipping partially installed patch\n");
        next;
      }

      if ($binary_id > $sql_id) {
        # Bundle ID is higher in binary then in SQL.  We need to apply:
        # Subject to the passed in apply list if present
        # Subject to upgrade_mode_only
        sqlpatch_log(LOG_DEBUG, "Apply candidate is $binary_key\n");

        if ((!@apply_list ||
             grep(/$binary_key/, @apply_list) ||
             grep(/$patch_descriptions{$binary_key}->{"patchid"}/, @apply_list)) &&
            ((!$upgrade_mode_only ||
              $patch_descriptions{$binary_key}->{"startup_mode"} eq "upgrade"))) {
          $entry->{$series . "_candidate"} = $binary_key;
          $entry->{$series . "_mode"} = "apply";
        }
      }
      elsif ($binary_id < $sql_id) {
        # Bundle ID is higher in SQL then in binary.  We need to rollback:
        # Subject to the passed in rollback list if present
        # 20348653: And the patch is not partially installed
        if ((!@rollback_list ||
             grep(/$sql_key/, @rollback_list) ||
             grep(/$patch_descriptions{$sql_key}->{"patch_id"}/, @rollback_list)) &&
            (!$upgrade_mode_only ||
             ($patch_descriptions{$sql_key}->{"startup_mode"} eq "upgrade"))) {
          $entry->{$series . "_candidate"} = $sql_key;
          $entry->{$series . "_mode"} = "rollback";
        }
      }
    }
  }

  sqlpatch_log(LOG_DEBUG, "After add_to_queue first pass:\n");
  sqlpatch_log(LOG_DEBUG,
    "Patch queue: " . Data::Dumper->Dumper(\@patch_queue));
  sqlpatch_log(LOG_DEBUG,
    "Patch descriptions: " . Data::Dumper->Dumper(\%patch_descriptions));
  sqlpatch_log(LOG_DEBUG, "all_series: " . Data::Dumper->Dumper(\%all_series));

  # 19708632: Put any JVM fixes first in the apply or rollback list
  # 17277459: Add bundle candidates to apply or rollback list
  foreach my $entry (@patch_queue) {
    # First put bundle candidates at the front of the list
    foreach my $series (keys %all_series) {
      my $candidate = $entry->{$series . "_candidate"};
      sqlpatch_log(LOG_DEBUG,
        "add_to_queue bundle pass checking candidate $candidate\n");

      if (defined($candidate)) {
        my $mode = $entry->{$series . "_mode"};
        $patch_descriptions{$candidate}->{"mode"} = $mode;
        if ($mode eq "apply") {
          unshift($entry->{"applys"}, $candidate);
          $work_to_do = 1;
        }
        else {
          unshift($entry->{"rollbacks"}, $candidate);
          $work_to_do = 1;
        }
      }
    }

    # Now put JVM fixes at the front of the list
    if ($entry->{"apply_jvm"}) {
      unshift($entry->{"applys"}, $entry->{"apply_jvm"});
    }
    if ($entry->{"rollback_jvm"}) {
      unshift($entry->{"rollbacks"}, $entry->{"rollback_jvm"});
    }
  }

  sqlpatch_log(LOG_DEBUG, "After add_to_queue JVM and bundle pass:\n");
  sqlpatch_log(LOG_DEBUG,
    "Patch queue: " . Data::Dumper->Dumper(\@patch_queue));
  sqlpatch_log(LOG_DEBUG,
    "Patch descriptions: " . Data::Dumper->Dumper(\%patch_descriptions));
  sqlpatch_log(LOG_DEBUG, "all_series: " . Data::Dumper->Dumper(\%all_series));

  # Step Two: Combine queue entries
  # Initial applys and rollbacks are added to the queue.  Now we need to
  # combine queue entries that have the same apply and rollback lists.
  # We also generate the patch string for each entry.  
  # We do this using a hash that tests for uniqueness.
  my %unique_patch_strings;
  for (my $queue_index = 0; $queue_index <= $#patch_queue; $queue_index++) {
    my $entry = $patch_queue[$queue_index];

    my $patch_string =
      "R:" . join(',', @{$entry->{"rollbacks"}}) .
        " A:" . join(',', @{$entry->{"applys"}});
    $entry->{"patch_string"} = $patch_string;
    # See if it's unique by adding to the hash
    if (exists($unique_patch_strings{$patch_string})) {
      # Entry already in the hash
      (@patch_queue[$unique_patch_strings{$patch_string}])->{"pdbs"} .= 
        (" " . $entry->{"pdbs"});
      (@patch_queue[$unique_patch_strings{$patch_string}])->{"escaped_pdbs"} .= 
        (" " . $entry->{"escaped_pdbs"});
      # Mark the current entry as combined so it won't be processed
      $entry->{"combined"} = 1;

      (@patch_queue[$unique_patch_strings{$patch_string}])->{"num_pdbs"} += 1;
    }
    else {
      $unique_patch_strings{$patch_string} = $queue_index;
    }
  }

 queue_complete:

  sqlpatch_log(LOG_DEBUG, "End of add_to_queue:\n");
  sqlpatch_log(LOG_DEBUG,
    "Patch queue: " . Data::Dumper->Dumper(\@patch_queue));
  sqlpatch_log(LOG_DEBUG,
    "Patch descriptions: " . Data::Dumper->Dumper(\%patch_descriptions));
  sqlpatch_log(LOG_DEBUG, "all_series: " . Data::Dumper->Dumper(\%all_series));

  if (!$debug && !$verbose) {
    sqlpatch_log(LOG_ALWAYS, "done\n");
  }

  # Step Four: The queue is complete.  Print it out and check for prereqs.
  print_queue();
  $prereq_failed = check_queue_prereqs();

  sqlpatch_log(LOG_DEBUG, "add_to_queue returning $prereq_failed\n");

  return $prereq_failed;
}


# ------------------------- report_prereq_errors -----------------------------
# NAME
#   report_prereq_errors
#
# DESCRIPTION
#   Scans the patch descriptions for any patches which have errors, and
#   reports them to the user
#
# ARGUMENTS
#   None
#
# RETURNS
#   1 if any prereq errors where found, 0 otherwise
sub report_prereq_errors {
  if (!$debug && !$verbose) {
    sqlpatch_log(LOG_ALWAYS, "\n");
  }

  my $found = 0;

  # 18355572: Print errors so the user will know what went wrong
  foreach my $patch (sort keys %patch_descriptions) {
    if ($patch ne "") {
      if (!$patch_descriptions{$patch}->{"prereq_ok"}) {
        if (!$found) {
          $found = 1;
          sqlpatch_log(LOG_ALWAYS, "Error: prereq checks failed!\n");
        }
        sqlpatch_log(LOG_ALWAYS, 
          "  patch " . $patch_descriptions{$patch}->{"patchid"} . ": " .
          $patch_descriptions{$patch}->{"prereq_failed_reason"} . "\n");
      }
    }
  }

  return $found;
}


# ----------------------------- print_queue ----------------------------------
# NAME
#   print_queue
#
# DESCRIPTION
#   Prints patch queue to the user
#
# ARGUMENTS
#   None
#
# RETURNS
#   None
sub print_queue {
  sqlpatch_log(LOG_ALWAYS, "Installation queue:\n");

  foreach my $queue_entry (@patch_queue) {
    if ($queue_entry->{"combined"}) {
      next;
    }
    # 18355572: Print out work to be done based on final queue
    my $indent;
    if ($container_db) {
      sqlpatch_log(LOG_ALWAYS, 
        "  For the following PDBs: " . $queue_entry->{"pdbs"} . "\n");
      $indent = "    ";
    }
    else {
      $indent = "  ";
    }

    if (scalar @{$queue_entry->{"rollbacks"}} == 0) {
      sqlpatch_log(LOG_ALWAYS, $indent . "Nothing to roll back\n");
    }
    else {
      sqlpatch_log(LOG_ALWAYS,
        $indent . "The following patches will be rolled back:\n");

      foreach my $patch (@{$queue_entry->{"rollbacks"}}) {
        sqlpatch_log(LOG_ALWAYS,
          $indent . "  " . $patch_descriptions{$patch}->{"patchid"} .
          " (" . $patch_descriptions{$patch}->{"description"} . ")\n");
      }
    }

    if (scalar @{$queue_entry->{"applys"}} == 0) {
      sqlpatch_log(LOG_ALWAYS, $indent . "Nothing to apply\n");
    }
    else {
      sqlpatch_log(LOG_ALWAYS,
        $indent . "The following patches will be applied:\n");
      foreach my $patch (@{$queue_entry->{"applys"}}) {
        sqlpatch_log(LOG_ALWAYS,
          $indent . "  " . $patch_descriptions{$patch}->{"patchid"} . 
          " (" . $patch_descriptions{$patch}->{"description"} . ")\n");
      }
    }
  }

  sqlpatch_log(LOG_ALWAYS, "\n");
}


# ----------------------------- check_queue_prereqs --------------------------
# NAME
#   check_queue_prereqs
#
# DESCRIPTION
#   Verify final prereqs based on the patch queue, namely that the install
#   script exists and that the log file directory either exists or can be 
#   created.
#
# ARGUMENTS
#   None
#
# RETURNS
#   0 for success, 1 if any prereqs failed
# existance of script
sub check_queue_prereqs {
  my $prereq_failed = 0;

  foreach my $entry (@patch_queue) {
    foreach my $patch (@{$entry->{"applys"}}, @{$entry->{"rollbacks"}}) {
      # Check for the existence of the log directory, and create if necessary
      unless (-e $patch_descriptions{$patch}->{"logdir"}) {
        sqlpatch_log(LOG_DEBUG, 
          "creating logdir " . $patch_descriptions{$patch}->{"logdir"} . "\n");

        if (!make_path($patch_descriptions{$patch}->{"logdir"})) {
          # Could not create the log directory
          $patch_descriptions{$patch}->{"prereq_ok"} 	= 0;
          $patch_descriptions{$patch}->{"prereq_failed_reason"} = 
            "Could not create log directory " .
            $patch_descriptions{$patch}->{"logdir"};
          $prereq_failed = 1;
          next;
        }
      }

      # Check for the existence of the install script
      my $script = $patch_descriptions{$patch}->{"mode"} . "_script";
      unless (-e $patch_descriptions{$patch}->{$script}) {
        $patch_descriptions{$patch}->{"prereq_ok"} = 0;
        $patch_descriptions{$patch}->{"prereq_failed_reason"} = 
          $patch_descriptions{$patch}->{"mode"} . " script " .
          $patch_descriptions{$patch}->{$script} . " does not exist";
        $prereq_failed = 1;
      }
   
      if( $patch_descriptions{$patch}->{"startup_mode"} eq "upgrade")  {
        if ($container_db) {
          foreach my $pdb (split (/ / , $entry -> {"pdbs"})){
            if ($pdb_info{$pdb}->{"startup_mode"} ne "MIGRATE") {
              $patch_descriptions{$patch}->{"prereq_ok"} = 0;
              $patch_descriptions{$patch}->{"prereq_failed_reason"} =  
                "The pluggable databases that need to be patched must be in upgrade mode";
              $prereq_failed = 1;
            }
          }
        }
        else {
          # 19723336: For the single tenant case just check %pdb_info and not
          # the pdbs list in the queue entry.  Note also that the startup
          # mode (which comes from v$instance originally) is OPEN MIGRATE and
          # not MIGRATE when in upgrade mode.
          if ($pdb_info{"undef"}->{"startup_mode"} ne "OPEN MIGRATE") {
            $patch_descriptions{$patch}->{"prereq_ok"} = 0;
            $patch_descriptions{$patch}->{"prereq_failed_reason"} =  
              "The database must be in upgrade mode";
            $prereq_failed = 1;
          }
        }
      }
    }
  }

  return $prereq_failed;
}


# ----------------------------- install_patches ------------------------------
# NAME
#   install_patches
#
# DESCRIPTION
#   Installs (applies or rolls back) the patches in the execution queue using
#   catcon.
#
# ARGUMENTS
#   None
#
# RETURNS
#   Number of patches installed in total across all PDBs
sub install_patches {
  my $total_patches = 0;


  # 17665122 - We want to ensure that there are no sessions in pdb$seed
  # so we switch to cdb$root.
  if ($container_db){
    my $alter_handle =
          $dbh->prepare("ALTER SESSION SET CONTAINER = cdb\$root");
        $alter_handle->execute;
  } 

  # For each entry in the patch queue
  foreach my $queue_entry (@patch_queue) {
    if ($queue_entry->{"patch_string"} eq "R: A:" ||
        $queue_entry->{"combined"}) {
      next; # Skip PDBs with nothing to do
    }

    # Catcon parameters
    my @catcon_scripts;               # Array of scripts/statements to run
    my $catcon_single_threaded = 1;   # Run scripts in order?
    my $catcon_root_only = 0;         # Run only in the root?
    my $catcon_run_per_proc = 0;      # Run per process init statements?
    my $con_names_incl;               # PDBs to include
    my $con_names_excl;               # PDBs to exclude
    my $custom_err_logging_ident;     # Custom error logging identifier

    if ($container_db) {
      $con_names_incl = $queue_entry->{"pdbs"};
    }
    else {
      $con_names_incl = "";
    }

    my $session_initialized = 0;

    foreach my $patch (@{$queue_entry->{"rollbacks"}},
                       @{$queue_entry->{"applys"}}) {
      my ($patchid, $patchuid) = split(/\//, $patch);

      if ($total_patches == 0) {
        sqlpatch_log(LOG_ALWAYS, "Installing patches...\n");
      }

      if (!$session_initialized) {
        $session_initialized = 1;
        # 17277459: We need to first execute session_initialize before
        # installing any patches
        my $session_init_sql =
          "BEGIN dbms_sqlpatch.session_initialize('";

        if ($user_oh ne "") {
          $session_init_sql .= $user_oh;
        }
        else {
          $session_init_sql .= $oracle_home;
        }

        $session_init_sql .= "', ";
        $session_init_sql .= $force ? "TRUE, " : "FALSE, ";
        $session_init_sql .= $debug ? "TRUE) " : "FALSE) ";
        $session_init_sql .= "; END;";

        push (@catcon_scripts, $session_init_sql);
        }

      # We need to increment total patches by the number of PDBs in this
      # entry since we are going to run it in each PDB
      $total_patches += $queue_entry->{"num_pdbs"};

      if ($patch_descriptions{$patch}->{"mode"} eq "apply") {
        push (@catcon_scripts, "@" . $patch_descriptions{$patch}->{"apply_script"});
      }
      else {
        push (@catcon_scripts, "@" . $patch_descriptions{$patch}->{"rollback_script"});
      }

      # 17277459: Pass all parameters
      push (@catcon_scripts, "--p\"" . $patch_descriptions{$patch}->{"description"} . "\"");
      push (@catcon_scripts, "--p" . $patch_descriptions{$patch}->{"logdir"});
      push (@catcon_scripts, "--p" . $patch_descriptions{$patch}->{"flags"});

      if (defined($patch_descriptions{$patch}->{"bundle_series"})) {
        push (@catcon_scripts, "--p" . $patch_descriptions{$patch}->{"bundle_series"});
      }
      else {
        # We can't pass a null parameter with catcon, so the series will be
        # NONE.
        push (@catcon_scripts, "--pNONE");
      }
    }

    # 19189525: Set PDBs to include for catconExec not catcatonInit
    my $catcon_ret = 
      catcon::catconExec(@catcon_scripts, $catcon_single_threaded,
                         $catcon_root_only, $catcon_run_per_proc,
                         $con_names_incl, $con_names_excl,
                         $custom_err_logging_ident);

    if ($catcon_ret) {
      # 19501299: Fail immediately and return without installing further
      # patches.
      sqlpatch_log(LOG_ALWAYS, 
                   "\ncactonExec failed during patch installation\n");
      $catcon_ok = 0;
      return 0;
    }
  }

  sqlpatch_log(LOG_ALWAYS, 
    "Patch installation complete.  Total patches installed: $total_patches\n\n");

  return $total_patches;
}


# ---------------------------- validate_logfiles ----------------------------
# NAME
#   validate_logfiles
#
# DESCRIPTION
#   Scans each logfile for ignorable errors, and updates the SQL registry
#   (for each PDB if necessary) indicating success or failure.
#
# ARGUMENTS
#   None
#
# RETURNS
#   0 for success, 2 if one or more logfiles contains a non-ignorable error
sub validate_logfiles {

  my $ret = 0;
  my $found_error = 0;

  sqlpatch_log(LOG_ALWAYS, "Validating logfiles...");
  if ($debug || $verbose) {
    sqlpatch_log(LOG_ALWAYS, "\n");
  }

  foreach my $queue_entry (@patch_queue) {
    if ($queue_entry->{"combined"}) {
      next;
    }

    my @pdbs;
    if (defined($queue_entry->{"pdbs"})) {
      @pdbs = split(' ', $queue_entry->{"pdbs"});
    }
    for (my $p = 0; $p <= (@pdbs ? $#pdbs : 0); $p++) {
      my $reset_seed = 0;
      if (@pdbs) {
        sqlpatch_log(LOG_DEBUG, 
                     "validate_logfiles switching to pdb @pdbs[$p]\n");

        # Switch to PDB first
        my $alter_handle = 
          $dbh->prepare("ALTER SESSION SET CONTAINER = " . @pdbs[$p]);
        $alter_handle->execute;

        # If this is the seed PDB then if is opened READ ONLY then
        # we need to open it read write
        if (@pdbs[$p] eq "PDB\$SEED") {
          my ($open_mode) =
            $dbh->selectrow_array("SELECT open_mode FROM v\$containers
                                     WHERE name = 'PDB\$SEED'");
          if ($open_mode eq "READ ONLY") {
            sqlpatch_log(LOG_DEBUG, "resetting seed to read write\n");

            my $sth = $dbh->prepare(
              "ALTER PLUGGABLE DATABASE pdb\$seed
                 CLOSE IMMEDIATE INSTANCES=ALL");
            $sth->execute;

            $sth = 
              $dbh->prepare(
                "ALTER PLUGGABLE DATABASE pdb\$seed
                   OPEN READ WRITE INSTANCES=ALL");

            # 18396989: We are in the process of patching the seed DB.  This
            # open will perform the check of validating the seed SQL registry
            # against the root.  But since we haven't finished the patching
            # the validation will fail, and we'll get a rather ominous message
            # printed to stderr (which is really a warning).
            # So we just supress the warning printing for this statement only.
            $sth->{PrintWarn} = 0;
            $sth->execute;
            $sth->{PrintWarn} = 1;

            $reset_seed = 1;
          }
        }
      }

      foreach my $patch (@{$queue_entry->{"rollbacks"}}) {
        $ret = validate_one_logfile(@pdbs ? @pdbs[$p] : undef,
                                    $patch, "rollback");
        if ($ret) {
          $found_error = 1;
        }
      }
      foreach my $patch (@{$queue_entry->{"applys"}}) {
        $ret =validate_one_logfile(@pdbs ? @pdbs[$p] : undef,
                                   $patch, "apply");
        if ($ret) {
          $found_error = 1;
        }
      }

      if ($reset_seed) {
        my $sth =
          $dbh->prepare(
            "ALTER PLUGGABLE DATABASE pdb\$seed
               CLOSE IMMEDIATE INSTANCES=ALL");
        $sth->execute;

        # 17277459: The server doesn't seem to execute the PDB validation code
        # if we open a PDB in read only mode.  But we want to be sure that we
        # validate the (re)open of the seed, since we likely encountered 
        # errors when opening in read write mdoe before the patching was
        # complete.  Thus we open in read write mode first here, then close
        # once more and open in read only mode.
        $sth =
          $dbh->prepare("ALTER PLUGGABLE DATABASE pdb\$seed
                           OPEN READ WRITE INSTANCES=ALL");
        $sth->execute;

        $sth =
          $dbh->prepare("ALTER PLUGGABLE DATABASE pdb\$seed
                           CLOSE IMMEDIATE INSTANCES=ALL");
        $sth->execute;

        $sth = 
          $dbh->prepare("ALTER PLUGGABLE DATABASE pdb\$seed
                           OPEN READ ONLY INSTANCES=ALL");
        $sth->execute;
       }
     }
   }

  sqlpatch_log(LOG_DEBUG,
               "Patch results:\n" . Data::Dumper->Dumper(\@patch_results));

  # All log files have been validated, display results if needed
  if (!$verbose && !$found_error) {
    sqlpatch_log(LOG_ALWAYS, "done\n");
    return 0;
  }

  if (!$verbose) {
    sqlpatch_log(LOG_ALWAYS, "\n");
  }

  foreach my $result_entry (@patch_results) {
    my $patchid = $patch_descriptions{$result_entry->{"patch"}}->{"patchid"};
    if ($verbose || $result_entry->{"status"} ne "SUCCESS") {
      sqlpatch_log(LOG_ALWAYS, "Patch $patchid " .
        $result_entry->{"mode"} .
        ($result_entry->{"pdb"} ? (" (pdb " . $result_entry->{"pdb"} . ")")
                                : "") .
        ": " . $result_entry->{"status"} . "\n");
      sqlpatch_log(LOG_ALWAYS, "  logfile: " . $result_entry->{"logfile"});
      if ($#{$result_entry->{"errors"}} eq -1) {
        sqlpatch_log(LOG_ALWAYS, " (no errors)\n");
      }
      else {
        sqlpatch_log(LOG_ALWAYS, " (errors)\n");
        for (my $i = 0; $i <= $#{$result_entry->{"errors"}}; $i++) {
          sqlpatch_log(LOG_ALWAYS,
            "    Error at line " . $result_entry->{"error_lines"}[$i] . 
            ": " . $result_entry->{"errors"}[$i] . "\n");
        }
      }
    }
  }

  if ($found_error) {
    return 2;
  }
  else {
    return 0;
  }
}

# ------------------------------- validate_one_logfile -----------------------
# NAME
#   validate_one_logfile
#
# DESCRIPTION
#   Determines the logfile for a given patch installation attempt, checks for
#   errors, and adds the result to @patch_results.  Also updates the SQL
#   registry with the results.
#
# ARGUMENTS
#   $pdb:  PDB to which this patch was installed (undefined if not a
#          container DB).  The session should already be pointing to the
#          correct PDB prior to calling this routine.
#   $patch: patch which was installed
#   $mode: "apply" or "rollback"
#
# RETURNS
#   0 for no errors, 2 if a non-ignorable error appears in the logfile
#   or if the second update in the install script did not complete.
#   Regardless of the return status, a new entry is added to @patch_results.
sub validate_one_logfile {
  my ($pdb, $patch, $mode) = @_;
  my $result_rec = {};
  my $retval;
  my $patchid;
  my $patchuid;

  # 17277459: Handle bootstrap mode
  if ($mode eq "bootstrap") {
    if ($container_db) {
      $result_rec->{"logfile"} = $pdb_info{$pdb}->{"bootstrap_log"};
    }
    else {
      $result_rec->{"logfile"} = $pdb_info{undef}->{"bootstrap_log"};
    }
  }
  else {
    # 17665117: Split into patch id and UID
    ($patchid, $patchuid) = split(/\//, $patch);

    sqlpatch_log(LOG_DEBUG,
      "validate_one_logfile checking patch $patchid UID $patchuid mode $mode\n");

    # Get logfile by querying the registry
    my $registry_query = 
      "SELECT status, logfile
         FROM dba_registry_sqlpatch
         WHERE patch_id = ?
         AND patch_uid = ?
         AND action_time = (SELECT MAX(action_time)
                              FROM dba_registry_sqlpatch
                              WHERE patch_id = ?
                              AND patch_uid = ?
                              AND action = UPPER(?))";

    ($result_rec->{"status"}, $result_rec->{"logfile"}) =
      $dbh->selectrow_array($registry_query, undef,
                            ($patchid, $patchuid, $patchid, $patchuid, $mode));
    $result_rec->{"patch"} = $patch;
    $result_rec->{"mode"} = $mode;
    $result_rec->{"pdb"} = $pdb;

    sqlpatch_log(LOG_DEBUG,
      "validate_one_logfile checking " . $result_rec->{"logfile"} .
      ", status " . $result_rec->{"status"} . "\n");
  }

  # 17354355: Don't return if the status is not END, we need to check the
  # logfiles to be completely sure.

  # 17277459: No need to scan the catcon log

  my $sqlpatch_logok;

  # 17981677: Set up the list of local ignorable errors, which will be checked
  # in addition to the file ignorable errors.  If the user specified ignorable
  # errors, use them.  If not, and this is a PSU or EXA patch, then use the
  # PSU list.
  my @local_ignorable_errors;

  if ($#user_ignorable_errors ne -1 || ($mode eq "bootstrap")) {
    @local_ignorable_errors = @user_ignorable_errors;
  }
  # 14643995: Skip this check if in bootstrap mode.  This avoids putting an
  # empty entry in the patch decriptions hash.
  elsif ($mode ne "bootstrap") {
    if (($patch_descriptions{$patch}->{"bundle_series"} eq "PSU") ||
        ($patch_descriptions{$patch}->{"bundle_series"} eq "EXA")) {
      sqlpatch_log(LOG_DEBUG, 
        "Setting ignorable errors to psu_ignorable_errors\n");

      @local_ignorable_errors = @psu_ignorable_errors;
    }
  }

  sqlpatch_log(LOG_DEBUG, 
    "local ignorable errors: @local_ignorable_errors\n");

  # Check log files for errors
  # 17354111: Check catbundle logs as well
  # 17277459: No need for catbundle logs
  foreach my $type ("sqlpatch") {
    my @file_ignorable_errors = undef;

    my $lineno = 0;

    my $lines;
    my $errors;
    my $logfile;
    my $logok = 1;

    if ($type eq "sqlpatch") {
      $lines = "error_lines";
      $errors = "errors";
      $logfile = $result_rec->{"logfile"};
    }

    if (defined($logfile)) {
      sqlpatch_log(LOG_DEBUG, "Scanning file $logfile for errors\n");

      # 14372248: sqlplus errors are of the format SP2-xxxx
      # 19044962: Catch PL/SQL errors and compilation warnings
      my $error_regexp = "^[A-Z]{2}[A-Z2]-\\d{4,5}";  # ORA- and SP2-
      $error_regexp .= "|PLS-\\d\\d\\d\\d\\d";             # PLS-xxxxx

      # compilation errors
      $error_regexp .= "|^Warning: .* with compilation errors";  

      # PL/SQL errors in show errors output
      $error_regexp .= "| PL/SQL: ";

      open (LOGFILE, $logfile);
      while (my $line = <LOGFILE>) {
        chomp $line;
        $lineno++;
        if ($line =~ /^IGNORABLE ERRORS: (.*)/) {
          sqlpatch_log(LOG_DEBUG, "  Found new ignorable error line: $line\n");

          if ($1 eq "NONE") {
            @file_ignorable_errors = undef;
          }
          else {
            @file_ignorable_errors = split(/,/, $1)
          }

          sqlpatch_log(LOG_DEBUG, 
                       "  file ignorable errors: @file_ignorable_errors\n");
        }

        elsif ($line =~ /($error_regexp)/) {
          sqlpatch_log(LOG_DEBUG, "  Found error line $1\n");

          if ((grep(/$1/, @file_ignorable_errors) eq 0) &&
              (grep(/$1/, @local_ignorable_errors) eq 0)) {
            # Found error line which is not in the current list
            sqlpatch_log(LOG_DEBUG, "  Error at line $lineno: $line\n");

            push(@{$result_rec->{$lines}}, $lineno);
            push(@{$result_rec->{$errors}}, $line);
            $logok = 0;
          }
        }
      }
    }
  
    if ($type eq "sqlpatch") {
      $sqlpatch_logok = $logok;
    }
  }

  if ($mode eq "bootstrap") {
    if ($sqlpatch_logok) {
      return 0;
    }
    else {
      sqlpatch_log(LOG_ALWAYS,
        "  Error in bootstrap log " . $result_rec->{"logfile"} . ":\n");
      for (my $i = 0; $i <= $#{$result_rec->{"errors"}}; $i++) {
        sqlpatch_log(LOG_ALWAYS,
          "    Error at line " . $result_rec->{"error_lines"}[$i] . 
          ": " . $result_rec->{"errors"}[$i] . "\n");
      }
      return 2;
    }
  }
  else {
    if ($sqlpatch_logok) {
      $result_rec->{"status"} = "SUCCESS";
      $retval = 0;
    }
    else {
      $result_rec->{"status"} = "WITH ERRORS";
      $retval = 2;
    }

    push(@patch_results, $result_rec);

    # Update the registry
    my $update_sql =
      "UPDATE dba_registry_sqlpatch
         SET status = ?, action_time = SYSTIMESTAMP
         WHERE patch_id = ?
         AND patch_uid = ?
         AND action = UPPER(?)
         AND action_time = (SELECT MAX(action_time)
                              FROM dba_registry_sqlpatch
                              WHERE patch_id = ?
                                AND patch_uid = ?
                                AND action = UPPER(?))";
    my $sth = $dbh->prepare($update_sql);
    $sth->execute($result_rec->{"status"},
                  $patchid, $patchuid, $mode, $patchid, $patchuid, $mode);

    sqlpatch_log(LOG_DEBUG,
      "updated registry to " . $result_rec->{"status"} . 
        " for $patchid/$patchuid mode $mode\n");
  }

  return $retval;
}

# ------------------------------- bootstrap ----------------------------------
# NAME
#   bootstrap
#
# DESCRIPTION
#   Bootstraps the registry and package if needed.  If the SQL registry table
#   and view are missing columns, then they are added.  If the dbms_sqlpatch
#   package is missing, invalid, or the wrong version, it is (re)created.
#
# ARGUMENTS
#   None
#
# RETURNS
#   0 for success, 1 for failure during the bootstrap process
sub bootstrap {

  my $ret;

  if ($verbose || $full_bootstrap) {
    sqlpatch_log(LOG_ALWAYS, 
                 "Bootstrapping registry and package to current versions...");
  }

  sqlpatch_log(LOG_DEBUG, "\n");

  # catcon parameters
  my @catcon_scripts;               # Array of scripts/statements to run
  my $catcon_single_threaded = 1;   # Run scripts in order?
  my $catcon_root_only = 0;         # Run only in the root?
  my $catcon_run_per_proc = 0;      # Run per process init statements?
  my $con_names_incl;               # PDBs to include
  my $con_names_excl;               # PDBs to exclude
  my $custom_err_logging_ident;     # Custom error logging identifier

  if ($container_db) {
    $con_names_incl = join(' ', @pdb_list);
  }
  else {
    $con_names_incl = "";
  }

  my $oh;
  if ($user_oh ne "") {
    $oh = $user_oh;
  }
  else {
    $oh = $oracle_home;
  }

  my $bootstrap_file = 
    File::Spec->catfile($user_oh ne "" ? $user_oh : $oracle_home,
                        "sqlpatch", "sqlpatch_bootstrap.sql");

  push (@catcon_scripts, "\@$bootstrap_file");
  push (@catcon_scripts, "--p$invocation_logdir");
  if ($full_bootstrap) {
    push (@catcon_scripts, "--pTRUE");
  }
  else {
    push (@catcon_scripts, "--pFALSE");
  }

  # Record bootstrap log
  if ($container_db) {
    foreach my $pdb (@pdb_list) {
      my $local_name = $pdb;
      $local_name =~ s/\$//;
      $pdb_info{$pdb}->{"bootstrap_log"} =
        File::Spec->catfile($invocation_logdir,
                            "bootstrap_" . $database_name . "_" .
                            $local_name . ".log");
    }
  }
  else {
    $pdb_info{undef}->{"bootstrap_log"} =
      File::Spec->catfile($invocation_logdir,
                          "bootstrap_" . $database_name .".log");
  }

  sqlpatch_log(LOG_DEBUG,
    "bootstrap pdb info: " . Data::Dumper->Dumper(\%pdb_info) . "\n");

  my $catcon_ret =
    catcon::catconExec(@catcon_scripts, $catcon_single_threaded,
                       $catcon_root_only, $catcon_run_per_proc,
                       $con_names_incl, $con_names_excl,
                       $custom_err_logging_ident);
  if ($catcon_ret) {
    # 19501299: Fail immediately and return without installing further
    # patches.
    sqlpatch_log(LOG_ALWAYS, "\ncatconExec failed during bootstrap\n");
    $catcon_ok = 0;
    $ret = 1;
    goto bootstrap_complete;
  }

  if ($verbose || $full_bootstrap) {
    sqlpatch_log(LOG_ALWAYS, "done\n");
  }

  foreach my $pdb (@pdb_list) {
    if (validate_one_logfile($pdb, undef, "bootstrap")) {
      $ret = 1;
    }
  }

  bootstrap_complete:
  return $ret;

}

# ------------------------------ applied_patches -----------------------------
# NAME
#   applied_patches
#
# DESCRIPTION
#   Returns the current set of applied patches in all PDBs as an array.
#   Used for -rollback all
#
# ARGUMENTS
#   None
#
# RETURNS
#   Array consisting of patch id/patch UID strings
sub applied_patches {

  my @ret;

  my $applied_query = 
    "SELECT patchid || '/' || patchuid
       FROM XMLTable('/sql_registry_state/patch'
                     PASSING dbms_sqlpatch.sql_registry_state
                     COLUMNS patchid NUMBER PATH '\@id',
                     patchuid NUMBER PATH '\@uid')";
  my $applied_stmt = $dbh->prepare($applied_query);

  # For each PDB we need to alter session to that PDB, then get the list
  # of applied patches.
  foreach my $pdb (@pdb_list) {
    if ($container_db) {
      my $alter_handle = 
        $dbh->prepare("ALTER SESSION SET CONTAINER = " . $pdb);
      $alter_handle->execute;
    }

    push(@ret, @{$dbh->selectcol_arrayref($applied_stmt)});
  }

  sqlpatch_log(LOG_DEBUG, "applied patches returning @ret\n");

  return @ret;
}


# ------------------------ check_global_prereqs ------------------------------
# NAME
#   check_global_prereqs
#
# DESCRIPTION
#   Verifies that any global prereqs are satisfied:
#   19051526: Check that the queryable inventory package is working properly
#   by calling dbms_sqlpatch.verify_queryable_inventory.
#
# ARGUMENTS
#   None
#
# RETURNS
#   0 for success, 1 for prereq failure
sub check_global_prereqs {

  if ($force) {
    # -force specified, skip the check
    return 0;
  }

  # 19189525: Call bootstrap
  if (bootstrap()) {
    return 1;
  }

  if ($container_db) {
    my $alter_handle =
      $dbh->prepare("ALTER SESSION SET CONTAINER = CDB\$ROOT");
    $alter_handle->execute();
  }

  sqlpatch_log(LOG_DEBUG, "verify_qi calling verify_queryable_inventory...\n");

  my $verify_query = 
    "SELECT dbms_sqlpatch.verify_queryable_inventory FROM dual";
  my ($qi_status) = $dbh->selectrow_array($verify_query);
  if ($qi_status eq "OK") {
    return 0;
  }
  else {
    sqlpatch_log(LOG_INVOCATION,
      "verify_queryable_inventory returned $qi_status\n");

    sqlpatch_log(LOG_ALWAYS,
      "\nQueryable inventory could not determine the current opatch status.\n");
    sqlpatch_log(LOG_ALWAYS,
      "Execute 'select dbms_sqlpatch.verify_queryable_inventory from dual'\n");
    sqlpatch_log(LOG_ALWAYS,
      "and/or check the invocation log\n" . $invocation_log);
    sqlpatch_log(LOG_ALWAYS, "\nfor the complete error.\n");
    return 1;
  }

}

# ----------------------------- usage ---------------------------------------
# NAME
#   usage
#
# DESCRIPTION
#
#   Prints the usage (via sqlpatch.pl) to the screen and invocation log
#
# ARGUMENTS
#   None
#
# RETURNS
#   None
sub usage() {
  sqlpatch_log(LOG_ALWAYS, 
    "SQL Patching tool version $build_version on " . (localtime) . "\n");
  sqlpatch_log(LOG_ALWAYS, "$copyright\n\n");

  sqlpatch_log(LOG_ALWAYS,
    "sqlpatch usage:\n");
  sqlpatch_log(LOG_ALWAYS,
    "All arguments are optional, if there are no arguments sqlpatch\n");
  sqlpatch_log(LOG_ALWAYS,
    "will automatically determine which SQL scripts need to be run in\n");
  sqlpatch_log(LOG_ALWAYS,
    "order to complete the installation of any SQL patches.\n\n");

  sqlpatch_log(LOG_ALWAYS,
    "Optional arguments:\n");
  sqlpatch_log(LOG_ALWAYS,
    "-db <db name>\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Use the specified database rather than \$ORACLE_SID\n");
  sqlpatch_log(LOG_ALWAYS,
    "-bundle_series <bundle_series>\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Specify if the patch is a bundle patch \n");
  sqlpatch_log(LOG_ALWAYS,
    "  Should also be accompanied by -force option\n");
  sqlpatch_log(LOG_ALWAYS,
    "  if -bundle_series option is specified,only 1 patch will\n");
  sqlpatch_log(LOG_ALWAYS,
    "  be considered by the -force command\n");
  sqlpatch_log(LOG_ALWAYS,
    "-apply <patch1,patch2,...,patchn>\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Only consider the specified patch list for apply operations\n");
  sqlpatch_log(LOG_ALWAYS,
    "-rollback <patch1,patch2,...,patchn>\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Only consider the specified patch list for rollback operations\n");
  sqlpatch_log(LOG_ALWAYS,
    "-upgrade_mode_only\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Only consider patches that require upgrade mode\n");
  sqlpatch_log(LOG_ALWAYS,
    "-force\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Run the apply and/or rollback scripts even if not necessary\n");
  sqlpatch_log(LOG_ALWAYS,
    "  per the SQL registry\n");
  sqlpatch_log(LOG_ALWAYS,
    "-pdbs <pdb1,pdb2,...,pdbn>\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Only consider the specified list of PDBs for patching.  All\n");
  sqlpatch_log(LOG_ALWAYS,
    "  other PDBs will not be patched\n");
  sqlpatch_log(LOG_ALWAYS,
    "-prereq\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Run prerequisite checks only, do not actually run any scripts\n");
  sqlpatch_log(LOG_ALWAYS,
    "-oh <oracle_home value>\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Use the specified directory to check for installed patches\n");
  sqlpatch_log(LOG_ALWAYS,
    "-verbose\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Output additional information used for debugging\n");
  sqlpatch_log(LOG_ALWAYS,
    "-help\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Output usage information and exit\n");
  sqlpatch_log(LOG_ALWAYS,
    "-version\n");
  sqlpatch_log(LOG_ALWAYS,
    "  Output build information and exit\n");
  sqlpatch_log(LOG_ALWAYS, "\n");
}

1;
