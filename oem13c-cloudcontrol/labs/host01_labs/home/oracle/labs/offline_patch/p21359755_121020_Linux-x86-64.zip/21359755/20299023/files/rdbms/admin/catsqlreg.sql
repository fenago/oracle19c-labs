Rem
Rem $Header: rdbms/admin/catsqlreg.sql /st_rdbms_12.1.0.2.0dbpsu/2 2015/03/15 08:49:11 surman Exp $
Rem
Rem catsqlreg.sql
Rem
Rem Copyright (c) 2014, 2015, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catsqlreg.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/catsqlreg.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/catsqlreg.sql
Rem    SQL_PHASE: CATSQLREG
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: rdbms/admin/catptabs.sql
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      01/26/15 - Backport surman_bug-19315691 from main
Rem    surman      06/12/14 - Add new columns to the end
Rem    surman      10/08/14 - 19315691: bundle_data to CLOB
Rem    surman      04/21/14 - Seperate script for SQL registry
Rem    surman      04/21/14 - Created
Rem

@@?/rdbms/admin/sqlsessstart.sql

Rem SQL Registry table
Rem This is used to record the SQL patches that are applied and rolled back
Rem for this database instance.  It is updated by the patch apply and rollback
Rem scripts.
Rem 17277459: Add columns to track installation of bundle patches
Rem The flags column contains the following characters:
Rem  U: Patch requires upgrade mode
Rem  N: Patch requires normal mode
Rem  B: Patch is a bundle patch
Rem  J: Patch is a OJVM patch
Rem At least U or N must be present in flags.
Rem If the patch is not a bundle patch, then bundle_series will be NONE.
CREATE TABLE registry$sqlpatch (
  patch_id      NUMBER,         -- Patch ID
  action        VARCHAR2(15),   -- APPLY or ROLLBACK
  action_time   TIMESTAMP,      -- Time of action
  description   VARCHAR2(100),  -- Patch description
  logfile       VARCHAR2(500),  -- Location of logfile
  status        VARCHAR2(15),   -- BEGIN, END, SUCCESS, WITH ERRORS
  version       VARCHAR2(20),   -- First 4 digits of version
  patch_uid     NUMBER,         -- Patch UID
  flags         VARCHAR2(10),   -- Flags for this patch
  bundle_series VARCHAR2(30),   -- PSU, EXA, WINBUNDLE, etc.
  bundle_id     NUMBER,         -- Bundle ID being installed
  bundle_data   CLOB,           -- Bundledata associated with this install
  CONSTRAINT registry$sqlpatch_pk
    PRIMARY KEY (patch_id, patch_uid, version, action, action_time)
);

Rem -------------------------------------------------------------------------
Rem SQL Registry view
Rem -------------------------------------------------------------------------

CREATE OR REPLACE VIEW dba_registry_sqlpatch AS
  SELECT patch_id, patch_uid, version, flags, action, status, action_time,
         description, bundle_series, bundle_id, bundle_data, logfile
    FROM registry$sqlpatch;

CREATE OR REPLACE PUBLIC SYNONYM dba_registry_sqlpatch
                   FOR dba_registry_sqlpatch;

GRANT SELECT ON dba_registry_sqlpatch TO SELECT_CATALOG_ROLE;

execute CDBView.create_cdbview(false,'SYS','dba_registry_sqlpatch','CDB_registry_sqlpatch');
grant select on SYS.CDB_registry_sqlpatch to select_catalog_role
/
create or replace public synonym CDB_registry_sqlpatch for SYS.CDB_registry_sqlpatch
/

@?/rdbms/admin/sqlsessend.sql
