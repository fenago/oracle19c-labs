Rem
Rem $Header: rdbms/admin/bug18909599.sql /st_rdbms_12.1.0.2.0dbpsu/2 2015/02/11 12:39:31 czechar Exp $
Rem
Rem bug18909599.sql
Rem
Rem Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      bug18909599.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/bug18909599.sql 
Rem    SQL_SHIPPED_FILE: rdbms/admin/bug18909599.sql 
Rem    SQL_PHASE: PATCH
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: NONE 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    czechar     02/11/15 - Fix SQL file metadata
Rem    dkoppar     02/03/15 - backport of 18909599
Rem    dkoppar     02/03/15 - Created
Rem

SET ECHO ON
SET FEEDBACK 1
SET NUMWIDTH 10
SET LINESIZE 80
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

@@?/rdbms/admin/sqlsessstart.sql
INSERT INTO sys.ku_noexp_tab ( obj_type, schema, name ) VALUES
 ('DIRECTORY', NULL, 'OPATCH_TEMP_DIR')
/
@?/rdbms/admin/sqlsessend.sql
