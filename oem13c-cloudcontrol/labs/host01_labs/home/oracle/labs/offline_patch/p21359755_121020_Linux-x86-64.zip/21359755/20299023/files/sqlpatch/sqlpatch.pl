#!/usr/local/bin/perl
# 
# $Header: rdbms/admin/sqlpatch/sqlpatch.pl /st_rdbms_12.1.0.2.0dbpsu/2 2015/02/03 19:17:52 surman Exp $
#
# sqlpatch.pl
# 
# Copyright (c) 2012, 2015, Oracle and/or its affiliates. All rights reserved.
#
#    NAME
#      sqlpatch.pl - <one-line expansion of the name>
#
#    DESCRIPTION
#      <short description of component this file declares/defines>
#      0: Success
#      1: Failure during prereq checks
#      2: Failure during patch application
#
#    NOTES
#      See support note 1585822.1 for full documentation.
#    MODIFIED   (MM/DD/YY)
#    apfwkr      01/05/15 - Backport surman_ci_backport_19547370_12.1.0.2.5dbbp
#                           from st_rdbms_12.1.0.2.0dbbp
#    surman      12/16/14 - Backport surman_bug-19547370 from main
#    surman      09/11/14 - 19547370: Much better logging
#    surman      06/24/14 - 19051526: Add period
#    surman      06/05/14 - Backport surman_bug-17277459 from main
#    apfwkr      05/20/14 - Backport mpradeep_bug-17665122_1 from main
#    apfwkr      05/02/14 - Backport mpradeep_bug-18411124_1 from main
#    surman      04/17/14 - Backport surman_bug-17665117 from main
#    surman      04/04/14 - Backport surman_bug-17898119 from main
#    apfwkr      04/03/14 - Backport mpradeep_bug-17358877 from main
#    surman      03/21/14 - Backport surman_bug-18355572 from main
#    mpradeep    05/13/14 - 17665122 Check if patches need upgrade mode
#    surman      04/21/14 - 17277459: datapatch replaces catbundle
#    mpradeep    04/18/14 - 18411124 - Correct help messages
#    mpradeep    03/24/14 - 17358877 Add a message for multitenant DB's
#    surman      03/19/14 - 17665117: Patch UID
#    surman      03/14/14 - 17898119: Fix -oh
#    surman      03/11/14 - 18355572: Exit if prereqs fail and bundle fixes
#    surman      02/21/14 - Add -bundle_series
#    surman      12/20/13 - 17981677: Add ignorable_errors
#    surman      12/16/13 - 17922172: Handle multiple bundles
#    surman      11/19/13 - 17777061: Better PDB handling
#    surman      09/17/13 - 17442449: Handle RAC better
#    surman      08/06/13 - 17005047: datapatch calls catbundle
#    surman      11/20/12 - 15873839: Check open_mode of PDBs
#    surman      10/30/12 - 14763881: Use db in connect string
#    surman      10/19/12 - 14787047: CDB support
#    surman      09/20/12 - 14624172: Add status column
#    surman      09/07/12 - 14563601: DB name and timestamp for logfile
#    surman      09/05/12 - 14589745: Version to 12.1.0.1.0
#    surman      08/29/12 - 14503324: Pass debug to sqlpatch.pm
#    surman      07/13/12 - 14165102: Creation
# 

use strict;
use Getopt::Long;

use sqlpatch;

my $db = '';              # Database to use instead of ORACLE_SID
my $ret;                  # 18355572: Return code
my $prereq_failed;        # 18355572: True if prereq checks failed
my %sqlpatch_parameters;     # 17665117: Hash of all parameters

# Turn on autoflush of output
$| = 1;

my $debug;

# Parse command line into parameters hash
my $parseError = 
  GetOptions (\%sqlpatch_parameters,
              'db=s',
              'apply=s',
              'rollback=s',
              'force',
              'prereq',
              'pdbs=s',
              'oh=s',
              'verbose',
              'bundle_series=s',
              'help',
              'debug',
              'ignorable_errors=s', 
              'version',
              'upgrade_mode_only',
              'bootstrap');


# Handle parse errors and help options
if (!$parseError || scalar(@ARGV)) {
  sqlpatch::usage();
  $ret = 1;
  goto complete;
}
elsif (defined($sqlpatch_parameters{"help"})) {
  sqlpatch::usage();
  $ret = 0;
  goto complete;
}

if (defined($sqlpatch_parameters{"debug"})) {
  sqlpatch::sqlpatch_log(sqlpatch::LOG_DEBUG, "Command line arguments:\n");
  sqlpatch::sqlpatch_log(sqlpatch::LOG_DEBUG,
                         Data::Dumper->Dumper(%sqlpatch_parameters));
}

# 14763881: If -db is specified, set $ORACLE_SID to it
if (defined($sqlpatch_parameters{"db"})) {
  $ENV{ORACLE_SID} = $sqlpatch_parameters{"db"};
  if (defined($sqlpatch_parameters{"debug"})) {
    sqlpatch::sqlpatch_log(sqlpatch::LOG_DEBUG,
      "-db specified, set ORACLE_SID to $ENV{ORACLE_SID}\n");
  }
}

# Initialize sqlpatch parameters
$ret = sqlpatch::initialize(\%sqlpatch_parameters);
if ($ret) {
  goto complete;
}

# Complete patching based on initialized parameters
$ret = sqlpatch::patch();

# And we're done

complete:

# 17277459: Clean up before exiting
sqlpatch::finalize();

exit($ret);

