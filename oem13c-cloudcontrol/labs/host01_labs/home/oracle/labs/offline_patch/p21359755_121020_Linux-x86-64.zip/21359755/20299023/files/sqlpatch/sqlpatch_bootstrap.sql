Rem
Rem $Header: rdbms/admin/sqlpatch/sqlpatch_bootstrap.sql /st_rdbms_12.1.0.2.0dbpsu/8 2015/03/15 08:49:11 surman Exp $
Rem
Rem sqlpatch_bootstrap.sql
Rem
Rem Copyright (c) 2014, 2015, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      sqlpatch_bootstrap.sql
Rem
Rem    DESCRIPTION
Rem      This file is used only by the datapatch utility.  It will scan the
Rem      SQL patching infrastructure (dbms_sqlpatch package,
Rem      dba_registry_sqlpatch view, registry$sqlpatch table) and recreate
Rem      it as needed.
Rem
Rem      sqlpatch_bootstrap.sql is executed automatically by datapatch each
Rem      time it starts up, for all active PDBs, unless -force is specified.
Rem
Rem    NOTES
Rem      Added for bug 19189525.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/sqlpatch/sqlpatch_bootstrap.sql 
Rem    SQL_SHIPPED_FILE: sqlpatch/sqlpatch_bootstrap.sql
Rem    SQL_PHASE: NONE
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: NONE
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      01/26/15 - Backport surman_bug-19315691 from main
Rem    apfwkr      01/05/15 - Backport
Rem                           surman_ci_backport_19547370_12.1.0.2.5dbbp from
Rem                           st_rdbms_12.1.0.2.0dbbp
Rem    surman      10/08/14 - 19315691: bundle_data to CLOB
Rem    dkoppar     09/11/14 - Backport dkoppar_bug-19561643 from
Rem    surman      12/16/14 - Backport surman_bug-19547370 from main
Rem    surman      09/06/14 - 19501173: Add QI packages
Rem                           st_rdbms_12.1.0.2.0dbbp
Rem    surman      08/21/14 - Backport surman_bug-19468347 from
Rem                           st_rdbms_12.1.0.2.0dbpsu
Rem    surman      08/20/14 - 19468347: Create CDB view
Rem    surman      09/15/14 - 19547370: No timestamp needed
Rem    surman      08/18/14 - Always reload dbms_sqlpatch
Rem    surman      07/17/14 - 19189525: Add bootstrap
Rem    surman      07/17/14 - Created
Rem

SET SERVEROUTPUT ON

@@?/rdbms/admin/sqlsessstart.sql

DEFINE logfiledir = &1
DEFINE full_bootstrap = &2

COLUMN bootstrap_logfile NEW_VALUE full_logfile
SELECT '&logfiledir' || '/bootstrap_' ||
  CASE WHEN (sys_context('userenv', 'cdb_name') IS NULL)
    THEN name
    ELSE name || '_' || replace(sys_context('userenv', 'con_name'), '$')
  END || '.log' AS bootstrap_logfile
  FROM v$database;

SPOOL &full_logfile

SET PAGESIZE 0
SELECT 'Starting bootstrap on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

VARIABLE sql_file VARCHAR2(50)
BEGIN
  :sql_file := dbms_registry.nothing_script;
END;
/


COLUMN sss NEW_VALUE sql_script

-- First validate the SQL registry table and view
DECLARE
  registry_found BOOLEAN := FALSE;
  reloading_registry BOOLEAN := FALSE;
  recreate_constraint BOOLEAN := FALSE;
  recreate_view BOOLEAN := FALSE;
  current_type NUMBER;

  FUNCTION column_exists(p_column_name IN VARCHAR2) RETURN BOOLEAN IS
    cnt NUMBER;
  BEGIN
    SELECT COUNT(column_name)
      INTO cnt
      FROM dba_tab_columns
      WHERE table_name = 'REGISTRY$SQLPATCH' AND owner = 'SYS'
      AND column_name = p_column_name;

    IF cnt = 1 THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;
  END column_exists;

BEGIN
  IF &full_bootstrap THEN
    dbms_output.put_line('Full bootstrap: recreating registry');
    BEGIN
      -- Drop existing registry first, ignoring errors in case it does not
      -- exist
      EXECUTE IMMEDIATE 'DROP TABLE registry$sqlpatch';
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;

    :sql_file := '?/rdbms/admin/catsqlreg.sql';
  ELSE
    :sql_file := dbms_registry.nothing_script;

    -- First check if the registry table and view exist and are valid
    FOR rec IN (SELECT object_name, status
                  FROM dba_objects
                  WHERE owner = 'SYS'
                  AND object_name IN ('REGISTRY$SQLPATCH', 
                                      'DBA_REGISTRY_SQLPATCH')) LOOP
      registry_found := TRUE;
      IF rec.status != 'VALID' AND NOT reloading_registry THEN
        reloading_registry := TRUE;
        -- Need to reload registry
        dbms_output.put_line(rec.object_name || ' not valid');

        BEGIN
          -- Drop existing registry first, ignoring errors in case it does not
          -- exist
          EXECUTE IMMEDIATE 'DROP TABLE registry$sqlpatch';
        EXCEPTION
          WHEN OTHERS THEN NULL;
        END;

        :sql_file := '?/rdbms/admin/catsqlreg.sql';
      END IF;
    END LOOP;

    IF NOT registry_found THEN
      -- Need to reload registry
      reloading_registry := TRUE;
      dbms_output.put_line('SQL registry not found');
      :sql_file := '?/rdbms/admin/catsqlreg.sql';
    ELSIF NOT reloading_registry THEN
      -- Check for existence of new columns and create if needed
      IF NOT column_exists('VERSION') THEN
        dbms_output.put_line('adding version column');
        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch DROP CONSTRAINT registry$sqlpatch_pk';
        recreate_constraint := TRUE;

        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (version VARCHAR2(20))';
        EXECUTE IMMEDIATE 'UPDATE registry$sqlpatch SET VERSION = ''0''';
        recreate_view := TRUE;
      END IF;

      IF NOT column_exists('PATCH_UID') THEN
        dbms_output.put_line('adding patch_uid column');
        IF NOT recreate_constraint THEN
          EXECUTE IMMEDIATE
            'ALTER TABLE registry$sqlpatch DROP CONSTRAINT registry$sqlpatch_pk';
          recreate_constraint := TRUE;
        END IF;

        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (patch_uid NUMBER)';
        EXECUTE IMMEDIATE 'UPDATE registry$sqlpatch SET patch_uid = 0';
        recreate_view := TRUE;
      END IF;

      IF NOT column_exists('FLAGS') THEN
        dbms_output.put_line('adding flags column');
        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (flags VARCHAR2(10))';
        recreate_view := TRUE;
      END IF;

      IF NOT column_exists('BUNDLE_SERIES') THEN
        dbms_output.put_line('adding bundle_series column');
        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (bundle_series VARCHAR2(30))';
        recreate_view := TRUE;
      END IF;

      IF NOT column_exists('BUNDLE_ID') THEN
        dbms_output.put_line('adding bundle_id column');
        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (bundle_id NUMBER)';
        recreate_view := TRUE;
      END IF;

      IF NOT column_exists('BUNDLE_DATA') THEN
        dbms_output.put_line('adding bundle_data column');
        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (bundle_data CLOB)';
        recreate_view := TRUE;
      END IF;

      -- 19315691: Change bundle_data column to CLOB from XMLType if needed
      -- We can't do this by adding and renaming columns because we aren't
      -- in upgrade mode and would get "ORA-12988: cannot drop column from
      -- table owned by SYS".  So we need to create a new table, drop the
      -- existing one, and rename the new one.  Sigh.
      -- We also can't query a nice view like dba_tab_columns because it may
      -- be invalid during an upgrade.  Sigh again.
      SELECT type#
        INTO current_type
        FROM col$
        WHERE obj# = (SELECT obj#
                        FROM obj$
                        WHERE name = 'REGISTRY$SQLPATCH'
                          AND owner# = 0)
          AND name = 'BUNDLE_DATA';

      -- Type 112 is CLOB
      IF current_type != 112 THEN
        dbms_output.put_line('changing bundle_data to CLOB');
        IF NOT recreate_constraint THEN
          EXECUTE IMMEDIATE
            'ALTER TABLE registry$sqlpatch DROP CONSTRAINT registry$sqlpatch_pk';
          recreate_constraint := TRUE;
        END IF;

        EXECUTE IMMEDIATE
          'CREATE TABLE registry$sqlpatch_temp AS
             SELECT patch_id, action, action_time, description, logfile,
                    status, version, patch_uid, flags, bundle_series,
                    bundle_id, TO_CLOB(bundle_data) bundle_data
               FROM registry$sqlpatch';

        EXECUTE IMMEDIATE
          'DROP TABLE registry$sqlpatch';

        EXECUTE IMMEDIATE
          'RENAME registry$sqlpatch_temp TO registry$sqlpatch';
        recreate_view := TRUE;
        recreate_constraint := TRUE;
      END IF;

      IF recreate_constraint THEN
        dbms_output.put_line('recreating constraint');
        EXECUTE IMMEDIATE
          'ALTER TABLE registry$sqlpatch ADD (
             CONSTRAINT registry$sqlpatch_pk PRIMARY KEY
               (patch_id, patch_uid, version, action, action_time))';
        recreate_view := TRUE;
      END IF;

      IF recreate_view THEN
        dbms_output.put_line('recreating view');
        EXECUTE IMMEDIATE
          'CREATE OR REPLACE VIEW dba_registry_sqlpatch AS
             SELECT patch_id, patch_uid, version, flags, action, status,
               action_time, description, bundle_series, bundle_id, bundle_data,
               logfile
             FROM registry$sqlpatch';

        CDBView.create_cdbview(FALSE, 'SYS', 'dba_registry_sqlpatch',
                               'CDB_registry_sqlpatch');

        -- Recompile public synonyms
        EXECUTE IMMEDIATE 'ALTER PUBLIC SYNONYM dba_registry_sqlpatch COMPILE';
        EXECUTE IMMEDIATE 'ALTER PUBLIC SYNONYM cdb_registry_sqlpatch COMPILE';
      END IF;
    END IF;
  END IF;
END;
/

SELECT :sql_file AS sss FROM dual;
@&sql_script

-- Second (re)create the queryable inventory and dbms_sqlpatch packages and
-- synonyms.  If there are no actual code changes then PL/SQL will treat this
-- as a no-op.
BEGIN
  dbms_output.put_line('(Re)creating dbms_qopatch package');
END;
/

@?/rdbms/admin/dbmsqopi.sql
@?/rdbms/admin/prvtqopi.plb

BEGIN
  dbms_output.put_line('(Re)creating dbms_sqlpatch package');
END;
/

@?/rdbms/admin/dbmssqlpatch.sql
@?/rdbms/admin/prvtsqlpatch.plb

@?/rdbms/admin/sqlsessend.sql

SET PAGESIZE 0
SELECT 'Finished bootstrap on ' || SYSTIMESTAMP FROM dual;
SET PAGESIZE 10

SPOOL off
