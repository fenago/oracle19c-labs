Rem
Rem $Header: rdbms/admin/dbmssqlpatch.sql /st_rdbms_12.1.0.2.0dbpsu/1 2014/08/18 22:17:55 surman Exp $
Rem
Rem dbmssqlpatch.sql
Rem
Rem Copyright (c) 2013, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      dbmssqlpatch.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    surman      08/18/14 - Always reload dbms_sqlpatch
Rem    surman      06/24/14 - 19051526: Add verify_queryable_inventory
Rem    surman      04/10/14 - More parameters
Rem    surman      10/31/13 - Creation for 17277459
Rem    surman      07/29/13 - Created
Rem
Rem  BEGIN SQL_FILE_METADATA 
Rem  SQL_SOURCE_FILE: rdbms/admin/dbmssqlpatch.sql 
Rem  SQL_SHIPPED_FILE: rdbms/admin/dbmssqlpatch.sql
Rem  SQL_PHASE: DBMSSQLPATCH
Rem  SQL_STARTUP_MODE: NORMAL 
Rem  SQL_IGNORABLE_ERRORS: NONE 
Rem  SQL_CALLING_FILE: rdbms/admin/catpdbms.sql
Rem  END SQL_FILE_METADATA

@@?/rdbms/admin/sqlsessstart.sql

CREATE OR REPLACE PACKAGE dbms_sqlpatch AS

  -- Performs any initialization necessary for the given patch, including
  -- the initial insert to the SQL registry.  Parameters:
  -- patch_id/patch_uid: patch ID/universal patch id
  -- flags: patch flags
  -- description: patch description as recorded in binary registry
  -- action: APPLY or ROLLBACK
  -- logfile: Full path to logfile
  -- bndl_series: For a bundle patch, the bundle series.
  -- bnld_xml: For a bundle patch, the full path to the bundledata.xml
  PROCEDURE patch_initialize(p_patch_id IN NUMBER,
                             p_patch_uid IN NUMBER,
                             p_flags IN VARCHAR2,
                             p_description IN VARCHAR2,
                             p_action IN VARCHAR2,
                             p_logfile IN VARCHAR2,
                             p_bundle_series IN VARCHAR2 DEFAULT NULL);

  -- Performs any finalization necessary for the current patch.  This
  -- includes clearing the package state and updating the SQL registry.
  PROCEDURE patch_finalize;

  -- For the current patch and mode under consideration, determines if the
  -- given file should be run or not.  Returns the name of the file to be
  -- run, which will either be the supplied input file (prefixed with
  -- top_directory supplied during initialisze) or
  -- dbms_registry.nothing_script if the file does not need to be run.
  FUNCTION install_file(sql_file IN VARCHAR2)
    RETURN VARCHAR2;

  -- Returns a hash string representing the current state of the SQL
  -- registry (i.e. a list of the BLRs installed successfully or not, and
  -- the current bundle ID for any bundles).  This is used to compare the
  -- SQL registry upon PDB plug in
  FUNCTION sql_registry_state RETURN XMLType;

  -- Performs session initialization.  Must be called before patch_initialize
  PROCEDURE session_initialize(p_oh IN VARCHAR2,
                               p_force IN BOOLEAN := FALSE,
                               p_debug IN BOOLEAN := FALSE);

  -- Tests the queryable inventory functionality.
  -- If QI is working properly, then the string 'OK' is returned, otherwise
  -- any errors are returned.
  FUNCTION verify_queryable_inventory RETURN VARCHAR2;
END dbms_sqlpatch;
/

CREATE OR REPLACE PUBLIC SYNONYM dbms_sqlpatch FOR sys.dbms_sqlpatch;

GRANT EXECUTE ON dbms_sqlpatch TO execute_catalog_role;

@?/rdbms/admin/sqlsessend.sql
