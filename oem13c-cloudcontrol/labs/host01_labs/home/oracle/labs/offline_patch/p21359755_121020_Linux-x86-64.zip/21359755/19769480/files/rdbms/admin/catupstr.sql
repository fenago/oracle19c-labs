Rem
Rem $Header: rdbms/admin/catupstr.sql /st_rdbms_12.1.0.2.0dbpsu/1 2014/10/18 15:52:40 apfwkr Exp $
Rem
Rem catupstr.sql
Rem
Rem Copyright (c) 2006, 2014, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catupstr.sql - CATalog UPgrade STaRt script
Rem
Rem    DESCRIPTION
Rem      This script performs the initial checks for upgrade
Rem      (open for UPGRADE, AS SYSDBA, etc.) and then runs
Rem      the "i" scripts, utlip.sql, and the "c" scripts
Rem      to complete the basic RDBMS upgrade
Rem
Rem    NOTES
Rem      Invoked from catupgrd.sql
Rem
Rem     *WARNING*   *WARNING*  *WARNING*  *WARNING*  *WARNING*  *WARNING*
Rem
Rem      set serveroutput must be set to off before
Rem      invoking utlip.sql script otherwise deadlocks
Rem      and internal errors may result.
Rem
Rem     *WARNING*   *WARNING*  *WARNING*  *WARNING*  *WARNING*  *WARNING*
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    apfwkr      10/09/14 - Backport
Rem                           apfwkr_ci_backport_18791688_12.1.0.2.2dbbp from
Rem                           st_rdbms_12.1.0.2.0dbbp
Rem    apfwkr      09/19/14 - Backport cdilling_bug-18791688 from
Rem                           st_rdbms_12.1.0.2.0dbpsu
Rem    cdilling    09/15/14 - bug 18791688 - check for existence of pdb_alert$
Rem                           as part of @utlip check
Rem    cmlim       05/25/14 - lrg 12025320: roll back latest time zone file
Rem                           version in 12102 to 18 (from 21)
Rem    apfwkr      05/09/14 - Backport rdecker_bug-18507841 from st_rdbms_12.1
Rem    apfwkr      04/30/14 - Backport cmlim_bug-18555439 from main
Rem    rdecker     04/29/14 - bug 18507841 - recomp packages with stale TOIDs
Rem    apfwkr      04/21/14 - Backport cmlim_bug-18589266 from main
Rem    cmlim       04/25/14 - bug 18555439: if this is a non-cdb, seed, or pdb,
Rem                           then terminate upgrade if MAX_STRING_SIZE=EXTENDED
Rem                           but utl32k.sql had not completed yet
Rem    cmlim       04/15/14 - bug 18589266: to see if new users/roles were
Rem                           created in 12c, check oracle-supplied bit
Rem    jaeblee     02/21/14 - 18056941: for CDB, run i1201000.sql instead of 
Rem                           i1002000.sql
Rem    cmlim       11/26/13 - lrg 10260355: latest time zone file version for
Rem                           12102 is 21
Rem    jerrede     11/14/13 - Add summary table for DBUA
Rem    jerrede     11/12/13 - Add DBUA Summary Table.
Rem    cechen      10/17/13 - Bug 16561577: handle GDS users and roles
Rem    kyagoub     09/12/13 - bug16561082: handle EM_EXPRESS_ALL and
Rem                           EM_EXPRESS_BASIC
Rem    cdilling    09/07/13 - Bug 17404281: make sys.enabled$indexes a local table
Rem    cmlim       07/05/13 - lrg 8816946: update time zone file version to 20
                              in 12.1.0.2 in 'time zone check 3' below.
Rem    cdilling    04/03/13 - only run ultip for major release upgrades, not
Rem                           patch upgrades
Rem    jibyun      03/28/13 - Bug 16567861: throw an error if the following
Rem                           users/roles already exist: SYSBACKUP, SYSDG,
Rem                           SYSKM, capture_admin 
Rem    yiru        03/28/13 - Bug 16561033: Add query to check the existence
Rem                           of RAS reserved roles
Rem    vpriyans    03/26/13 - Bug 16552266: modify query to check the existence
Rem                           of audit admins
Rem    cmlim       03/01/13 - XbranchMerge cmlim_bug-16085743 from
Rem                           st_rdbms_12.1.0.1
Rem    aramappa    02/19/13 - bug 16317592 - Remove PREUPG_AUD$ check
Rem    jerrede     02/04/13 - Upgrade Support for CDB
Rem    cdilling    01/17/13 - version to 12.1.0.2
Rem    cmlim       01/09/13 - comment: fix INVALID_TABLEDATA error in old OH
Rem    bmccarth    12/05/12 - check for invalid table data - 7174392
Rem                         - remove unsupported prior version checks
Rem                         - Fix use of dual
Rem    jerrede     11/08/12 - Make sure set serverouput is off Lrg 8473773
Rem    brwolf      10/22/12 - enable editioning for public synonyms
Rem    cmlim       10/16/12 - "_ORACLE_SCRIPT"=true set is missing at begin of
Rem                           catupstr.sql
Rem    amunnoli    10/05/12 - Bug 14727837:Fix AUDSYS query to work 
Rem                           for non-english locale
Rem    amunnoli    09/14/12 - Bug 14560783:Throw error on upgrade if AUDSYS,
Rem                           AUDIT_ADMIN(/VIEWER) exists in the source DB
Rem    aramappa    08/30/12 - bug 14555249: fix olspreupgrade query to work for
Rem                           non-english locale
Rem    cdilling    08/29/12 - version to 12.1.0.1.0
Rem    cdilling    08/29/12 - version to 12.1.0.1.0
Rem    cdilling    08/20/12 - add 10205 to check for olspreupgrade
Rem    bmccarth    07/10/12 - tz to 18
Rem    traney      07/09/12 - bug 12915774: mark sys objects noneditionable
Rem    srtata      03/09/12 - bug 13779729 : add checks for OLS pre-upgrade
Rem    jerrede     12/21/11 - Make Parallel Upgrade the Default
Rem    jerrede     12/12/11 - Display Version Info
Rem    cdilling    11/16/11 - run @i1002000.sql rather than @i090200.sql
Rem    jerrede     10/28/11 - Fix Bug 13252372
Rem    cmlim       10/26/11 - update_tzv_17: change time zone file version from
Rem                           16 to 17
Rem    cdilling    10/13/11 - check direct upgrade versions for 12.1
Rem    yanchuan    10/11/11 - Bug 12776828: admin procedure name changes
Rem    cmlim       10/04/11 - update_tzv_16: change utlu_tz_version from 15 to
Rem                           16
Rem    cmlim       09/16/11 - olsdv upgrade: updated checks to dv-not-enabled
Rem                           and ols-not-installed
Rem    cmlim       11/11/09 - change the timezone check from 8 to 11
Rem    jerrede     09/01/11 - Parallel Upgrade Project #23496
Rem    brwolf      08/31/11 - 32733: finer-grained editioning
Rem    cmlim       04/17/11 - bug 12363704: update time zone check in
Rem                           catupstr.sql that will work for re-upgrades
Rem                         - update time zone file version from 14 to 15
Rem    traney      04/05/11 - 35209: long identifiers dictionary upgrade
Rem    cdilling    02/17/11 - invoke utlip for upgrade to 12.1
Rem    cdilling    02/12/11 - bug 10373381: check instance to the 4th digit
Rem    cmlim       12/14/10 - bug 10400001: check that 112 oracle has DV off
Rem                           prior to upgrade
Rem    bmccarth    08/13/10 - version_script update for 12.1
Rem    cdilling    08/04/10 - add support for 12.1 instance version
Rem    cmlim       06/21/10 - update_tzv14: 11202 is now at time zone file v14
Rem    cmlim       04/26/10 - bug 9546509; suggest to force a checkpoint prior
Rem                           to shutdown abort in instructions
Rem    cdilling    03/12/10 - abort upgrade if invalid conditions for editions
Rem                           - bug 9454506
Rem    cmlim       02/01/10 - 11202 is now at time zone file version 13
Rem    cdilling    06/01/09 - check for supported upgrade versions
Rem    cdilling    05/26/09 - for PSU check only 5 digits for version
Rem    cmlim       01/16/09 - bug 7496789: update check on when DV needs to be
Rem                           relinked off
Rem    cmlim       12/19/08 - timezone_b7193417-c: rewrite timezone check
Rem    cmlim       12/12/08 - timezone_b7193417-b: if old OH has newer timezone
Rem                           version than 8, abort if new OH is not patched
Rem    rlong       09/25/08 - 
Rem    cmlim       07/24/08 - bug 7193417: support timezone file version
Rem                           changes in 11.2
Rem    awitkows    03/30/08 - DST. repl registry with props
Rem    rburns      11/11/07 - XbranchMerge rburns_bug-6446262 from
Rem                           st_rdbms_project-18813
Rem    rburns      11/08/07 - check for INVALID old versions of types
Rem    jciminsk    10/22/07 - Upgrade support for 11.2
Rem    cdilling    10/09/07 - update version to 11.2
Rem    cdilling    08/23/07 - check disabled indexes only
Rem    rburns      07/16/07 - add 11.1 patch upgrade
Rem    rburns      05/29/07 - add timezone version check
Rem    rburns      05/01/07 - reload dbms_assert
Rem    rburns      03/10/07 - add DV and OLS check
Rem    cdilling    02/19/07 - add sys.enabled$indexes table for bug 5530085
Rem    dvoss       02/19/07 - Check bootstrap migration status
Rem    rburns      10/23/06 - add session script
Rem    rburns      08/14/06 - add RDBMS identifier
Rem    cdilling    06/08/06 - add error logging table
Rem    gviswana    06/07/06 - Enable 4523571 fix 
Rem    rburns      05/22/06 - parallel upgrade 
Rem    rburns      05/22/06 - Created
Rem

Rem =====================================================================
Rem Exit immediately if there are errors in the initial checks
Rem =====================================================================

WHENEVER SQLERROR EXIT;        


Rem Set session initializations by invoking catpses.sql directly.
Rem This script will set session variable "_ORACLE_SCRIPT" to TRUE.
@@catpses.sql


DOC 
######################################################################
######################################################################
    The following statement will cause an "ORA-01722: invalid number"
    error if the user running this script is not SYS.  Disconnect
    and reconnect with AS SYSDBA.
######################################################################
######################################################################
#

SELECT TO_NUMBER('MUST_BE_AS_SYSDBA') FROM SYS.DUAL
WHERE USER != 'SYS';

DOC
######################################################################
######################################################################
    The following statement will cause an "ORA-01722: invalid number"
    error if the database server version is not correct for this script.
    Perform "ALTER SYSTEM CHECKPOINT" prior to "SHUTDOWN ABORT", and use
    a different script or a different server.
######################################################################
######################################################################
#

SELECT TO_NUMBER('MUST_BE_12_1_0_2') FROM v$instance
WHERE substr(version,1,8) != '12.1.0.2';

DOC
#######################################################################
#######################################################################
   The following statement will cause an "ORA-01722: invalid number"
   error if the database has not been opened for UPGRADE.  

   Perform "ALTER SYSTEM CHECKPOINT" prior to "SHUTDOWN ABORT",  and 
   restart using UPGRADE.
#######################################################################
#######################################################################
#

SELECT TO_NUMBER('MUST_BE_OPEN_UPGRADE') FROM v$instance
WHERE status != 'OPEN MIGRATE';

DOC
#######################################################################
#######################################################################
     The following statement will cause an "ORA-01722: invalid number"
     error if Oracle Database Vault is enabled in the database.
     Oracle Database Vault cannot be enabled while the database is
     upgrading since administrative actions may not be permitted.

     To disable Database Vault in this database, log in as Database
     Vault administrator and run this operation
     "DVSYS.DBMS_MACADM.DISABLE_DV()".  Then restart the server
     in UPGRADE mode to continue the database upgrade.
#######################################################################
#######################################################################
#

SELECT TO_NUMBER('DATABASE_VAULT_ENABLED') FROM v$option
 WHERE
  value = 'TRUE' and parameter = 'Oracle Database Vault';

DOC
#######################################################################
#######################################################################
   The following statement will cause an "ORA-01722: invalid number"
   error if Oracle Database Vault is installed but
   Oracle Label Security is not.  To successfully upgrade Oracle
   Database Vault, both Database Vault and Label Security must be
   installed.

   Install Oracle Label Security in this database before continuing
   the database upgrade.
#######################################################################
#######################################################################
#

SELECT TO_NUMBER('LABEL_SECURITY_NOT_INSTALLED') FROM SYS.DUAL
WHERE (SELECT COUNT(*) FROM user$ where name = 'LBACSYS') = 0 and
      (SELECT COUNT(*) FROM user$ where name = 'DVSYS') = 1;

DOC
#######################################################################
#######################################################################
   The following statement will cause an "ORA-01722: invalid number"
   error if bootstrap migration is in progress and logminer clients
   require utlmmig.sql to be run next to support this redo stream.

   Run utlmmig.sql
   then (if needed) 
   restart the database using UPGRADE and
   rerun the upgrade script.
#######################################################################
#######################################################################
#

SELECT TO_NUMBER('MUST_RUN_UTLMMIG.SQL')
    FROM SYS.V$DATABASE V
    WHERE V.LOG_MODE = 'ARCHIVELOG' and
          V.SUPPLEMENTAL_LOG_DATA_MIN != 'NO' and
          exists (select 1 from sys.props$
                  where name = 'LOGMNR_BOOTSTRAP_UPGRADE_ERROR');


DOC
#######################################################################
#######################################################################
   The following error is generated if the pre-upgrade tool has not been
   run in the old ORACLE_HOME home prior to upgrading a pre-11.2 database: 

   SELECT TO_NUMBER('MUST_HAVE_RUN_PRE-UPGRADE_TOOL_FOR_TIMEZONE')
                       *
      ERROR at line 1:
      ORA-01722: invalid number

     o Action:
       Shutdown database ("alter system checkpoint" and then "shutdown abort").
       Revert to the original oracle home and start the database.
       Run pre-upgrade tool against the database.
       Review and take appropriate actions based on the pre-upgrade
       output before opening the datatabase in the new software version.
    
#######################################################################
#######################################################################
#
Rem time zone check 1
Rem   SELECT TO_NUMBER('MUST_HAVE_RUN_PRE-UPGRADE_TOOL_FOR_TIMEZONE')

Rem Assure CHAR semantics are not used in the dictionary
ALTER SESSION SET NLS_LENGTH_SEMANTICS=BYTE;

Rem To keep the check simple and avoid multiple errors - in upgrade mode,
Rem create registry$database and add tz_version in case the table
Rem and/or column do not exist.
CREATE TABLE registry$database
               (platform_id NUMBER, platform_name VARCHAR2(101),
                edition VARCHAR2(30), tz_version NUMBER);
ALTER TABLE registry$database add (tz_version number);

Rem Check if tz_version was populated if the db is pre-11.2
SELECT TO_NUMBER('MUST_HAVE_RUN_PRE-UPGRADE_TOOL_FOR_TIMEZONE')
   FROM sys.props$
   WHERE
     (
       (
        (0 = (select count(*) from registry$database))
        OR
        ((SELECT tz_version from registry$database) is null)
       )
       AND
       (
        ((SELECT substr(version,1,4) FROM registry$ where cid = 'CATPROC') =
          '10.2') OR
        ((SELECT substr(version,1,4) FROM registry$ where cid = 'CATPROC') =
          '11.1')
       )
     );


DOC
#######################################################################
#######################################################################
   The following error is generated if the pre-upgrade tool has not been
   run in the old oracle home prior to upgrading a pre-11.2 database:

      SELECT TO_NUMBER('MUST_BE_SAME_TIMEZONE_FILE_VERSION')
                       *
      ERROR at line 1:
      ORA-01722: invalid number

     o Action:
       Shutdown database ("alter system checkpoint" and then "shutdown abort").
       Revert to the original ORACLE_HOME and start the database.
       Run pre-upgrade tool against the database.
       Review and take appropriate actions based on the pre-upgrade
       output before opening the datatabase in the new software version.

#######################################################################
#######################################################################
#
Rem time zone check 2
Rem   SELECT TO_NUMBER('MUST_BE_SAME_TIMEZONE_FILE_VERSION')

Rem Check if sys.props$ was populated if the db is pre-11.2
SELECT TO_NUMBER('MUST_BE_SAME_TIMEZONE_FILE_VERSION')
   FROM sys.props$
   WHERE
     (
      ((SELECT TO_NUMBER(value$) from sys.props$
         WHERE name = 'DST_PRIMARY_TT_VERSION') !=
       (SELECT tz_version from registry$database))
      AND
       (((SELECT substr(version,1,4) FROM registry$ where cid = 'CATPROC') =
         '10.2') OR
       ((SELECT substr(version,1,4) FROM registry$ where cid = 'CATPROC') =
         '11.1'))
     );


DOC
#######################################################################
#######################################################################
   The following error is generated if (1) the old release uses a time
   zone file version newer than the one shipped with the new oracle
   release and (2) the new oracle home has not been patched yet:

      SELECT TO_NUMBER('MUST_PATCH_TIMEZONE_FILE_VERSION_ON_NEW_ORACLE_HOME')
                       *
      ERROR at line 1:
      ORA-01722: invalid number

     o Action:
       Shutdown database ("alter system checkpoint" and then "shutdown abort").
       Patch new ORACLE_HOME to the same time zone file version as used
       in the old ORACLE_HOME.

#######################################################################
#######################################################################
#
Rem time zone check 3
Rem   SELECT TO_NUMBER('MUST_PATCH_TIMEZONE_FILE_VERSION_ON_NEW_ORACLE_HOME')

Rem Check if time zone file version used by the database exists in new home
SELECT TO_NUMBER('MUST_PATCH_TIMEZONE_FILE_VERSION_ON_NEW_ORACLE_HOME')
   FROM sys.props$
   WHERE
     (
      (name = 'DST_PRIMARY_TT_VERSION' AND TO_NUMBER(value$) > 18)
      AND
      (0 = (select count(*) from v$timezone_file))
     );


DOC 
#######################################################################
#######################################################################
    The following statements will cause an "ORA-01722: invalid number"
    error if the SYSAUX tablespace does not exist or is not
    ONLINE for READ WRITE, PERMANENT, EXTENT MANAGEMENT LOCAL, and
    SEGMENT SPACE MANAGEMENT AUTO.
 
    The SYSAUX tablespace is used in 10.1 to consolidate data from
    a number of tablespaces that were separate in prior releases. 
    Consult the Oracle Database Upgrade Guide for sizing estimates.

    Create the SYSAUX tablespace, for example,

     create tablespace SYSAUX datafile 'sysaux01.dbf' 
         size 70M reuse 
         extent management local 
         segment space management auto 
         online;

    Then rerun the upgrade script.
#######################################################################
#######################################################################
#

SELECT TO_NUMBER('No SYSAUX tablespace') FROM dual 
WHERE 'SYSAUX' NOT IN (SELECT name from ts$);

SELECT TO_NUMBER('Not ONLINE for READ/WRITE') from ts$
WHERE name='SYSAUX' AND online$ !=1;

SELECT TO_NUMBER ('Not PERMANENT') from ts$
WHERE name='SYSAUX' AND 
      (contents$ !=0 or (contents$ = 0 AND bitand(flags, 16)= 16));

SELECT TO_NUMBER ('Not LOCAL extent management') from ts$
WHERE name='SYSAUX' AND bitmapped = 0;

SELECT TO_NUMBER ('Not AUTO segment space management') from ts$
WHERE name='SYSAUX' AND bitand(flags,32) != 32;

DOC
#######################################################################
#######################################################################
     The following statement will cause an "ORA-01722: invalid number"
     error, if a user or role with the name AUDSYS or AUDIT_ADMIN or 
     AUDIT_VIEWER is found in the database. 
     AUDSYS is an Oracle supplied user in 12.1 and AUDIT_ADMIN, AUDIT_VIEWER 
     are Oracle supplied roles in 12.1. Hence, these existing user or role 
     names found in the database must be dropped before upgrading.
     Please move the contents if any, from AUDSYS schema to a different schema.

     To drop the user 'AUDSYS' in this database, log in as SYS
     and run this operation
     "DROP USER AUDSYS CASCADE". 
     To drop the role 'AUDIT_ADMIN' in this database, log in as SYS
     and run this operation
     "DROP ROLE AUDIT_ADMIN".
     To drop the role 'AUDIT_VIEWER' in this database, log in as SYS
     and run this operation
     "DROP ROLE AUDIT_VIEWER".
#######################################################################
#######################################################################
#

Rem Bug 18589266: include filter to check if users/roles are oracle-supplied

SELECT TO_NUMBER('AUDIT_ADMINS_ARE_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name in ('AUDSYS', 'AUDIT_ADMIN', 'AUDIT_VIEWER')
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM sys.registry$ where
       cid = 'CATPROC') < '12.1' ;

DOC
#######################################################################
#######################################################################
     The following statement will cause an "ORA-01722: invalid number"
     error if a user/role with the name PROVISIONER, XS_RESOURCE, 
     XS_SESSION_ADMIN, XS_NAMESPACE_ADMIN, XS_CACHE_ADMIN is found in the 
     database.

     PROVISIONER, XS_RESOURCE, XS_SESSION_ADMIN, XS_NAMESPACE_ADMIN,
     XS_CACHE_ADMIN are Oracle supplied roles in 12.1. Hence, these existing 
     user or role names found in the database must be dropped before 
     upgrading.

     Please move the contents in the existing schemas to different schemas,
     if necessary, before dropping these schemas. The fixup needs to be
     done in the original Oracle home.

     Shutdown database ("alter system checkpoint" and then "shutdown abort").
     Revert to the original oracle home and start the database.
     Move the contents in the conflicting schemas as needed.
     Drop the conflicting users/roles.
     Revert to the new oracle home and restart the database in UPGRADE mode.
     Continue the database upgrade.

     Note - the following drops require execution as SYS:
     To drop role 'PROVISIONER'         - "DROP ROLE PROVISIONER".
     To drop role 'XS_RESOURCE'         - "DROP ROLE XS_RESOURCE".
     To drop role 'XS_SESSION_ADMIN'    - "DROP ROLE XS_SESSION_ADMIN".
     To drop role 'XS_NAMESPACE_ADMIN'  - "DROP ROLE XS_NAMESPACE_ADMIN".
     To drop role 'XS_CACHE_ADMIN'      - "DROP ROLE XS_CACHE_ADMIN".
#######################################################################
#######################################################################
#

Rem Bug 18589266: include filter to check if users/roles are oracle-supplied

SELECT TO_NUMBER('RAS_RESERVED_ROLES_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name in ('PROVISIONER', 'XS_RESOURCE', 'XS_SESSION_ADMIN',
                 'XS_NAMESPACE_ADMIN', 'XS_CACHE_ADMIN')
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM registry$ where
       cid = 'CATPROC') < '12.1' ;

DOC
#######################################################################
#######################################################################
     The following statement will cause an "ORA-01722: invalid number"
     error, if a user or role with the name SYSBACKUP, SYSDG, SYSKM, or
     CAPTURE_ADMIN is found in the database.

     SYSBACKUP, SYSDG, and SYSKM are Oracle supplied users in 12.1, and 
     CAPTURE_ADMIN is Oracle supplied role in 12.1. Hence, these 
     existing user or role names found in the database must be dropped
     before upgrading. 

     Please move the contents in the existing schemas to different schemas,
     if necessary, before dropping these schemas. The fixup needs to be
     done in the original Oracle home.

     Shutdown database ("alter system checkpoint" and then "shutdown abort").
     Revert to the original oracle home and start the database.
     Move the contents in the conflicting schemas as needed.
     Drop the conflicting users/roles.
     Revert to the new oracle home and restart the database in UPGRADE mode.
     Continue the database upgrade.

     Note - the following drops require execution as SYS:
     To drop user 'SYSBACKUP'      - "DROP USER SYSBACKUP CASCADE".
     To drop user 'SYSDG'          - "DROP USER SYSDG CASCADE".
     To drop user 'SYSKM'          - "DROP USER SYSKM CASCADE".
     To drop role 'CAPTURE_ADMIN'  - "DROP ROLE CAPTURE_ADMIN".
#######################################################################
#######################################################################
#

Rem Bug 18589266: include filter to check if users/roles are oracle-supplied

SELECT TO_NUMBER('SOD_USERS_ARE_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name in ('SYSBACKUP', 'SYSDG', 'SYSKM')
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM registry$ where
       cid = 'CATPROC') < '12.1';

SELECT TO_NUMBER('CAPTURE_ADMIN_IS_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name = 'CAPTURE_ADMIN'
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM registry$ where
       cid = 'CATPROC') < '12.1';

DOC
#######################################################################
#######################################################################
     The following statement will cause an "ORA-01722: invalid number"
     error if a user/role with the name EM_EXPRESS_BASIC or 
     EM_EXPRESS_ALL is found in the database.

     EM_EXPRESS_BASIC and EM_EXPRESS_ALL are Oracle supplied roles 
     in 12.1. Hence, these existing user or role names found in 
     the database must be dropped before upgrading.

     Please move the contents in the existing schemas to different schemas,
     if necessary, before dropping these schemas. The fixup needs to be
     done in the original Oracle home.

     Shutdown database ("alter system checkpoint" and then "shutdown abort").
     Revert to the original oracle home and start the database.
     Move the contents in the conflicting schemas as needed.
     Drop the conflicting users/roles.
     Revert to the new oracle home and restart the database in UPGRADE mode.
     Continue the database upgrade.

     Note - the following drops require execution as SYS:
     To drop role 'EM_EXPRESS_BASIC' - "DROP ROLE EM_EXPRESS_BASIC".
     To drop role 'EM_EXPRESS_ALL'   - "DROP ROLE EM_EXPRESS_ALL".

#######################################################################
#######################################################################
#

Rem Bug 18589266: include filter to check if users/roles are oracle-supplied

SELECT TO_NUMBER('EM_EXPRESS_RESERVED_ROLES_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name in ('EM_EXPRESS_BASIC', 'EM_EXPRESS_ALL')
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM registry$ where
       cid = 'CATPROC') < '12.1' ;

DOC
#######################################################################
#######################################################################
     The following statement will cause an "ORA-01722: invalid number"
     error, if a user or role with the name GSMCATUSER, GSMUSER, 
     GSMADMIN_INTERNAL or GSMUSER_ROLE, GSM_POOLADMIN_ROLE, GSMADMIN_ROLE, 
     GDS_CATALOG_SELECT is found in the database.

     GSMCATUSER, GSMUSER and GSMADMIN_INTERNAL are Oracle supplied users in 
     12.1, and GSMUSER_ROLE, GSM_POOLADMIN_ROLE, GSMADMIN_ROLE, 
     GDS_CATALOG_SELECT is Oracle supplied role in 12.1. Hence, these 
     existing user or role names found in the database must be dropped
     before upgrading. 

     Please move the contents in the existing schemas to different schemas,
     if necessary, before dropping these schemas. The fixup needs to be
     done in the original Oracle home.

     Shutdown database ("alter system checkpoint" and then "shutdown abort").
     Revert to the original oracle home and start the database.
     Move the contents in the conflicting schemas as needed.
     Drop the conflicting users/roles.
     Revert to the new oracle home and restart the database in UPGRADE mode.
     Continue the database upgrade.

     Note - the following drops require execution as SYS:
     To drop user 'GSMCATUSER'     - "DROP USER GSMCATUSER CASCADE".
     To drop user 'GSMUSER'        - "DROP USER GSMUSER CASCADE".
     To drop user 'GSMADMIN_INTERNAL' - "DROP USER GSMADMIN_INTERNAL CASCADE".
     To drop role 'GSMUSER_ROLE'         - "DROP ROLE GSMUSER_ROLE".
     To drop role 'GSM_POOLADMIN_ROLE'   - "DROP ROLE GSM_POOLADMIN_ROLE".
     To drop role 'GSMADMIN_ROLE'        - "DROP ROLE GSMADMIN_ROLE".
     To drop role 'GDS_CATALOG_SELECT'   - "DROP ROLE GDS_CATALOG_SELECT".
#######################################################################
#######################################################################
#

Rem Bug 18589266: include filter to check if users/roles are oracle-supplied

SELECT TO_NUMBER('GDS_USERS_ARE_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name in ('GSMCATUSER', 'GSMUSER', 'GSMADMIN_INTERNAL')
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM registry$ where
       cid = 'CATPROC') < '12.1';

SELECT TO_NUMBER('GDS_ROLES_ARE_FOUND') FROM SYS.DUAL
WHERE (select count(*) from sys.user$ WHERE
        name in ('GSMUSER_ROLE', 'GSM_POOLADMIN_ROLE', 'GSMADMIN_ROLE',
        'GDS_CATALOG_SELECT')
        AND bitand(spare1, 256) != 256) > 0 AND
      (select SUBSTR(version,1,4) FROM registry$ where
       cid = 'CATPROC') < '12.1';

DOC
#######################################################################
#######################################################################

     The following statement will cause an "ORA-01722: invalid number"
     error, if the database contains invalid data as a result of type
     evolution which was performed without the data being converted.
     
     To resolve this specific "ORA-01722: invalid number" error:
       Shutdown database ("alter system checkpoint" and then "shutdown abort").
       Perform the data conversion (details below) in the old ORACLE_HOME.

     Please refer to Oracle Database Object-Relational Developer's Guide
     for more information about type evolution.

     Data in columns of evolved types must be converted before the
     database can be upgraded. 

     This data can be converted at any time prior to the upgrade (the
     conversion does not need to be performed directly before the
     upgrade). The data conversion process can be time consuming.

     The following commands will perform the data conversion for Oracle
     supplied data:

     @?/rdbms/admin/utluppkg.sql
     SET SERVEROUTPUT ON;
     exec dbms_preup.run_fixup_and_report('INVALID_SYS_TABLEDATA');
     SET SERVEROUTPUT OFF;

     You should then confirm that any non-Oracle supplied data is also
     converted.  You should review the data and determine if it needs
     to be converted or removed. 

     To view the data which is affected by type evolution, execute the following:

     SELECT rpad(u.name,128) TABLENAME, rpad(o.name,128) OWNER,
       rpad(c.name,128) COLNAME FROM SYS.OBJ$ o, SYS.COL$ c, SYS.COLTYPE$ t,
         SYS.USER$ u
         WHERE o.OBJ# = t.OBJ# AND c.OBJ# = t.OBJ# AND c.COL# = t.COL#
           AND t.INTCOL# = c.INTCOL# AND BITAND(t.FLAGS, 256) = 256
           AND o.OWNER# = u.USER# AND o.OWNER# NOT IN
            (SELECT UNIQUE (d.USER_ID) FROM SYS.DBA_USERS d, SYS.REGISTRY$ r
               WHERE d.USER_ID = r.SCHEMA# and r.NAMESPACE='SERVER');

     Once the data is confirmed, the following commands will convert the
     the data returned by the above query.

     @?/rdbms/admin/utluppkg.sql
     SET SERVEROUTPUT ON;
     exec dbms_preup.run_fixup_and_report('INVALID_USR_TABLEDATA');
     SET SERVEROUTPUT OFF;

     Depending on the amount of data involved, converting the evolved type
     data can take a significant amount of time.

#######################################################################
#######################################################################
#

SELECT TO_NUMBER('INVALID_TABLEDATA') FROM SYS.DUAL
WHERE (SELECT COUNT(*) FROM SYS.OBJ$ o, SYS.COL$ c, SYS.COLTYPE$ t
         WHERE o.OBJ# = t.OBJ# AND c.OBJ# = t.OBJ# AND c.COL# = t.COL# 
           AND t.INTCOL# = c.INTCOL# AND BITAND(t.FLAGS, 256) = 256 
       ) > 0;


DOC
#######################################################################
#######################################################################
   The following error is generated if initialization parameter
   MAX_STRING_SIZE is set to 'EXTENDED' but the 32k migration (or
   rdbms/admin/utl32k.sql) had not completed yet.

   SELECT TO_NUMBER('32K_MIGRATION_NOT_COMPLETED')
                    *
      ERROR at line 1:
      ORA-01722: invalid number

   Database upgrade will terminate on this error.

   o Cause:
     a) MAX_STRING_SIZE initialization parameter is set to
        EXTENDED but 32K migration had not completed.

     b) Database upgrade does not run rdbms/admin/utl32k.sql.

   o Action:
     Since database upgrade had already started, let's wait until
     it is done before user completes 32K migration.

     a) To resume database upgrade:
        Reset initialization parameter MAX_STRING_SIZE to 'STANDARD',
        restart database in UPGRADE mode,
        and rerun database upgrade.

     b) To complete 32K migration after database had been upgraded:
        Set initialization parameter MAX_STRING_SIZE to 'EXTENDED',
        restart database in UPGRADE mode,
        and run rdbms/admin/utl32k.sql.

#######################################################################
#######################################################################
#

Rem
Rem Bug 18555439
Rem Terminate upgrade if the following conditions are TRUE:
Rem a) if database is a non-CDB, PDB$SEED, or PDB
Rem (note: root, with con id of 1, is not included in the check
Rem        because utl32k.sql doesn't change props$ value for root)
Rem AND
Rem b) initialization parameter MAX_STRING_SIZE is at 'EXTENDED'
Rem AND
Rem c) MAX_STRING_SIZE in sys.props$ is not at 'EXTENDED'
Rem (note: we only care about the 'EXTENDED' value as this is the
Rem        value set at end of utl32k.sql)
Rem

SELECT TO_NUMBER('32K_MIGRATION_NOT_COMPLETED')
FROM sys.props$
WHERE
  ((select con_id from sys.v$containers) <> 1)
  AND
  ((select upper(value) from sys.v$parameter where upper(name)
      = 'MAX_STRING_SIZE') = upper('EXTENDED'))
  AND
  ((select upper(value$) from sys.props$ where upper(name)
     = 'MAX_STRING_SIZE') <> upper('EXTENDED'));


Rem =====================================================================
Rem Assure CHAR semantics are not used in the dictionary
Rem =====================================================================

ALTER SESSION SET NLS_LENGTH_SEMANTICS=BYTE;

Rem =====================================================================
Rem Continue even if there are SQL errors in remainder of script
Rem =====================================================================

WHENEVER SQLERROR CONTINUE;  

Rem
Rem Bug 5530085
Rem
Rem Poplulate sys.enabled_indexes table with the list of function-based 
Rem indexes that are currently not 'disabled'. This schema/index name list 
Rem will be later used in utlrp.sql to enable indexes in the list that may 
Rem have become disabled. 
Rem
CREATE TABLE sys.enabled$indexes sharing=none ( schemaname, indexname, objnum )
AS select u.name, o1.name, i.obj# from user$ u, obj$ o1, obj$ o2, ind$ i
    where
        u.user# = o1.owner# and o1.type# = 1 and o1.obj# = i.obj#
       and bitand(i.property, 16)= 16 and bitand(i.flags, 1024)=0
       and i.bo# = o2.obj# and bitand(o2.flags, 2)=0;



Rem
Rem Create error logging table
Rem
CREATE TABLE sys.registry$error(username   VARCHAR(256),
                                timestamp  TIMESTAMP,
                                script     VARCHAR(1024),
                                identifier VARCHAR(256),
                                message    CLOB,
                                statement  CLOB);
                                         
DELETE FROM sys.registry$error;
commit;

Rem
Rem Run Session initialization scripts
Rem error logging table must exist
Rem
@@catupses.sql
@@catalogses.sql

Rem
Rem Summary progress of the upgrade used by DBUA
Rem
Rem Create DBUA Summary table in the ROOT only
Rem PDB's are object linked to the table.
Rem

CREATE TABLE sys.registry$upg_summary
                (con_id      NUMBER,          /* Con id */
                 con_name    VARCHAR2(128),   /* Container Name */
                 cid         VARCHAR2(30),    /* Component id */
                 progress    VARCHAR2(1024),  /* DBUA Timestamp progress */
                 errcnt      NUMBER,          /* Error Count */
                 starttime   TIMESTAMP,       /* Start of phase time */
                 endtime     TIMESTAMP,       /* End of phase time */
                 reportname  VARCHAR2(2000)   /* Summary Report Name */
                );
Rem
Rem Remove existing data
Rem
DELETE FROM sys.registry$upg_summary;

--
-- Insert into upgrade summary table 
--
INSERT INTO sys.registry$upg_summary (con_id,
                                      con_name,
                                      cid,
                                      progress,
                                      errcnt,
                                      starttime,
                                      endtime,
                                      reportname)
VALUES (-1,
        'REPORT',
        'REPORT',
        'REPORT',
        0,
        SYSDATE,
        SYSDATE,
        'Report not run');
COMMIT;


Rem
Rem Pre-create log to record upgrade operations and errors
Rem

CREATE TABLE registry$log (
             cid         VARCHAR2(128),              /* component identifier */
             namespace   VARCHAR2(128),               /* component namespace */
             operation   NUMBER NOT NULL,              /* current operation */
             optime      TIMESTAMP,                  /* operation timestamp */
             errmsg      varchar2(1000)         /* ORA error message number */
             );
Rem Clear log entries if the table already exists
DELETE FROM registry$log;

Rem put timestamps into spool log and registry$log
INSERT INTO registry$log (cid, namespace, operation, optime)
       VALUES ('UPGRD_BGN','SERVER',-1,SYSTIMESTAMP);
COMMIT;
SELECT 'COMP_TIMESTAMP UPGRD__BGN ' || 
        TO_CHAR(SYSTIMESTAMP,'YYYY-MM-DD HH24:MI:SS ')  || 
        TO_CHAR(SYSTIMESTAMP,'J SSSSS ')
        AS timestamp FROM SYS.DUAL;

--
--   Display Version Info from registry$
--
SELECT org_version from sys.registry$ where cid = 'CATPROC';
SELECT prv_version from sys.registry$ where cid = 'CATPROC';
SELECT version from sys.registry$ where cid = 'CATPROC';

--
-- NOTE: DBUA_TIMESTAMP is sorted by catctl.pl if you change the
-- position of the SYSTIMESTAMP output then you have to change
-- the substr command on the sort in catrpt.pl.
--
SELECT 'DBUA_TIMESTAMP RDBMS      STARTED     ' || 
       TO_CHAR(SYSTIMESTAMP,'YYYY-MM-DD HH24:MI:SS ') from SYS.DUAL;

Rem =====================================================================
Rem BEGIN STAGE 1: load dictionary changes for basic SQL processing
Rem =====================================================================

Rem For non-CDB, run all of the "i" scripts from the earliest supported release
Rem release.  For CDB, we only need to run from 12.1.0.1.

COLUMN i_script NEW_VALUE i_upgrade_file
SELECT decode(cdb,'YES','i1201000.sql','i1002000.sql') i_script
from v$database;

@@&i_upgrade_file

Rem =====================================================================
Rem END STAGE 1: load dictionary changes for basic SQL processing
Rem =====================================================================

Rem =====================================================================
Rem Between stages 1 and 2
Rem =====================================================================

-- Beginning in version 12.1, PUBLIC has editioning enabled for public
-- synonyms.  Because utlip recreates the public synonym for dbms_standard,
-- before utlip can run all existing synonyms in PUBLIC must be marked as
-- non-editionable.  We do that here.

update obj$ set flags = flags + 1048576
  where owner# = 1 and type# in (5,10) and bitand(flags, 1048576) = 0;

-- bug 12915774: Set noneditionable bit for builtin schema objects
update obj$ set flags = (flags - bitand(flags, 1048576) + 1048576)
  where owner# in (select u.user# from registry$ r, user$ u 
    where r.status in (0,1,3,5)
       and r.namespace = 'SERVER'
       and r.schema#   = u.user#
     union all
     select u.user#
     from registry$ r, registry$schemas s, user$ u
     where r.status in (0,1,3,5)
       and r.namespace = 'SERVER'
       and r.cid       = s.cid
       and s.schema#   = u.user#)
  and type# in (4,5,7,8,9,11,12,13,14,22,114);
commit;
alter role "PUBLIC" enable editions for synonym;
alter system flush shared_pool;

Rem =====================================================================
Rem BEGIN STAGE 2: invalidate all non-Java objects
Rem =====================================================================

-- This block of code sets up to run utlip.sql only if the release is
-- prior to 12.1.0.1 or there has been a platform change. 

-- It uses the existence of a new 12.1.0.1 table to determine the need for 
-- utlip.sql.  pdb_alert$ is created in 12.1.0.1 or during the upgrade to  
-- 12.1.0.1 in c1102000.sql and dropped during the downgrade in
-- e1102000.sql.If the table pdb_alert$ exists, then utlip.sql is not needed 
-- unless there is a platform change.

DEFINE utlip_file = 'utlip.sql';
DEFINE utlip_tabcol = NULL;

COLUMN utlip_name NEW_VALUE utlip_file NOPRINT;
COLUMN utlip_tabcolumn NEW_VALUE utlip_tabcol NOPRINT;

SELECT 'nothing.sql' AS utlip_name FROM obj$ 
       WHERE name = 'PDB_ALERT$' and owner#=0;

SELECT platform_id AS utlip_tabcolumn FROM v$database;

SELECT 'SELECT platform_id FROM registry$database' AS utlip_tabcolumn FROM 
obj$ WHERE name = 'REGISTRY$DATABASE';

-- Set utlip_name if the platform identifer in v$database 
-- does not match platform identifier in registry$database
SELECT 'utlip.sql' AS utlip_name FROM v$database
    WHERE v$database.platform_id  
      NOT IN (&&utlip_tabcol);      
--
-- Invalidate all PL/SQL packages
--
@@&utlip_file

-- Bug 18507841 - invalidate packages and their dependents that have 
-- attributes with stale TOIDs.
declare
  p_version      VARCHAR2(30);
  type numtab is table of number;
  tab_t numtab;
begin
  SELECT version INTO p_version FROM registry$ where cid='CATPROC';

  -- Only needed when upgrading from 12.1.0.1
  IF substr(p_version,1,8) = '12.1.0.1' THEN

    -- invalidate top level objects with stale TOIDs and 
    -- "disable fast validation"
    update obj$ set status = 6, flags = flags - bitand(flags, 8192) + 8192
      where obj# in 
        (select o.obj#
           from obj$ o, attribute$ at, type$ t
           where t.package_obj# IS NOT NULL and    -- only package types 
                 t.toid = at.toid and
                 o.obj# = t.package_obj# and
                 at.attr_toid not in (select sys_nc_oid$ from kottd$))
    returning obj# bulk collect into tab_t;

    -- invalidate dependents with status 6
    forall i in 1..tab_t.count
      update obj$ set status = 6 
        where obj# in 
          (select unique(d_obj#) 
             from dependency$ d
             start with d.p_obj# = tab_t(i)
             connect by prior     d.d_obj# = d.p_obj#
                              and (bitand(d.property, 1) = 1));
  end if;
end;
/

-- Bug 6446262, check forINVALID old versions of types and update 
-- any with status = 6
SELECT name, subname, owner#, status FROM obj$
       WHERE type#=13 AND subname IS NOT NULL AND status > 1;
UPDATE obj$ SET status=1 
       WHERE type#=13 AND subname IS NOT NULL AND status=6;
COMMIT;
ALTER SYSTEM FLUSH SHARED_POOL;

-- Reload dbms_assert package for changed interfaces (used in "c" scripts)
@@dbmsasrt.sql
@@prvtasrt.plb

-- Load dbms_registry_simple package for use with "c" scripts
@@dbmscrs.sql
@@prvtcrs.plb

Rem =====================================================================
Rem END STAGE 2: invalidate all non-Java objects
Rem =====================================================================

Rem =====================================================================
Rem BEGIN STAGE 3: dictionary upgrade
Rem =====================================================================

WHENEVER SQLERROR EXIT

Rem Determine original release and run the appropriate script
CREATE OR REPLACE FUNCTION version_script 
RETURN VARCHAR2 IS

  p_null         char(1);
  p_version      VARCHAR2(30);
  p_prv_version  VARCHAR2(30);
  server_version VARCHAR2(30);

BEGIN

-- For 12.1, direct uppgrades are supported from 
-- 10.2.0.5, 11.1.0.7, and 11.2.0.2 and above.

  SELECT version INTO p_version FROM registry$ where cid='CATPROC';
  IF substr(p_version,1,8) = '10.2.0.5' THEN
     RETURN '1002000';
  ELSIF substr(p_version,1,8) = '11.1.0.7' THEN
     RETURN '1101000';
  ELSIF substr(p_version,1,6) = '11.2.0' AND
        substr(p_version,1,8) != '11.2.0.1' THEN
     RETURN '1102000';
  ELSIF substr(p_version,1,6) = '12.1.0' THEN -- current version
     SELECT version INTO server_version FROM v$instance;
     IF substr(p_version,1,8) != substr(server_version,1,8) THEN --- run c1201000   
        RETURN '1201000';
     ELSE 
        -- version is the same as instance, so rerun the previous upgrade
        -- rerun upgrade of previous release 
        EXECUTE IMMEDIATE
             'SELECT prv_version FROM registry$ where cid=''CATPROC'''
        INTO p_prv_version;

        IF substr(p_prv_version,1,8) = '10.2.0.5' THEN
           RETURN '1002000';
        ELSIF substr(p_prv_version,1,8) = '11.1.0.7' THEN
           RETURN '1101000';
        ELSIF substr(p_prv_version,1,6) = '11.2.0' AND
              substr(p_prv_version,1,8) != '11.2.0.1' THEN
           RETURN '1102000';
        ELSIF substr(p_prv_version,1,6) = '12.1.0' OR
              p_prv_version IS NULL THEN  -- new database
           RETURN '1201000';
        ELSE
           RAISE_APPLICATION_ERROR(-20000,
          'Upgrade re-run not supported from version ' || p_prv_version );
        END IF;
      END IF;
  END IF;

  RAISE_APPLICATION_ERROR(-20000,
       'Upgrade not supported from version ' || p_version );

END version_script;
/

Rem get the correct script name into the "upgrade_file" variable
COLUMN file_name NEW_VALUE upgrade_file NOPRINT;
SELECT version_script AS file_name FROM SYS.DUAL;

WHENEVER SQLERROR CONTINUE

Rem run the selected "c" upgrade script
@@c&upgrade_file

Rem Remove entries from sys.duc$ - rebuilt for 11g by catalog and catproc
Rem Can cause errors on any DROP USER statements in upgrade scripts
truncate table duc$;

Rem =====================================================================
Rem END STAGE 3: dictionary upgrade
Rem =====================================================================


