===============================
Interim Patch for Bug: 21370953
===============================

Release: October 2015
---------------------------------
Platform Patch for : Generic
Product Patched : ORACLE WEBLOGIC SERVER
Product Version      : 12.1.3.0.0

21370953 - WLS PATCH SET UPDATE 12.1.3.0.5

This document describes how to install the interim patch for
bug #  21370953. It includes the following sections:

	Section 1, "Prerequisites"

	Section 2, "Pre-Installation Instructions"

	Section 3, "Installation Instructions"

	Section 4, "Post-Installation Instructions"

	Section 5, "Deinstallation Instructions"

	Section 6, "Post Deinstallation Instructions"

	Section 7, "Bugs Fixed by This Patch"

 

1 Prerequisites
----------------
Ensure that you meet the following requirements before you install or
deinstall the patch:

1. Before applying the non-mandatory patches, ensure that you have the
exact symptoms described in the bug.

2. Oracle recommends that all customers be on the latest version of OPatch for
their release. Download the latest version of OPatch 13.2.x via My Oracle
Support Patch 6880880. (Choose 13.2.0.0.0 or "OUI NextGen 13.2")

Patch: p6880880_132000_Generic.zip

Review the following for more information:
Doc ID 1587524.1, "Using OPatch 13.1 for Oracle Fusion Middleware 12c (12.1.2+)"
https://support.oracle.com/rs?type=doc&id=1587524.1

For Oracle Fusion Middleware OPatch usage, refer to the URL below which
redirects to the latest FMW 12c document:
"Oracle Fusion Middleware Patching With OPatch"
http://www.oracle.com/pls/topic/lookup?ctx=fmw121x00&id=OPATC

3. Verify the OUI Inventory.
OPatch needs access to a valid OUI inventory to apply patches.

Note: This needs the ORACLE_HOME to be set(refer section "2. Pre-Installation Instructions")
prior to run the below commands:

Validate the OUI inventory with the following commands:

opatch lsinventory -jdk $JAVA_HOME  (in Windows %JAVA_HOME%)

If the command errors out, contact Oracle Support and work to validate and
verify the inventory setup before proceeding.

4. Confirm the executables appear in your system PATH.

The patching process will use the unzip and the OPatch executables. After
setting the ORACLE_HOME environment, confirm if the following executables
exist, before proceeding to the next step:

- opatch
- unzip

If either of these executables do not show in the PATH, correct the
problem before proceeding.

5. Create a location for storing the unzipped patch. This location
will be referred to later in the document as PATCH_TOP.

NOTE: On WINDOWS, the preferred location is the drive root directory.
For example, "C:\PATCH_TOP" and avoid choosing locations like,
"C:\Documents and Settings\username\PATCH_TOP".
This is necessary due to the 256 characters limitation on windows
platform.

2 Pre-Installation Instructions
-------------------------------

1. Set the ORACLE_HOME environment variable to the directory where you have installed ORACLE WEBLOGIC SERVER.

2. Stop all servers (AdminServer and all Managed server(s)).


3 Installation Instructions
---------------------------

1. Unzip the patch zip file into the PATCH_TOP.

$ unzip -d PATCH_TOP p21370953_121300_Generic.zip

NOTE: On WINDOWS, the unzip command has a limitation of 256 characters in the path name.
If you encounter this, please use an alternate ZIP utility like 7-Zip to unzip the patch.

For example: To unzip using 7-zip, run the command:
"c:\Program Files\7-Zip\7z.exe" x  p21370953_121300_Generic.zip

2. Set your current directory to the directory where the patch is located.

$ cd PATCH_TOP/21370953

3. Run OPatch to apply the patch.

$ opatch apply -jdk $JAVA_HOME   (in Windows %JAVA_HOME%)

Note:
-----
When OPatch starts, it validates the patch and makes sure that there are no
conflicts with the software already installed in the ORACLE_HOME.

In case of opatch conflict, you will see a warning message similar to the one mentioned below:

Interim Patch XXXX has Conflict with patch(es) [ YYYY ] in OH ...
Conflict patches: YYYY
Patch(es) YYYY conflict with the patch currently being installed (XXXX).
If you continue, patch(es) YYYY will be rolled back and the new patch (XXXX) will be installed.

If a merge of the new patch (XXXX) and the conflicting patch(es) ( YYYY) is required,contact Oracle Support Services and request a Merged patch.

Do you want to proceed? [y|n]
n

You must stop the patch installation and contact oracle support on how to proceed.

4 Post-Installation Instructions
---------------------------------
After install patched weblogic-maven-plugin-12.1.3.jar, users would need to
run weblogic sync plugin again to push jar to local maven repository to use. 
See https://docs.oracle.com/middleware/1213/wls/WLPRG/maven.htm#WLPRG587

Start all servers (AdminServer and all Managed server(s)).

5 Deinstallation Instructions
------------------------------

If you experience any problems after installing this patch, remove the patch as
follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any)
when deinstalling a patch.
This includes setting up any environment variables like ORACLE_HOME and
verifying the OUI inventory before deinstalling.

2. Change to the directory where the patch was unzipped.

$ cd PATCH_TOP/21370953

3. Run OPatch to deinstall the patch.

$ opatch rollback -id  21370953

6 Post Deinstallation Instructions
-----------------------------------
Restart all servers (AdminServer and all Managed server(s)).

This is necessary to redeploy the original applications and bring the
environment back to it's original state.

7 Bugs Fixed by This Patch
--------------------------
16562029 WEBLOGIC.APPMERGE DOES NOT MERGE DEPLOYMENT PLAN INTO PERSISTENCE.XML
17012341 PSR:PERF:WLS 12.1.2 JDBC BENCHMARK DIDN'T WORK WITH DRCP 
17394051 WEBLOGIC SERVER HAS MEMORY LEAK ON REDEPLOY
17721032 JAVA.LANG.INDEXOUTOFBOUNDSEXCEPTION: INDEX: 0, SIZE: 0
18082758 NOT POSSIBLE TO CONFIGURE WS-POLICY IN WLS 12.1.2
18276961 DEFAULT ERROR-PAGE FROM SERVLET 3.0 SPEC NOT WORKING
18289179 SETTING MAX-OPEN-SOCK-COUNT REQUIRES ENTITY REBOOT
18305935 SOA SERVER GOING TO SHUTDOWN STATE UPON FA DB OUTAGE
18376812 COOKIE-CONFIG IN WEB.XML NOT BEING HONORED
18432174 LIFECYCLESHUTDOWNSEQUENCETLOG IN DATABASE
18466848 NOT ABLE TO TARGET A SUBDEPLOYMENT ONCE JMS RESOURCE HAS BEEN CREATED
18481239 RA CALL TO ISDELIVERYTRANSACTED RAISES NOSUCHMETHODERROR FOR INHERITED METHOD
18538501 WLST DEPLOY COMMAND FAILING UNDER WEBLOGIC 12.1.2
18589879 MDS DOES NOT USE DATASOUCE RE-STARTED MANUALLY
18671042 JACC POLICYCONTEXT RESET BEFORE METHOD INVOCATION IN EJB AND SERVLET
18691894 Fix for Bug 18691894
18718889 WEB SERVICES RUNNING ON WLS FAIL WHILE MAINTAINING SESSION
18722098 NPE THROWN BY CLUSTEREDEJBTIMERMANAGER
18727635 UNABLE TO CONNECT TO JMS THROUGH JAVA APPLET (RDAY)
18729264 JAVA8 JDT GA MAY FAIL WITH JDK8 RUNTIME AND '-SOURCE' / '-TARGET' LESS THAN 1.8
18746515 GLOBAL ERROR-PAGE=FOR SERVLET 3.0 MERGING RESPONSES 
18753794 WEBLOGIC.NET.HTTP.HTTPURLCONNECTION DOES NOT USE HTTP CHANNEL IP
18859387 Fix for Bug 18859387
18912482 JAVA.LANG.CLASSNOTFOUNDEXCEPTION WHEN LOOKING UP GENERIC EJB
18922324 WLS12 EAR IST NOT DEPLOYABLE IF JACC POLICY PROVIDER IS ACTIVE
18964349 ILLEGALSTATEEXCEPTION THROWN WHEN MIGRATING JMS
18968900 Fix for Bug 18968900
19001915 CDI INJECTED PRINCIPAL NOT UPDATED AFTER CALLING HTTPSERVLETREQUEST#AUTHENTICATE
19033547 AC: WLS FCF CLEARS BORROWED CONNECTION LIST WHEN REPLAY DRIVER IS CONFIGURED
19066738 HTTP RESPONSE WRITE TIMEOUT FAILURE
19080525 NODEMANAGER DOES NOT HONOR 'MAX RESTARTS WITHIN INTERVAL' 
19265688 FORWARD DELAY WON'T WORK AS EXPECTED
19268444 ISSUE WITH JSP FILES CONTAINED IN JARS ON WEBLOGIC 12.1.2
19287842 Fix for Bug 19287842
19287874 Fix for Bug 19287874
19297004 WORK MANAGER NAME SHOWS (NO VALUE SPECIFIED) AFTER CREATION
19299358 EJB ASYNCHRONOUS CALL THROWS EXCEPTION
19339238 BUFFEREDREADER FAILS TO WHEN HTTP POST USES CHUNKED TRANSFER ENCODING
19351700 JAPANESE IS NOT USED IN SERVER LOG AND STANDARD OUT ON WLS 12.1.3
19422493 MENTORING:CCE ON STORE&RETRIEVE HANDLE TO REMOTE INTERFACE IN HTTP SESSION
19459949 RAC TX AFFINITY WITHOUT FAN
19500276 INJECT NOT WORKING IN INTERCEPTOR CLASS WHICH INTERCEPT MDB
19533331 EJB INJECTION VIA BASE CLASS DOES NOT WORK.  ILLEGALARGUMENTEXCEPTION IS THROWN.
19556868 JMS THIN CLIENT NOT INCLUDING CLASS ADMINTOOLHELPER
19576633 THREAD STACK ERROR OCCURRED WHEN MULTI-BYTE CHARACTERS ARE ENCODED UTF-8
19585666 ADMINISTRATION PORT OVERRIDE ISSUE WITH DYNAMIC CLUSTER
19668883 HIGH CPU USAGE ON WEBLOGIC 12.1.2 WHEN REMOTE JMX IS ENABLED
19705162 PERSISTENT FILE STORE COMMIT FAILED WHEN PARALLEL-XA-ENABLED DISABLED
19730967 FIX THE CHANGE MADE FOR BUG 18859387
19852007 WLS 12.1.3.0.0 - WEBLOGIC ADMIN SERVER IS HUNG WHILE STARTUP
19907066 Fix for Bug 19907066
19917893 IS THERE ANY ERROR MESSAGE WHEN REACHING WORKMANAGER MAX CAPACITY CONSTRAINT ?
19917991 MS GOES TO ADMIN MODE DUE TO APP DEPLOY ERRORS IN MSI MODE
19936917 CONCURRENTMODIFICATIONEXCEPTION IN MESSAGEDRIVENBEAN
19942900 WEBLOGIC 10.3.6.0.9 - DEPLOYER ROLE DOES NOT HAVE PERMISSION TO INSTALL APPLICAT
19973098 DEPLOY FAILED ON JAVAEE6\JCA\STOCKTRANSACTION SAMPLES
19988824 Fix for Bug 19988824
20080751 DURABLE SUBSCRIBERS ARE NOT DELETED FOR DYNAMIC EJB MODULE
20169972 WLS RETURNS HTTP CODE 500 WHEN A DEPLOYMENT WITH JSF IS RE-ACTIVATED
20206879 Fix for Bug 20206879
20266379 WLS 12.1.2 'SECONDS TO TRUST AN IDLE POOL CONNECTION' DOES NOT WORK
20323632 TRIED ALL: '1' ADDRESSES, BUT COULD NOT CONNECT ... FROM CONSOLEHELP URL
20471785 FAILURE WHILE NOTIFYING AN OBSERVER OF CDI EVENT FROM MDB
20523619 WLS SERVER HEALTH ISSUE IN PROVISIONING STARTUP PHASE 
20758863 T3S CONNECTION FAILS TO JAVA SERVICE OPC DOMAINS USING WLTHINT3CLIENT
20798352 WEBLOGIC CLIENT TRYING FOR DIRECT CONNECTION WHEN PROXY SERVER IS NOT AVAILABLE
20814890 Fix for Bug 20814890
20906638 Fix for Bug 20906638
20985893 CPU BUG20206879 FIX DOESN'T RESOLVE THE ISSUE FOR 10.3.6 
21069524 Fix for Bug 21069524
21107126 Fix for Bug 21107126
21169554 CONFIGURATION FAILURE IN FA PREFLGHTS
21746415 MAVEN PLUGIN FAILS TO EXECUTE GOAL UNDER PLUGIN COMPONENT
-----------------------------------------------------------------------------
DISCLAIMER:

This interim patch has only undergone basic unit testing, and has not been
through a complete test cycle generally followed for a production patch set.
Though the fixes in this document rectifies the bug, Oracle Corporation will
not be responsible for other issues that may arise due to these fixes.
Oracle Corporation recommends to later upgrade to the next production patch
set, when available. Applying this patch could overwrite other interim
patches applied since the last patch set. Customers need to make a request
to Oracle Support for a patch that includes those fixes, as well as inform
Oracle Support about all the patches installed when a Service Request is
opened. Please download, test, and provide feedback as soon as possible
to assist in the timely resolution of this problem.

Copyright (c)  2015, Oracle and/or its affiliates. All rights reserved.
----------------------------------------------------------------------------- 
