CREATE OR REPLACE PROCEDURE simple_error
as aNumber nuber;
BEGIN
     aNumber :=7;
END simple_error;
/
